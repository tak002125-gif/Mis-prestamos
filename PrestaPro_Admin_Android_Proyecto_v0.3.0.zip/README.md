# PrestaPro Admin v0.3.0

Aplicación privada para el propietario de PrestaPro.

## Objetivo de esta versión
- Mantener la identidad maestra RSA-3072 y el respaldo cifrado ya creados.
- Generar licencias PP1: prueba gratis de 7 días, anual de 1 año o permanente.
- La prueba gratis se limita a 1 dispositivo y 1 vez por dispositivo por defecto.
- Permitir una segunda prueba solo cuando el administrador la autoriza explícitamente.
- Renovar licencias anuales por 1 año desde el historial.
- Copiar y compartir licencias desde el historial.
- Conservar PIN, historial, identidad maestra y respaldo al actualizar sobre v0.1/v0.2.
- Nuevo icono de PrestaPro Admin con llave dorada para distinguirlo de PrestaPro normal.

## Importante
No distribuir esta APK a clientes. La clave privada permanece en PrestaPro Admin y en su respaldo cifrado.
