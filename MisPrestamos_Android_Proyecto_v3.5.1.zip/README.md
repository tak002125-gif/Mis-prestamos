# PrestaPro v3.5.1

Corrección puntual sobre v3.5:
- Resumen de hoy: cobros pendientes y monto esperado reforzados para préstamos atrasados.
- Cotizaciones/recibos: logo predeterminado actualizado a PrestaPro.
- Se conserva el mismo package y almacenamiento para mantener los datos existentes.
