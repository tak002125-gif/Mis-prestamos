# PrestaPro by Taca v3.13.1

Bloque 7A: licencias comerciales y prueba gratuita.

- Conserva compatibilidad con licencias anteriores y permanentes.
- Acepta licencias firmadas por PrestaPro Admin.
- Reconoce plan Prueba 7 días, Anual y Permanente.
- Muestra días restantes cuando la licencia es de prueba.
- Al vencer una prueba, conserva los datos y activa el modo restringido.
- No contiene la clave privada del generador.
