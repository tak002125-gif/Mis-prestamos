PrestaPro by Taca v3.5
Base estable: TACA Money v3.3.2 recuperación.
Cambio exclusivo de branding: nombre, icono, cabecera, splash, recibos, cotizaciones y notificaciones.
Se preservan package, claves de almacenamiento y nombre interno del respaldo de Drive para mantener compatibilidad con los datos existentes.
