package com.bytaca.prestaproadmin;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.KeyStore;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;

public class MainActivity extends Activity {
    private static final String PREFS = "prestapro_admin_secure";
    private static final String KEYSTORE_ALIAS = "prestapro_admin_local_aes_v1";
    private static final int REQ_EXPORT_BACKUP = 4011;
    private static final int REQ_IMPORT_BACKUP = 4012;
    private static final int REQ_VERIFY_BACKUP = 4013;
    private static final int PBKDF2_ITERATIONS = 220000;

    private WebView webView;
    private SharedPreferences prefs;
    private String pendingBackupJson;
    private String pendingRestorePassword;
    private String pendingVerifyPassword;
    private final SecureRandom random = new SecureRandom();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        setupWebView();
        webView.setVisibility(View.INVISIBLE);
        if (prefs.contains("pin_hash")) showUnlockDialog(); else showPinSetupDialog();
    }

    private void setupWebView() {
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AdminApp");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private EditText pinField(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setMaxLines(1);
        e.setPadding(24, 12, 24, 12);
        return e;
    }

    private void showPinSetupDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (20 * getResources().getDisplayMetrics().density);
        box.setPadding(p, 0, p, 0);
        EditText p1 = pinField("PIN de 6 dígitos");
        EditText p2 = pinField("Repetir PIN");
        box.addView(p1); box.addView(p2);
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Proteger PrestaPro Admin")
                .setMessage("Crea un PIN de 6 dígitos. Se pedirá al abrir esta aplicación.")
                .setView(box)
                .setCancelable(false)
                .setPositiveButton("Guardar", null)
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String a = p1.getText().toString().trim();
            String b = p2.getText().toString().trim();
            if (!a.matches("\\d{6}")) { p1.setError("Debe tener exactamente 6 dígitos"); return; }
            if (!a.equals(b)) { p2.setError("Los PIN no coinciden"); return; }
            try {
                byte[] salt = new byte[16]; random.nextBytes(salt);
                prefs.edit().putString("pin_salt", b64(salt)).putString("pin_hash", b64(hashPin(a, salt))).apply();
                d.dismiss();
                unlockUi();
            } catch (Exception e) { Toast.makeText(this, "No se pudo guardar el PIN", Toast.LENGTH_LONG).show(); }
        }));
        d.show();
    }

    private void showUnlockDialog() {
        EditText pin = pinField("PIN de 6 dígitos");
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("PrestaPro Admin")
                .setMessage("Ingresa tu PIN para continuar.")
                .setView(pin)
                .setCancelable(false)
                .setNegativeButton("Salir", (x, w) -> finish())
                .setPositiveButton("Entrar", null)
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String value = pin.getText().toString().trim();
            try {
                byte[] salt = Base64.decode(prefs.getString("pin_salt", ""), Base64.DEFAULT);
                byte[] expected = Base64.decode(prefs.getString("pin_hash", ""), Base64.DEFAULT);
                if (!MessageDigest.isEqual(expected, hashPin(value, salt))) { pin.setError("PIN incorrecto"); return; }
                d.dismiss();
                unlockUi();
            } catch (Exception e) { pin.setError("No se pudo verificar el PIN"); }
        }));
        d.show();
    }

    private byte[] hashPin(String pin, byte[] salt) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(salt);
        md.update(pin.getBytes(StandardCharsets.UTF_8));
        return md.digest();
    }

    private void unlockUi() {
        webView.setVisibility(View.VISIBLE);
        webView.postDelayed(() -> webView.evaluateJavascript("window.refreshAdmin && window.refreshAdmin()", null), 250);
    }

    private SecretKey getOrCreateLocalAesKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEYSTORE_ALIAS)) {
            KeyStore.SecretKeyEntry entry = (KeyStore.SecretKeyEntry) ks.getEntry(KEYSTORE_ALIAS, null);
            return entry.getSecretKey();
        }
        KeyGenerator kg = KeyGenerator.getInstance("AES", "AndroidKeyStore");
        android.security.keystore.KeyGenParameterSpec spec = new android.security.keystore.KeyGenParameterSpec.Builder(
                KEYSTORE_ALIAS,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT | android.security.keystore.KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build();
        kg.init(spec);
        return kg.generateKey();
    }

    private void storeMasterKey(KeyPair kp) throws Exception {
        SecretKey aes = getOrCreateLocalAesKey();
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, aes);
        byte[] encrypted = c.doFinal(kp.getPrivate().getEncoded());
        prefs.edit()
                .putString("master_public", b64(kp.getPublic().getEncoded()))
                .putString("master_private_iv", b64(c.getIV()))
                .putString("master_private_enc", b64(encrypted))
                .putLong("master_created", System.currentTimeMillis())
                .apply();
    }

    private PrivateKey loadPrivateKey() throws Exception {
        String enc = prefs.getString("master_private_enc", "");
        String iv = prefs.getString("master_private_iv", "");
        if (enc.isEmpty() || iv.isEmpty()) throw new IllegalStateException("No existe identidad maestra");
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, getOrCreateLocalAesKey(), new GCMParameterSpec(128, Base64.decode(iv, Base64.DEFAULT)));
        byte[] pkcs8 = c.doFinal(Base64.decode(enc, Base64.DEFAULT));
        return KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(pkcs8));
    }

    private PublicKey loadPublicKey() throws Exception {
        byte[] der = Base64.decode(prefs.getString("master_public", ""), Base64.DEFAULT);
        return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(der));
    }

    private boolean masterReady() {
        return !prefs.getString("master_public", "").isEmpty() && !prefs.getString("master_private_enc", "").isEmpty();
    }

    private String fingerprint(byte[] publicDer) throws Exception {
        byte[] d = MessageDigest.getInstance("SHA-256").digest(publicDer);
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < 12; i++) {
            if (i > 0 && i % 4 == 0) s.append('-');
            s.append(String.format(Locale.US, "%02X", d[i]));
        }
        return s.toString();
    }

    private String b64(byte[] bytes) { return Base64.encodeToString(bytes, Base64.NO_WRAP); }
    private String b64url(byte[] bytes) { return Base64.encodeToString(bytes, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING); }

    private JSONArray loadLicenses() {
        try { return new JSONArray(prefs.getString("licenses", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private void saveLicenses(JSONArray arr) { prefs.edit().putString("licenses", arr.toString()).apply(); }

    private JSONObject stateJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("masterReady", masterReady());
            o.put("version", "0.5.1");
            o.put("device", Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID));
            JSONArray licenses = loadLicenses();
            o.put("licenses", licenses);
            o.put("licenseCount", licenses.length());
            if (masterReady()) {
                byte[] pub = Base64.decode(prefs.getString("master_public", ""), Base64.DEFAULT);
                o.put("fingerprint", fingerprint(pub));
                o.put("publicKey", prefs.getString("master_public", ""));
                o.put("createdAt", prefs.getLong("master_created", 0));
            }
        } catch (Exception ignored) {}
        return o;
    }

    private String normalizeDevice(String raw) {
        return raw == null ? "" : raw.trim().toUpperCase(Locale.ROOT).replaceAll("\\s+", "");
    }

    private ArrayList<String> parseDevices(String raw) {
        ArrayList<String> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        if (raw == null) return out;
        for (String p : raw.split("[\\n,;]+")) {
            String v = normalizeDevice(p);
            if (!v.isEmpty() && seen.add(v)) out.add(v);
        }
        return out;
    }

    private String newLicenseId() {
        String date = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
        int n = 100000 + random.nextInt(900000);
        return "PP-LIC-" + date + "-" + n;
    }

    private long oneYearFrom(long base) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(base);
        c.add(Calendar.YEAR, 1);
        return c.getTimeInMillis();
    }

    private long sevenDaysFrom(long base) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(base);
        c.add(Calendar.DAY_OF_YEAR, 7);
        return c.getTimeInMillis();
    }

    private boolean deviceAlreadyHadTrial(String device) {
        String target = normalizeDevice(device);
        JSONArray all = loadLicenses();
        for (int i = 0; i < all.length(); i++) {
            JSONObject r = all.optJSONObject(i);
            if (r == null || !"Prueba 7 días".equalsIgnoreCase(r.optString("plan"))) continue;
            JSONArray devs = r.optJSONArray("devices");
            if (devs != null) {
                for (int j = 0; j < devs.length(); j++) {
                    if (target.equals(normalizeDevice(devs.optString(j)))) return true;
                }
            }
        }
        return false;
    }

    private JSONObject signAndStoreLicense(String customer, ArrayList<String> devices, String planLabel, long issuedAt, long expiresAt, String renewalOf) throws Exception {
        return signAndStoreLicense(customer, devices, planLabel, issuedAt, expiresAt, renewalOf, "", "");
    }

    // Keep PP1 license payload unchanged for compatibility with installed PrestaPro.
    // Transfer metadata belongs only to the Admin history and encrypted recovery backup.
    private JSONObject signAndStoreLicense(String customer, ArrayList<String> devices, String planLabel, long issuedAt, long expiresAt, String renewalOf, String transferOf, String transferReason) throws Exception {
        String licenseId = newLicenseId();

        JSONObject payload = new JSONObject();
        payload.put("v", 1);
        payload.put("licenseId", licenseId);
        payload.put("customer", customer);
        payload.put("plan", planLabel);
        payload.put("issuedAt", issuedAt);
        payload.put("expiresAt", expiresAt);
        payload.put("maxDevices", devices.size());
        payload.put("device", devices.get(0));
        JSONArray devArr = new JSONArray();
        for (String d : devices) devArr.put(d);
        payload.put("devices", devArr);
        if (renewalOf != null && !renewalOf.isEmpty()) payload.put("renewalOf", renewalOf);

        byte[] payloadBytes = payload.toString().getBytes(StandardCharsets.UTF_8);
        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(loadPrivateKey());
        s.update(payloadBytes);
        String code = "PP1." + b64url(payloadBytes) + "." + b64url(s.sign());

        JSONObject record = new JSONObject();
        record.put("licenseId", licenseId);
        record.put("customer", customer);
        record.put("plan", planLabel);
        record.put("issuedAt", issuedAt);
        record.put("expiresAt", expiresAt);
        record.put("devices", devArr);
        record.put("code", code);
        if (renewalOf != null && !renewalOf.isEmpty()) record.put("renewalOf", renewalOf);
        if (transferOf != null && !transferOf.isEmpty()) {
            record.put("transferOf", transferOf);
            record.put("transferReason", transferReason);
            record.put("transferredAt", issuedAt);
        }

        JSONArray all = loadLicenses();
        if (transferOf != null && !transferOf.isEmpty()) {
            boolean sourceFound = false;
            for (int i = 0; i < all.length(); i++) {
                JSONObject prior = all.optJSONObject(i);
                if (prior != null && transferOf.equals(prior.optString("licenseId"))) {
                    prior.put("transferredTo", licenseId);
                    sourceFound = true;
                    break;
                }
            }
            if (!sourceFound) throw new IllegalStateException("No se encontró la licencia original para registrar la transferencia.");
        }
        all.put(record);
        while (all.length() > 250) {
            JSONArray trimmed = new JSONArray();
            for (int i = all.length() - 250; i < all.length(); i++) trimmed.put(all.get(i));
            all = trimmed;
        }
        saveLicenses(all);

        JSONObject result = new JSONObject();
        result.put("ok", true);
        result.put("record", record);
        result.put("code", code);
        return result;
    }

    private JSONObject generateLicenseInternal(String customer, String devicesRaw, String plan, boolean allowRepeatTrial) throws Exception {
        if (!masterReady()) throw new IllegalStateException("Primero crea la identidad maestra.");
        customer = customer == null ? "" : customer.trim();
        if (customer.length() < 2) throw new IllegalArgumentException("Escribe el nombre del cliente.");
        ArrayList<String> devices = parseDevices(devicesRaw);
        if (devices.isEmpty()) throw new IllegalArgumentException("Ingresa al menos un código de dispositivo.");
        for (String d : devices) if (!d.matches("PP-[A-Z0-9-]{12,40}")) throw new IllegalArgumentException("Revisa este código de dispositivo: " + d);

        boolean trial = "trial".equalsIgnoreCase(plan);
        boolean permanent = "permanent".equalsIgnoreCase(plan);
        if (!trial && customer.split("\\s+").length < 2)
            throw new IllegalArgumentException("Para una licencia anual o permanente escribe el nombre y apellido completos del titular.");
        if (trial && devices.size() != 1) throw new IllegalArgumentException("La prueba gratis de 7 días se emite para un solo dispositivo.");
        if (trial && !allowRepeatTrial && deviceAlreadyHadTrial(devices.get(0))) {
            throw new IllegalArgumentException("Este dispositivo ya recibió una prueba gratis de 7 días. Si deseas autorizar otra excepcionalmente, activa la opción de segunda prueba.");
        }

        long now = System.currentTimeMillis();
        long expires = permanent ? 0L : (trial ? sevenDaysFrom(now) : oneYearFrom(now));
        String planLabel = permanent ? "Permanente" : (trial ? "Prueba 7 días" : "Anual");
        return signAndStoreLicense(customer, devices, planLabel, now, expires, "");
    }

    private boolean hasSuccessor(JSONArray records, String licenseId) {
        if (licenseId == null || licenseId.isEmpty()) return false;
        for (int i = 0; i < records.length(); i++) {
            JSONObject r = records.optJSONObject(i);
            if (r != null && (licenseId.equals(r.optString("transferOf"))
                    || licenseId.equals(r.optString("renewalOf")))) return true;
        }
        return false;
    }

    private synchronized JSONObject transferLicenseInternal(String sourceLicenseId, String newDeviceRaw, String reason) throws Exception {
        if (!masterReady()) throw new IllegalStateException("Primero debes recuperar tu identidad maestra.");
        JSONArray records = loadLicenses();
        JSONObject source = null;
        for (int i = records.length() - 1; i >= 0; i--) {
            JSONObject row = records.optJSONObject(i);
            if (row != null && sourceLicenseId != null && sourceLicenseId.equals(row.optString("licenseId"))) {
                source = row;
                break;
            }
        }
        if (source == null) throw new IllegalArgumentException("No se encontró esa licencia en el historial.");
        String plan = source.optString("plan");
        if (!"Anual".equals(plan) && !"Permanente".equals(plan)) {
            throw new IllegalArgumentException("Solo se pueden transferir licencias anuales o permanentes.");
        }
        if (!source.optString("transferredTo").isEmpty() || hasSuccessor(records, sourceLicenseId)) {
            throw new IllegalArgumentException("Esta licencia ya tiene una renovación o transferencia posterior. Elige la licencia más reciente.");
        }
        long now = System.currentTimeMillis();
        long expiry = source.optLong("expiresAt", 0L);
        if ("Anual".equals(plan) && expiry <= now) {
            throw new IllegalArgumentException("La licencia anual ya venció. Debes renovarla, no transferirla.");
        }
        JSONArray oldDevices = source.optJSONArray("devices");
        if (oldDevices == null || oldDevices.length() != 1) {
            throw new IllegalArgumentException("Esta transferencia admite únicamente licencias de un dispositivo.");
        }
        String oldDevice = normalizeDevice(oldDevices.optString(0));
        String newDevice = normalizeDevice(newDeviceRaw);
        if (!newDevice.matches("PP-[A-Z0-9-]{12,40}")) {
            throw new IllegalArgumentException("Código del nuevo teléfono no válido. Cópialo desde PrestaPro → Mi licencia.");
        }
        if (newDevice.equals(oldDevice)) {
            throw new IllegalArgumentException("El nuevo dispositivo debe ser diferente al anterior.");
        }
        if (!"perdida".equals(reason) && !"cambio".equals(reason)) {
            throw new IllegalArgumentException("Selecciona el motivo de la transferencia.");
        }
        ArrayList<String> devices = new ArrayList<>();
        devices.add(newDevice);
        // Exact original expiration is retained, never start a new year.
        return signAndStoreLicense(source.optString("customer", "Cliente"), devices, plan,
                now, expiry, "", sourceLicenseId, reason);
    }

    private JSONObject renewLicenseInternal(String sourceLicenseId) throws Exception {
        if (!masterReady()) throw new IllegalStateException("Primero crea la identidad maestra.");
        if (sourceLicenseId == null || sourceLicenseId.trim().isEmpty()) throw new IllegalArgumentException("Licencia no válida.");
        JSONArray all = loadLicenses();
        JSONObject source = null;
        for (int i = all.length() - 1; i >= 0; i--) {
            JSONObject r = all.optJSONObject(i);
            if (r != null && sourceLicenseId.equals(r.optString("licenseId"))) { source = r; break; }
        }
        if (source == null) throw new IllegalArgumentException("No se encontró la licencia en el historial.");
        if (!"Anual".equalsIgnoreCase(source.optString("plan"))) throw new IllegalArgumentException("Solo las licencias anuales necesitan renovación.");
        if (!source.optString("transferredTo").isEmpty() || hasSuccessor(all, sourceLicenseId))
            throw new IllegalArgumentException("Esta licencia tiene una emisión posterior. Renueva la licencia más reciente.");

        String customer = source.optString("customer", "Cliente");
        JSONArray devArr = source.optJSONArray("devices");
        ArrayList<String> devices = new ArrayList<>();
        if (devArr != null) for (int i = 0; i < devArr.length(); i++) { String d = normalizeDevice(devArr.optString(i)); if (!d.isEmpty()) devices.add(d); }
        if (devices.isEmpty()) throw new IllegalStateException("La licencia no tiene dispositivos registrados.");

        long now = System.currentTimeMillis();
        long currentExpiry = source.optLong("expiresAt", 0L);
        long base = Math.max(now, currentExpiry);
        long newExpiry = oneYearFrom(base);
        return signAndStoreLicense(customer, devices, "Anual", now, newExpiry, sourceLicenseId);
    }

    private SecretKey deriveBackupKey(String password, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, PBKDF2_ITERATIONS, 256);
        byte[] key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        return new javax.crypto.spec.SecretKeySpec(key, "AES");
    }

    private JSONObject buildRecoveryBackup(String password) throws Exception {
        if (!masterReady()) throw new IllegalStateException("No existe identidad maestra para respaldar.");
        if (password == null || password.length() < 10) throw new IllegalArgumentException("La contraseña de recuperación debe tener al menos 10 caracteres.");
        byte[] privateDer = loadPrivateKey().getEncoded();
        byte[] salt = new byte[16]; random.nextBytes(salt);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, deriveBackupKey(password, salt));
        byte[] encrypted = c.doFinal(privateDer);
        JSONObject out = new JSONObject();
        out.put("format", "PrestaProAdminRecovery");
        out.put("v", 1);
        out.put("createdAt", System.currentTimeMillis());
        out.put("kdf", "PBKDF2-HMAC-SHA256");
        out.put("iterations", PBKDF2_ITERATIONS);
        out.put("salt", b64(salt));
        out.put("iv", b64(c.getIV()));
        out.put("encryptedPrivateKey", b64(encrypted));
        out.put("publicKey", prefs.getString("master_public", ""));
        out.put("licenses", loadLicenses());
        return out;
    }


    private JSONObject verifyRecoveryBackup(String json, String password) throws Exception {
        JSONObject b = new JSONObject(json);
        if (!"PrestaProAdminRecovery".equals(b.optString("format")) || b.optInt("v") != 1)
            throw new IllegalArgumentException("El archivo no es un respaldo válido de PrestaPro Admin.");
        if (password == null || password.length() < 10)
            throw new IllegalArgumentException("Escribe la contraseña correcta del respaldo.");

        int iterations = b.optInt("iterations", PBKDF2_ITERATIONS);
        if (iterations < 100000 || iterations > 1000000)
            throw new IllegalArgumentException("Parámetros de respaldo no válidos.");

        byte[] salt = Base64.decode(b.getString("salt"), Base64.DEFAULT);
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, iterations, 256);
        byte[] key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        SecretKey sk = new javax.crypto.spec.SecretKeySpec(key, "AES");
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, sk, new GCMParameterSpec(128, Base64.decode(b.getString("iv"), Base64.DEFAULT)));
        byte[] privateDer = c.doFinal(Base64.decode(b.getString("encryptedPrivateKey"), Base64.DEFAULT));
        PrivateKey priv = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(privateDer));
        PublicKey pub = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(Base64.decode(b.getString("publicKey"), Base64.DEFAULT)));

        byte[] challenge = "PrestaPro-Recovery-Check".getBytes(StandardCharsets.UTF_8);
        Signature signer = Signature.getInstance("SHA256withRSA");
        signer.initSign(priv);
        signer.update(challenge);
        byte[] sig = signer.sign();
        Signature verifier = Signature.getInstance("SHA256withRSA");
        verifier.initVerify(pub);
        verifier.update(challenge);
        if (!verifier.verify(sig))
            throw new IllegalArgumentException("La clave privada no corresponde a la clave pública del respaldo.");

        String backupPublic = b.getString("publicKey");
        String backupFingerprint = fingerprint(pub.getEncoded());
        boolean matchesCurrent = masterReady() && backupPublic.equals(prefs.getString("master_public", ""));
        JSONArray licenses = b.optJSONArray("licenses");

        JSONObject out = new JSONObject();
        out.put("ok", true);
        out.put("fingerprint", backupFingerprint);
        out.put("createdAt", b.optLong("createdAt", 0L));
        out.put("licenseCount", licenses == null ? 0 : licenses.length());
        out.put("matchesCurrent", matchesCurrent);
        out.put("hasCurrentIdentity", masterReady());
        return out;
    }

    private void restoreRecoveryBackup(String json, String password) throws Exception {
        JSONObject b = new JSONObject(json);
        if (!"PrestaProAdminRecovery".equals(b.optString("format")) || b.optInt("v") != 1) throw new IllegalArgumentException("El archivo no es un respaldo válido de PrestaPro Admin.");
        int iterations = b.optInt("iterations", PBKDF2_ITERATIONS);
        if (iterations < 100000 || iterations > 1000000) throw new IllegalArgumentException("Parámetros de respaldo no válidos.");
        byte[] salt = Base64.decode(b.getString("salt"), Base64.DEFAULT);
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, iterations, 256);
        byte[] key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        SecretKey sk = new javax.crypto.spec.SecretKeySpec(key, "AES");
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, sk, new GCMParameterSpec(128, Base64.decode(b.getString("iv"), Base64.DEFAULT)));
        byte[] privateDer = c.doFinal(Base64.decode(b.getString("encryptedPrivateKey"), Base64.DEFAULT));
        PrivateKey priv = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(privateDer));
        PublicKey pub = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(Base64.decode(b.getString("publicKey"), Base64.DEFAULT)));

        byte[] challenge = "PrestaPro-Recovery-Check".getBytes(StandardCharsets.UTF_8);
        Signature signer = Signature.getInstance("SHA256withRSA"); signer.initSign(priv); signer.update(challenge); byte[] sig = signer.sign();
        Signature verifier = Signature.getInstance("SHA256withRSA"); verifier.initVerify(pub); verifier.update(challenge);
        if (!verifier.verify(sig)) throw new IllegalArgumentException("La clave privada no corresponde a la clave pública del respaldo.");

        storeMasterKey(new KeyPair(pub, priv));
        JSONArray licenses = b.optJSONArray("licenses");
        if (licenses != null) saveLicenses(licenses);
    }

    private String readAll(Uri uri) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new IllegalStateException("No se pudo abrir el archivo");
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        }
    }

    private void jsNotify(String message, boolean ok) {
        String safe = JSONObject.quote(message == null ? "" : message);
        webView.post(() -> webView.evaluateJavascript("window.adminNativeResult && window.adminNativeResult(" + safe + "," + ok + ")", null));
    }

    private void jsBackupVerified(JSONObject result) {
        String payload = result == null ? "{}" : result.toString();
        webView.post(() -> webView.evaluateJavascript("window.adminBackupVerified && window.adminBackupVerified(" + payload + ")", null));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            if (requestCode == REQ_EXPORT_BACKUP || requestCode == REQ_IMPORT_BACKUP || requestCode == REQ_VERIFY_BACKUP) jsNotify("Operación cancelada.", false);
            return;
        }
        Uri uri = data.getData();
        try {
            if (requestCode == REQ_EXPORT_BACKUP) {
                try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                    if (out == null) throw new IllegalStateException("No se pudo guardar el archivo");
                    out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                }
                pendingBackupJson = null;
                jsNotify("Respaldo maestro guardado correctamente.", true);
            } else if (requestCode == REQ_VERIFY_BACKUP) {
                JSONObject result = verifyRecoveryBackup(readAll(uri), pendingVerifyPassword == null ? "" : pendingVerifyPassword);
                pendingVerifyPassword = null;
                jsBackupVerified(result);
            } else if (requestCode == REQ_IMPORT_BACKUP) {
                restoreRecoveryBackup(readAll(uri), pendingRestorePassword == null ? "" : pendingRestorePassword);
                pendingRestorePassword = null;
                jsNotify("Identidad maestra restaurada correctamente.", true);
            }
        } catch (Exception e) {
            if (requestCode == REQ_VERIFY_BACKUP) {
                pendingVerifyPassword = null;
                try { jsBackupVerified(new JSONObject().put("ok", false).put("message", e.getMessage() == null ? "No se pudo verificar el respaldo." : e.getMessage())); } catch (Exception ignored) {}
            } else {
                jsNotify(e.getMessage() == null ? "No se pudo completar la operación." : e.getMessage(), false);
            }
        }
    }

    public class AndroidBridge {
        @JavascriptInterface public String getState() { return stateJson().toString(); }

        @JavascriptInterface public String createMasterIdentity() {
            JSONObject out = new JSONObject();
            try {
                if (masterReady()) throw new IllegalStateException("La identidad maestra ya existe en este dispositivo.");
                KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
                g.initialize(3072, random);
                KeyPair kp = g.generateKeyPair();
                storeMasterKey(kp);
                out.put("ok", true);
                out.put("fingerprint", fingerprint(kp.getPublic().getEncoded()));
                out.put("publicKey", b64(kp.getPublic().getEncoded()));
            } catch (Exception e) {
                try { out.put("ok", false); out.put("message", e.getMessage()); } catch (Exception ignored) {}
            }
            return out.toString();
        }

        @JavascriptInterface public String generateLicense(String customer, String devices, String plan, boolean allowRepeatTrial) {
            try { return generateLicenseInternal(customer, devices, plan, allowRepeatTrial).toString(); }
            catch (Exception e) {
                try { return new JSONObject().put("ok", false).put("message", e.getMessage()).toString(); }
                catch (Exception ignored) { return "{\"ok\":false}"; }
            }
        }

        @JavascriptInterface public String transferLicense(String licenseId, String newDevice, String reason) {
            try { return transferLicenseInternal(licenseId, newDevice, reason).toString(); }
            catch (Exception e) {
                try { return new JSONObject().put("ok", false).put("message", e.getMessage()).toString(); }
                catch (Exception ignored) { return "{\"ok\":false}"; }
            }
        }

        @JavascriptInterface public String renewLicense(String licenseId) {
            try { return renewLicenseInternal(licenseId).toString(); }
            catch (Exception e) {
                try { return new JSONObject().put("ok", false).put("message", e.getMessage()).toString(); }
                catch (Exception ignored) { return "{\"ok\":false}"; }
            }
        }

        @JavascriptInterface public void copyText(String value) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("PrestaPro", value == null ? "" : value));
                Toast.makeText(MainActivity.this, "Copiado", Toast.LENGTH_SHORT).show();
            });
        }

        @JavascriptInterface public void shareText(String value, String title) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT, title == null ? "PrestaPro" : title);
                i.putExtra(Intent.EXTRA_TEXT, value == null ? "" : value);
                startActivity(Intent.createChooser(i, "Compartir"));
            });
        }

        @JavascriptInterface public void startRecoveryBackup(String password) {
            runOnUiThread(() -> {
                try {
                    pendingBackupJson = buildRecoveryBackup(password).toString(2);
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/json");
                    i.putExtra(Intent.EXTRA_TITLE, "PrestaPro_Admin_Respaldo_Maestro.json");
                    startActivityForResult(i, REQ_EXPORT_BACKUP);
                } catch (Exception e) { jsNotify(e.getMessage(), false); }
            });
        }

        @JavascriptInterface public void startRecoveryVerify(String password) {
            runOnUiThread(() -> {
                if (password == null || password.length() < 10) { jsNotify("Escribe la contraseña de recuperación de al menos 10 caracteres.", false); return; }
                pendingVerifyPassword = password;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                startActivityForResult(i, REQ_VERIFY_BACKUP);
            });
        }

        @JavascriptInterface public void startRecoveryRestore(String password) {
            runOnUiThread(() -> {
                if (password == null || password.length() < 10) { jsNotify("Escribe la contraseña de recuperación de al menos 10 caracteres.", false); return; }
                pendingRestorePassword = password;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                startActivityForResult(i, REQ_IMPORT_BACKUP);
            });
        }

        @JavascriptInterface public String getPublicKeyText() {
            try {
                if (!masterReady()) return "";
                String pub = prefs.getString("master_public", "");
                return "PRESTAPRO ADMIN - CLAVE PÚBLICA\nFingerprint: " + fingerprint(Base64.decode(pub, Base64.DEFAULT)) + "\nPublicKeyBase64: " + pub;
            } catch (Exception e) { return ""; }
        }
    }
}
