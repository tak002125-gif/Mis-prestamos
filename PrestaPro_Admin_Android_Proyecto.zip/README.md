# PrestaPro Admin v0.1.0

Aplicación privada para el propietario de PrestaPro.

## Objetivo de esta primera versión
- Crear una identidad maestra RSA-3072 en el teléfono.
- Guardar la clave privada cifrada localmente mediante Android Keystore.
- Exportar/copiar la clave pública para registrar la nueva autoridad en PrestaPro.
- Generar licencias PP1 anuales (1 año) o permanentes para uno o varios códigos de dispositivo.
- Guardar un historial local de licencias.
- Crear/restaurar una copia de recuperación cifrada con contraseña (PBKDF2-HMAC-SHA256 + AES-GCM).
- Proteger el acceso a la app con PIN local de 6 dígitos.

## Importante
La clave pública generada por esta app debe incorporarse después a PrestaPro normal antes de usar comercialmente las nuevas licencias. Las licencias antiguas de propietario no se modifican por este proceso.

No distribuir esta APK a clientes.
