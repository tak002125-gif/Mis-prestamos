# PrestaPro Admin v0.5.1 · Código 6

Actualización del proyecto original v0.5.0 para AndroidIDE.

## Transferir licencia por pérdida o cambio de equipo

- Pestaña **Clientes**: búsqueda por nombre completo (admite tildes), código de dispositivo e ID de licencia. Al usar nombres idénticos, comprobar siempre el ID original antes de transferir.
- **Transferir dispositivo** aparece en la licencia anual vigente o permanente que no tenga sucesor registrado; también está en **Historial**. No aplica a pruebas gratuitas ni anuales vencidas.
- Solicita código nuevo (1 dispositivo) y motivo (pérdida/robo o cambio).
- Una licencia anual transferida conserva exactamente los milisegundos de `expiresAt` originales. Nunca agrega un año nuevo. Una permanente conserva vencimiento cero.
- Se genera nueva licencia PP1 firmada con la MISMA identidad maestra almacenada en la app instalada; la estructura del payload PP1 no se modificó.
- En el historial local aparecen `transferOf`, `transferredTo`, `transferReason`, `transferredAt`; se incluyen en la copia de recuperación ya existente. No se altera la firma de las licencias previas ni su código.
- No se permite transferir/renovar una licencia con emisión posterior en el historial; escoger la última emisión.
- **Límite importante:** por tratarse de licencias offline, el dispositivo anterior NO se revoca remotamente. Una nueva transferencia no garantiza técnicamente 1 solo dispositivo activo mientras la licencia anterior no expire.

## Instalación segura

1. Abrir Admin actual v0.5.0 y crear **nuevo respaldo maestro** con contraseña segura; verificarlo desde la pestaña Seguridad (el respaldo anterior contenía menos licencias).
2. Compilar v0.5.1 **con el mismo certificado de firma** y el mismo applicationId `com.bytaca.prestaproadmin` que la versión instalada. En Android, misma aplicación pero otra firma NO permite instalación encima.
3. Instalar encima, **nunca desinstalar** ni borrar datos de Admin.
4. Confirmar que la identidad maestra esté ACTIVA, coincida la huella pública y aparezcan exactamente las licencias anteriores.
5. Probar transferencia con una licencia ficticia primero y comprobar la fecha de vencimiento original y el nuevo código en PrestaPro.
6. Tras la primera transferencia real, crear un nuevo respaldo maestro porque incorpora el historial actualizado.

El ZIP del proyecto nunca contiene la clave privada ni datos reales del usuario. El respaldo maestro de claves es independiente y no debe compartirse.
