# PrestaPro Admin v0.4.0

Generador privado de licencias para PrestaPro by Taca.

## Novedades v0.4.0
- Nueva pestaña Clientes con vista comercial organizada.
- Búsqueda por cliente o código de dispositivo.
- Estado por cliente: activo, prueba, vence pronto, vencido o permanente.
- Acciones rápidas: copiar, compartir, renovar anual y crear nueva licencia con datos precargados.
- Mantiene historial, identidad maestra, PIN y respaldo al actualizar desde v0.3.0.
- Conserva prueba gratis de 7 días, anual, permanente y protección contra segunda prueba.
