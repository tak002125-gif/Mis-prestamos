# 3.22.60 — 27/11/2026
ES: Dinero total disponible; conciliación manual de banco y efectivo; diferencia y efectivo esperado; evita duplicar ganancias reinvertidas.
EN: Total available money; manual bank and cash reconciliation; difference and expected cash; avoids double-counting reinvested profit.
PT-BR: Dinheiro total disponível; conciliação manual de banco e dinheiro; diferença e dinheiro esperado; evita duplicar lucros reinvestidos.
ES: Saldos guardados, depósitos y retiros internos, correcciones e historial; actualización por cobros y desembolsos registrados.
EN: Saved balances, internal deposits and withdrawals, corrections and history; updates from recorded payments and disbursements.
PT-BR: Saldos salvos, depósitos e retiradas internas, correções e histórico; atualização por recebimentos e desembolsos registrados.
