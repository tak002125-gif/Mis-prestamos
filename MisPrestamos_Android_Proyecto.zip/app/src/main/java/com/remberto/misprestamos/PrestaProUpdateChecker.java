package com.remberto.misprestamos;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Comprobación opcional y no bloqueante de actualizaciones de la edición externa.
 * Nunca instala APKs ni modifica préstamos, preferencias comerciales o licencias.
 * Los datos de versión se sirven en el dominio oficial por HTTPS.
 */
final class PrestaProUpdateChecker {
    static final String MANIFEST_URL = "https://prestapro.tacaapps.app/version.json";
    static final String OFFICIAL_HOST = "prestapro.tacaapps.app";
    private static final String PREFS = "prestapro_update_checks_v1";
    private static final long CHECK_EVERY_MS = 2L * 60L * 60L * 1000L;
    private static final int MAX_MANIFEST_BYTES = 32 * 1024;

    private final MainActivity activity;
    private final WebView webView;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private boolean checking = false; // Solo se modifica en el hilo UI.
    private boolean manualCheckRequestedWhileBusy = false;
    private boolean pageReady = false;

    PrestaProUpdateChecker(MainActivity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
    }

    void setPageReady() {
        pageReady = true;
        check(false);
    }

    void check(boolean manual) {
        if (!pageReady) return;
        if (checking) {
            if (manual) {
                manualCheckRequestedWhileBusy = true;
                postResult(result("checking", true, "Buscando actualizaciones…"));
            }
            return;
        }
        if (activity.isFinishing() || activity.isDestroyed()) return;
        if (activity.isPrestaProInstalledFromPlay()) {
            if (manual) postResult(result("play", true, "Las actualizaciones de esta instalación se gestionan desde Google Play."));
            return;
        }
        SharedPreferences prefs = activity.getSharedPreferences(PREFS, 0);
        long now = System.currentTimeMillis();
        long last = prefs.getLong("last_successful_check", 0L);
        if (!manual && last > 0L && now >= last && now - last < CHECK_EVERY_MS) return;
        checking = true;
        if (manual) postResult(result("checking", true, "Buscando actualizaciones…"));
        executor.execute(() -> {
            JSONObject response;
            boolean success = false;
            try {
                response = retrieveManifest(manual);
                success = true;
            } catch (Exception error) {
                response = result("error", manual, "No se pudo comprobar la versión. Revisa tu conexión a internet.");
            }
            final JSONObject finalResponse = response;
            final boolean finalSuccess = success;
            activity.runOnUiThread(() -> {
                checking = false;
                if (manualCheckRequestedWhileBusy) {
                    try { finalResponse.put("manual", true); } catch (Exception ignored) {}
                    manualCheckRequestedWhileBusy = false;
                }
                if (finalSuccess) prefs.edit().putLong("last_successful_check", System.currentTimeMillis()).apply();
                postResult(finalResponse);
            });
        });
    }

    private JSONObject retrieveManifest(boolean manual) throws Exception {
        URL source = new URL(MANIFEST_URL);
        HttpURLConnection connection = (HttpURLConnection) source.openConnection();
        try {
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(6500);
            connection.setReadTimeout(6500);
            connection.setUseCaches(false);
            connection.setRequestProperty("Accept", "application/json");
            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                throw new IllegalStateException("HTTP " + connection.getResponseCode());
            }
            byte[] bytes;
            try (InputStream in = connection.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[4096];
                int size;
                while ((size = in.read(buf)) != -1) {
                    if (out.size() + size > MAX_MANIFEST_BYTES) throw new IllegalStateException("Archivo de versiones demasiado grande");
                    out.write(buf, 0, size);
                }
                bytes = out.toByteArray();
            }
            JSONObject manifest = new JSONObject(new String(bytes, StandardCharsets.UTF_8));
            if (!"PrestaPro".equals(manifest.optString("app", ""))) throw new IllegalStateException("Aplicación desconocida");
            int remoteCode = manifest.optInt("versionCode", -1);
            if (remoteCode < 1) throw new IllegalStateException("Versión inválida");
            String remoteName = manifest.optString("versionName", "").trim();
            if (!remoteName.matches("[0-9]+(\\.[0-9]+){1,3}")) throw new IllegalStateException("Nombre de versión inválido");
            String downloadUrl = manifest.optString("downloadUrl", "");
            if (!validOfficialApkUrl(downloadUrl)) throw new IllegalStateException("Enlace oficial inválido");
            PackageInfo installed = activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0);
            long installedCode = Build.VERSION.SDK_INT >= 28 ? installed.getLongVersionCode() : installed.versionCode;
            JSONObject result = result(remoteCode > installedCode ? "available" : "current", manual,
                    remoteCode > installedCode ? "Hay una nueva versión de PrestaPro." : "Ya tienes la versión más reciente de PrestaPro.");
            result.put("versionCode", remoteCode);
            result.put("versionName", remoteName);
            result.put("installedCode", installedCode);
            result.put("installedVersion", installed.versionName == null ? "" : installed.versionName);
            result.put("downloadUrl", downloadUrl);
            JSONArray safeNotes = new JSONArray();
            JSONArray notes = manifest.optJSONArray("releaseNotes");
            if (notes != null) {
                for (int i = 0; i < Math.min(4, notes.length()); i++) {
                    String note = notes.optString(i, "").trim();
                    if (!note.isEmpty()) safeNotes.put(note.substring(0, Math.min(note.length(), 200)));
                }
            }
            result.put("releaseNotes", safeNotes);
            return result;
        } finally {
            connection.disconnect();
        }
    }

    private JSONObject result(String status, boolean manual, String message) {
        JSONObject out = new JSONObject();
        try {
            out.put("status", status);
            out.put("manual", manual);
            out.put("message", message);
        } catch (Exception ignored) {}
        return out;
    }

    private void postResult(JSONObject result) {
        if (activity.isFinishing() || activity.isDestroyed() || !pageReady) return;
        String js = "if(window.receivePrestaProUpdateStatus){window.receivePrestaProUpdateStatus(" + result.toString() + ");}";
        webView.evaluateJavascript(js, null);
    }

    /** Permite únicamente la APK publicada en la dirección HTTPS oficial. */
    static boolean validOfficialApkUrl(String value) {
        if (value == null || value.length() > 500) return false;
        try {
            Uri url = Uri.parse(value);
            return "https".equalsIgnoreCase(url.getScheme())
                    && OFFICIAL_HOST.equalsIgnoreCase(url.getHost())
                    && (url.getPort() == -1 || url.getPort() == 443)
                    && "/PrestaPro.apk".equals(url.getPath())
                    && (url.getAuthority() != null && !url.getAuthority().contains("@"))
                    && url.getFragment() == null;
        } catch (Exception ignored) {
            return false;
        }
    }

    void openDownload(String url) {
        if (!validOfficialApkUrl(url)) return;
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            activity.startActivity(intent);
        } catch (Exception ignored) {
            android.widget.Toast.makeText(activity, "No se pudo abrir la descarga oficial", android.widget.Toast.LENGTH_LONG).show();
        }
    }

    void shutdown() {
        executor.shutdownNow();
    }
}
