package com.remberto.misprestamos;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AutoCashCloseReceiver extends BroadcastReceiver {
    public static final String ACTION_WARN = "com.remberto.misprestamos.AUTO_CASH_WARN";
    public static final String ACTION_CLOSE = "com.remberto.misprestamos.AUTO_CASH_CLOSE";
    public static final String PREFS = "prestapro_auto_cash";
    private static final String CHANNEL_ID = "prestapro_caja_auto_v1";

    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (!prefs.getBoolean("enabled", false)) {
            cancel(context);
            return;
        }
        String action = intent == null ? "" : intent.getAction();
        if (ACTION_WARN.equals(action)) {
            showNotification(context, 2801, "PrestaPro · Cierre de caja", "Tu caja se cerrará automáticamente en " + prefs.getInt("warn_minutes", 15) + " minutos.");
            return;
        }
        if (ACTION_CLOSE.equals(action)) {
            createPendingClose(context, prefs);
            schedule(context, prefs.getInt("hour", 22), prefs.getInt("minute", 0), prefs.getInt("warn_minutes", 15));
            return;
        }
        // Reinicio, cambio de hora/zona o actualización de la APK.
        schedule(context, prefs.getInt("hour", 22), prefs.getInt("minute", 0), prefs.getInt("warn_minutes", 15));
    }

    private static void createPendingClose(Context context, SharedPreferences prefs) {
        try {
            String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
            String pendingRaw = prefs.getString("pending_close_json", "");
            if (pendingRaw != null && !pendingRaw.isEmpty()) {
                JSONObject pending = new JSONObject(pendingRaw);
                if (today.equals(pending.optString("date", ""))) return;
            }

            JSONObject summary;
            try { summary = new JSONObject(prefs.getString("summary_json", "{}")); }
            catch (Exception e) { summary = new JSONObject(); }

            boolean sameDate = today.equals(summary.optString("date", ""));
            if (sameDate && summary.optBoolean("closed", false)) {
                prefs.edit().putLong("last_close_at", System.currentTimeMillis()).putString("last_close_date", today).apply();
                return;
            }

            JSONObject out = new JSONObject();
            out.put("date", today);
            out.put("dateTime", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(new Date()));
            out.put("cash", sameDate ? summary.optDouble("cash", 0d) : 0d);
            out.put("qr", sameDate ? summary.optDouble("qr", 0d) : 0d);
            out.put("total", sameDate ? summary.optDouble("total", 0d) : 0d);
            out.put("payments", sameDate ? summary.optInt("payments", 0) : 0);
            out.put("clients", sameDate ? summary.optInt("clients", 0) : 0);
            if (sameDate && !summary.isNull("countedCash")) out.put("countedCash", summary.optDouble("countedCash", 0d));
            else out.put("countedCash", JSONObject.NULL);
            if (sameDate && !summary.isNull("difference")) out.put("difference", summary.optDouble("difference", 0d));
            else out.put("difference", JSONObject.NULL);
            out.put("automatic", true);

            prefs.edit()
                    .putString("pending_close_json", out.toString())
                    .putLong("last_close_at", System.currentTimeMillis())
                    .putString("last_close_date", today)
                    .apply();

            String totalLabel = sameDate ? summary.optString("totalLabel", "") : "";
            String text = totalLabel == null || totalLabel.isEmpty()
                    ? "La caja del día fue cerrada automáticamente."
                    : "Caja cerrada automáticamente · Total " + totalLabel;
            showNotification(context, 2802, "PrestaPro · Caja cerrada", text);
        } catch (Exception ignored) {}
    }

    public static void schedule(Context context, int hour, int minute, int warnMinutes) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (!prefs.getBoolean("enabled", false)) { cancel(context); return; }
        hour = Math.max(0, Math.min(23, hour));
        minute = Math.max(0, Math.min(59, minute));
        warnMinutes = Math.max(0, Math.min(60, warnMinutes));

        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        Calendar close = Calendar.getInstance();
        close.set(Calendar.HOUR_OF_DAY, hour);
        close.set(Calendar.MINUTE, minute);
        close.set(Calendar.SECOND, 0);
        close.set(Calendar.MILLISECOND, 0);
        if (close.getTimeInMillis() <= System.currentTimeMillis()) close.add(Calendar.DAY_OF_YEAR, 1);

        PendingIntent closePi = pending(context, ACTION_CLOSE, 9201);
        PendingIntent warnPi = pending(context, ACTION_WARN, 9202);
        am.cancel(closePi); am.cancel(warnPi);

        boolean exact = scheduleOne(am, close.getTimeInMillis(), closePi);
        long warnAt = close.getTimeInMillis() - warnMinutes * 60_000L;
        if (warnMinutes > 0 && warnAt > System.currentTimeMillis()) scheduleOne(am, warnAt, warnPi);

        prefs.edit()
                .putInt("hour", hour).putInt("minute", minute).putInt("warn_minutes", warnMinutes)
                .putLong("next_close_at", close.getTimeInMillis())
                .putLong("next_warn_at", warnMinutes > 0 ? warnAt : 0L)
                .putBoolean("last_schedule_exact", exact)
                .apply();
    }

    private static boolean scheduleOne(AlarmManager am, long when, PendingIntent pi) {
        boolean exact = false;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (am.canScheduleExactAlarms()) { am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi); exact = true; }
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) { am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi); exact = true; }
            else { am.setExact(AlarmManager.RTC_WAKEUP, when, pi); exact = true; }
        } catch (SecurityException denied) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else am.set(AlarmManager.RTC_WAKEUP, when, pi);
        }
        return exact;
    }

    public static void cancel(Context context) {
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am != null) {
                am.cancel(pending(context, ACTION_CLOSE, 9201));
                am.cancel(pending(context, ACTION_WARN, 9202));
            }
        } catch (Exception ignored) {}
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putLong("next_close_at", 0L).putLong("next_warn_at", 0L).apply();
    }

    private static PendingIntent pending(Context context, String action, int requestCode) {
        Intent i = new Intent(context, AutoCashCloseReceiver.class); i.setAction(action);
        return PendingIntent.getBroadcast(context, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void showNotification(Context context, int id, String title, String text) {
        try {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Cierre automático de caja", NotificationManager.IMPORTANCE_DEFAULT);
                ch.setDescription("Avisos del cierre automático de caja de PrestaPro");
                nm.createNotificationChannel(ch);
            }
            Intent open = new Intent(context, MainActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent content = PendingIntent.getActivity(context, 9203, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            android.app.Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? new android.app.Notification.Builder(context, CHANNEL_ID)
                    : new android.app.Notification.Builder(context);
            b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                    .setContentTitle(title).setContentText(text)
                    .setStyle(new android.app.Notification.BigTextStyle().bigText(text))
                    .setContentIntent(content).setAutoCancel(true)
                    .setCategory(Notification.CATEGORY_REMINDER)
                    .setPriority(Notification.PRIORITY_DEFAULT);
            nm.notify(id, b.build());
        } catch (Exception ignored) {}
    }
}
