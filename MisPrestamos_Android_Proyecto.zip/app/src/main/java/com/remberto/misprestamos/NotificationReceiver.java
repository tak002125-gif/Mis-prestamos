package com.remberto.misprestamos;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class NotificationReceiver extends BroadcastReceiver {
    public static final String ACTION_DAILY = "com.remberto.misprestamos.DAILY_ALERT";
    public static final String ACTION_LATE = "com.remberto.misprestamos.LATE_ALERT";
    public static final String ACTION_TEST = "com.remberto.misprestamos.TEST_ALERT";
    private static final String CHANNEL_ID = "taca_recordatorios_v28";

    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences("taca_alerts", Context.MODE_PRIVATE);
        boolean enabled = prefs.getBoolean("alerts_enabled", false);
        String action = intent == null ? "" : intent.getAction();

        if (!enabled) {
            cancelAll(context);
            return;
        }
        if (ACTION_TEST.equals(action)) {
            prefs.edit().putLong("last_test_fired_at", System.currentTimeMillis()).putLong("test_alarm_at", 0L).apply();
            showTestNotification(context);
            return;
        }
        if (ACTION_DAILY.equals(action)) {
            if (Calendar.getInstance().get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
                showNormalSummary(context, prefs.getString("alerts_json", "[]"));
            }
            scheduleNormal(context, prefs.getInt("hour", 13), prefs.getInt("minute", 0));
            return;
        }
        if (ACTION_LATE.equals(action)) {
            if (prefs.getBoolean("late_alerts_enabled", true) && Calendar.getInstance().get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
                showLateSummary(context, prefs.getString("alerts_json", "[]"));
            }
            scheduleLate(context, prefs.getInt("late_hour", 9), prefs.getInt("late_minute", 0));
            return;
        }

        // Reinicia ambas programaciones después de reinicio, cambio de hora/zona o actualización de la APK.
        scheduleAll(context);
    }

    public static void scheduleAll(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("taca_alerts", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("alerts_enabled", false)) {
            cancelAll(context);
            return;
        }
        scheduleNormal(context, prefs.getInt("hour", 13), prefs.getInt("minute", 0));
        if (prefs.getBoolean("late_alerts_enabled", true)) {
            scheduleLate(context, prefs.getInt("late_hour", 9), prefs.getInt("late_minute", 0));
        } else {
            cancelLate(context);
        }
    }

    // Compatibilidad con llamadas antiguas: programa el recordatorio normal y conserva el de atraso configurado.
    public static void schedule(Context context, int hour, int minute) {
        context.getSharedPreferences("taca_alerts", Context.MODE_PRIVATE).edit()
                .putInt("hour", Math.max(0, Math.min(23, hour)))
                .putInt("minute", Math.max(0, Math.min(59, minute)))
                .apply();
        scheduleAll(context);
    }

    private static void scheduleNormal(Context context, int hour, int minute) {
        scheduleOne(context, ACTION_DAILY, 9001, hour, minute, "next_alarm_at");
    }

    private static void scheduleLate(Context context, int hour, int minute) {
        SharedPreferences prefs = context.getSharedPreferences("taca_alerts", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("late_alerts_enabled", true)) {
            cancelLate(context);
            return;
        }
        scheduleOne(context, ACTION_LATE, 9005, hour, minute, "next_late_alarm_at");
    }

    private static void scheduleOne(Context context, String action, int requestCode, int hour, int minute, String nextKey) {
        SharedPreferences prefs = context.getSharedPreferences("taca_alerts", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("alerts_enabled", false)) return;

        hour = Math.max(0, Math.min(23, hour));
        minute = Math.max(0, Math.min(59, minute));
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        Intent i = new Intent(context, NotificationReceiver.class);
        i.setAction(action);
        PendingIntent pi = PendingIntent.getBroadcast(context, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, hour);
        c.set(Calendar.MINUTE, minute);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1);
        while (c.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) c.add(Calendar.DAY_OF_YEAR, 1);

        am.cancel(pi);
        boolean exactUsed = false;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
                    exactUsed = true;
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
                exactUsed = true;
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
                exactUsed = true;
            }
        } catch (SecurityException denied) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
            else am.set(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
        }

        prefs.edit()
                .putLong(nextKey, c.getTimeInMillis())
                .putLong("last_scheduled_at", System.currentTimeMillis())
                .putBoolean("last_schedule_exact", exactUsed)
                .apply();
    }

    private static void cancelLate(Context context) {
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am != null) {
                Intent late = new Intent(context, NotificationReceiver.class);
                late.setAction(ACTION_LATE);
                PendingIntent latePi = PendingIntent.getBroadcast(context, 9005, late, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                am.cancel(latePi);
            }
        } catch (Exception ignored) {}
        context.getSharedPreferences("taca_alerts", Context.MODE_PRIVATE).edit().putLong("next_late_alarm_at", 0L).apply();
    }

    public static void cancelAll(Context context) {
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am != null) {
                Intent daily = new Intent(context, NotificationReceiver.class);
                daily.setAction(ACTION_DAILY);
                PendingIntent dailyPi = PendingIntent.getBroadcast(context, 9001, daily, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                am.cancel(dailyPi);

                Intent late = new Intent(context, NotificationReceiver.class);
                late.setAction(ACTION_LATE);
                PendingIntent latePi = PendingIntent.getBroadcast(context, 9005, late, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                am.cancel(latePi);

                Intent test = new Intent(context, NotificationReceiver.class);
                test.setAction(ACTION_TEST);
                PendingIntent testPi = PendingIntent.getBroadcast(context, 9003, test, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                am.cancel(testPi);
            }
        } catch (Exception ignored) {}
        context.getSharedPreferences("taca_alerts", Context.MODE_PRIVATE).edit()
                .putBoolean("alerts_enabled", false)
                .putString("alerts_json", "[]")
                .putLong("next_alarm_at", 0L)
                .putLong("next_late_alarm_at", 0L)
                .putLong("test_alarm_at", 0L)
                .apply();
    }

    public static long scheduleTest(Context context, long delayMs) {
        long when = System.currentTimeMillis() + Math.max(10_000L, delayMs);
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return 0L;
        Intent i = new Intent(context, NotificationReceiver.class);
        i.setAction(ACTION_TEST);
        PendingIntent pi = PendingIntent.getBroadcast(context, 9003, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else am.set(AlarmManager.RTC_WAKEUP, when, pi);
        } catch (SecurityException denied) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else am.set(AlarmManager.RTC_WAKEUP, when, pi);
        }
        context.getSharedPreferences("taca_alerts", Context.MODE_PRIVATE).edit().putLong("test_alarm_at", when).apply();
        return when;
    }

    private static void showNormalSummary(Context context, String json) {
        try {
            JSONArray arr = new JSONArray(json == null ? "[]" : json);
            String today = dateOffset(0), tomorrow = dateOffset(1);
            int dueToday = 0, dueTomorrow = 0, reminders = 0, grace = 0, graceExpired = 0, guaranteeExecution = 0;
            String firstClient = "";

            for (int n = 0; n < arr.length(); n++) {
                JSONObject o = arr.optJSONObject(n); if (o == null) continue;
                String client=o.optString("client", ""),frequency=o.optString("collectionFrequency","daily"),weeklyMode=o.optString("weeklyPaymentMode","");
                String due=o.optString("dueDate",""); boolean hasCollateral=o.optBoolean("hasCollateral",false);
                int paid=Math.max(0,o.optInt("paidInstallments",0)); int weeklyMisses=Math.max(1,o.optInt("weeklyCollateralMisses",2)); int collateralGrace=Math.max(0,o.optInt("collateralGraceDays",3));
                double balance=Math.max(0,o.optDouble("baseBalance",0));
                JSONArray dates=o.optJSONArray("scheduleDates"); int before=0,throughToday=0; String next="";
                if(dates!=null){
                    for(int d=0;d<dates.length();d++){
                        String iso=dates.optString(d,""); if(iso.isEmpty())continue;
                        if(iso.compareTo(today)<0)before++; if(iso.compareTo(today)<=0)throughToday++;
                        if(next.isEmpty()&&d>=paid)next=iso;
                    }
                }
                if(next.isEmpty())next=due;
                int overdue=0;
                if("weekly".equals(frequency)&&!"installments".equals(weeklyMode)){
                    if(!due.isEmpty()&&due.compareTo(today)<0&&balance>0.005){int days=Math.max(1,daysBetween(due,today));overdue=1+Math.max(0,(days-1)/7);}
                } else overdue=Math.max(0,before-paid);
                boolean weeklyGuarantee=hasCollateral&&"weekly".equals(frequency)&&"installments".equals(weeklyMode)&&overdue>=weeklyMisses&&balance>0.005;
                if(weeklyGuarantee)guaranteeExecution++;

                boolean dueNow=dates!=null&&containsDate(dates,today)&&paid<throughToday;
                if(dueNow){reminders++;if(firstClient.isEmpty())firstClient=client;}
                if(today.equals(next))dueToday++; else if(tomorrow.equals(next))dueTomorrow++;

                if(hasCollateral&&!due.isEmpty()&&due.compareTo(today)<0){
                    String graceEnd=addDays(due,collateralGrace); if(today.compareTo(graceEnd)<=0)grace++; else graceExpired++;
                }
            }

            if(dueToday+dueTomorrow+grace+graceExpired+reminders+guaranteeExecution==0)return;
            NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE); if(nm==null)return;
            Uri soundUri=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION); long[] vibration=new long[]{0,350,180,350};
            ensureChannel(context,nm,soundUri,vibration);

            StringBuilder text=new StringBuilder();
            if(reminders>0)text.append(reminders).append(tr(context," recordatorio(s) de cobro para revisar y enviar"," collection reminder(s) to review and send"," lembrete(s) de cobrança para revisar e enviar"));
            if(guaranteeExecution>0)append(text,guaranteeExecution+tr(context," garantía(s) requieren revisión"," collateral item(s) require review"," garantia(s) precisam de revisão"));
            if(dueToday>0&&reminders==0)append(text,dueToday+tr(context," vence(n) hoy"," due today"," vence(m) hoje"));
            if(dueTomorrow>0)append(text,dueTomorrow+tr(context," vence(n) mañana"," due tomorrow"," vence(m) amanhã"));
            if(grace>0)append(text,grace+tr(context," garantía(s) en plazo adicional"," collateral item(s) in grace period"," garantia(s) em prazo adicional"));
            if(graceExpired>0)append(text,graceExpired+tr(context," garantía(s) con plazo adicional vencido"," collateral item(s) with expired grace period"," garantia(s) com prazo adicional vencido"));
            notifyReminder(context,nm,1901,9002,tr(context,"PrestaPro · Recordatorios","PrestaPro · Reminders","PrestaPro · Lembretes"),text.toString(),firstClient,soundUri,vibration);
        } catch(Exception ignored){}
    }

    private static void showLateSummary(Context context, String json) {
        try {
            JSONArray arr = new JSONArray(json == null ? "[]" : json);
            String today = dateOffset(0);
            int firstLate = 0, secondLate = 0;
            String firstClient = "", firstDue = "";
            double firstBalance = 0;

            int jsWeekday=(Calendar.getInstance().get(Calendar.DAY_OF_WEEK)+6)%7; // JS: domingo=0 ... sábado=6
            if(jsWeekday==0)return;

            for (int n = 0; n < arr.length(); n++) {
                JSONObject o = arr.optJSONObject(n); if (o == null) continue;
                String client=o.optString("client", ""),frequency=o.optString("collectionFrequency","daily"),weeklyMode=o.optString("weeklyPaymentMode","");
                String due=o.optString("dueDate",""); boolean hasCollateral=o.optBoolean("hasCollateral",false);
                JSONArray collectionDays=o.optJSONArray("collectionDays"); JSONArray dates=o.optJSONArray("scheduleDates");
                int paid=Math.max(0,o.optInt("paidInstallments",0)); int dailyGrace=Math.max(0,o.optInt("dailyGraceMisses",2)); int weeklyMisses=Math.max(1,o.optInt("weeklyCollateralMisses",2));
                int penaltyCount=Math.max(0,o.optInt("penaltyCountAccrued",0)); double balance=Math.max(0,o.optDouble("baseBalance",0));
                if(balance<=0.005)continue;

                int before=0; String targetDue="";
                if(dates!=null){
                    for(int d=0;d<dates.length();d++){
                        String iso=dates.optString(d,""); if(iso.isEmpty())continue;
                        if(iso.compareTo(today)<0)before++;
                        if(targetDue.isEmpty()&&d>=paid)targetDue=iso;
                    }
                }
                if(targetDue.isEmpty())targetDue=due;

                int overdue=0;
                if("weekly".equals(frequency)&&!"installments".equals(weeklyMode)){
                    if(!due.isEmpty()&&due.compareTo(today)<0){int days=Math.max(1,daysBetween(due,today));overdue=1+Math.max(0,(days-1)/7);}
                } else overdue=Math.max(0,before-paid);

                boolean reminderDay=!"daily".equals(frequency) || collectionDays==null || collectionDays.length()==0 || containsInt(collectionDays,jsWeekday);
                boolean weeklyGuarantee=hasCollateral&&"weekly".equals(frequency)&&"installments".equals(weeklyMode)&&overdue>=weeklyMisses;
                if(!reminderDay || ("daily".equals(frequency)&&(overdue>dailyGrace||penaltyCount>0)) || weeklyGuarantee || ("weekly".equals(frequency)&&overdue>weeklyMisses))continue;

                if(overdue==1)firstLate++; else if(overdue==2)secondLate++; else continue;
                if(firstClient.isEmpty()){
                    firstClient=client;
                    firstDue=targetDue;
                    firstBalance=balance;
                }
            }

            int total=firstLate+secondLate;
            if(total==0)return;
            NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE); if(nm==null)return;
            Uri soundUri=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION); long[] vibration=new long[]{0,350,180,350};
            ensureChannel(context,nm,soundUri,vibration);

            StringBuilder text=new StringBuilder("⚠ ");
            if(firstLate>0)text.append(firstLate).append(firstLate==1?tr(context," primer atraso"," first overdue payment"," primeiro atraso"):tr(context," primeros atrasos"," first overdue payments"," primeiros atrasos"));
            if(secondLate>0){if(firstLate>0)text.append(" · ");text.append(secondLate).append(secondLate==1?tr(context," segundo atraso"," second overdue payment"," segundo atraso"):tr(context," segundos atrasos"," second overdue payments"," segundos atrasos"));}
            text.append(tr(context," para revisar y enviar"," to review and send"," para revisar e enviar"));
            if(total==1&&!firstClient.isEmpty()){
                if(!firstDue.isEmpty())text.append(tr(context," · vencida desde "," · overdue since "," · vencida desde ")).append(formatIso(firstDue));
                if(firstBalance>0.005)text.append(tr(context," · saldo "," · balance "," · saldo ")).append(moneyLabel(context,firstBalance));
            }
            notifyReminder(context,nm,1905,9006,tr(context,"PrestaPro · ⚠ Recordatorio por atraso","PrestaPro · ⚠ Overdue reminder","PrestaPro · ⚠ Lembrete de atraso"),text.toString(),firstClient,soundUri,vibration);
        } catch(Exception ignored){}
    }

    private static void notifyReminder(Context context, NotificationManager nm, int notificationId, int requestCode, String title, String text, String firstClient, Uri soundUri, long[] vibration) {
        Intent open=new Intent(context,MainActivity.class);
        open.putExtra("open_reminders",true);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content=PendingIntent.getActivity(context,requestCode,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b=Build.VERSION.SDK_INT>=Build.VERSION_CODES.O?new android.app.Notification.Builder(context,CHANNEL_ID):new android.app.Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle(title).setContentText(text)
                .setStyle(new android.app.Notification.BigTextStyle().bigText(text+(firstClient.isEmpty()?"":tr(context,". Toca para abrir el recordatorio de ",". Tap to open the reminder for ",". Toque para abrir o lembrete de ")+firstClient+".")))
                .setContentIntent(content).setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER).setPriority(Notification.PRIORITY_HIGH)
                .setSound(soundUri).setVibrate(vibration).setDefaults(Notification.DEFAULT_SOUND|Notification.DEFAULT_VIBRATE);
        nm.notify(notificationId,b.build());
    }

    private static void showTestNotification(Context context){
        try{
            NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);if(nm==null)return;
            Uri soundUri=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);long[] vibration=new long[]{0,350,180,350};ensureChannel(context,nm,soundUri,vibration);
            Intent open=new Intent(context,MainActivity.class);open.putExtra("open_reminders",true);open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent content=PendingIntent.getActivity(context,9004,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            android.app.Notification.Builder b=Build.VERSION.SDK_INT>=Build.VERSION_CODES.O?new android.app.Notification.Builder(context,CHANNEL_ID):new android.app.Notification.Builder(context);
            b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(tr(context,"PrestaPro · Prueba correcta","PrestaPro · Test successful","PrestaPro · Teste concluído")).setContentText(tr(context,"La alarma de prueba se ejecutó correctamente.","The test alarm ran successfully.","O alarme de teste foi executado corretamente."))
                    .setContentIntent(content).setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER).setPriority(Notification.PRIORITY_HIGH)
                    .setSound(soundUri).setVibrate(vibration).setDefaults(Notification.DEFAULT_SOUND|Notification.DEFAULT_VIBRATE);
            nm.notify(1902,b.build());
        }catch(Exception ignored){}
    }

    private static void ensureChannel(Context context, NotificationManager nm, Uri soundUri, long[] vibration){
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
            NotificationChannel ch=new NotificationChannel(CHANNEL_ID,tr(context,"Recordatorios PrestaPro","PrestaPro reminders","Lembretes PrestaPro"),NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription(tr(context,"Avisos con sonido y vibración para revisar cobros y atrasos","Sound and vibration alerts for collections and overdue payments","Avisos com som e vibração para cobranças e atrasos"));ch.enableVibration(true);ch.setVibrationPattern(vibration);ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            AudioAttributes attrs=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();ch.setSound(soundUri,attrs);nm.createNotificationChannel(ch);
        }
    }

    private static boolean containsDate(JSONArray dates,String target){for(int i=0;i<dates.length();i++)if(target.equals(dates.optString(i,"")))return true;return false;}
    private static boolean containsInt(JSONArray values,int target){for(int i=0;i<values.length();i++)if(values.optInt(i,-99)==target)return true;return false;}
    private static String language(Context context) {
        return context.getSharedPreferences("taca_alerts", Context.MODE_PRIVATE).getString("language", "es");
    }
    private static String tr(Context context, String es, String en, String pt) {
        String l = language(context);
        if ("en".equalsIgnoreCase(l)) return en;
        if (l != null && l.toLowerCase(Locale.US).startsWith("pt")) return pt;
        return es;
    }
    private static String moneyLabel(Context context, double value) {
        android.content.SharedPreferences p = context.getSharedPreferences("taca_alerts", Context.MODE_PRIVATE);
        String c = p.getString("currency", "BOB");
        String symbol = "BOB".equals(c) ? "Bs" : ("BRL".equals(c) ? "R$" : ("USD".equals(c) ? "$" : ("EUR".equals(c) ? "€" : c)));
        return symbol + " " + String.format(Locale.US, "%.2f", value);
    }
    private static int daysBetween(String start,String end){try{SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);Date a=f.parse(start),b=f.parse(end);if(a==null||b==null)return 0;return (int)Math.floor((b.getTime()-a.getTime())/86400000d);}catch(Exception e){return 0;}}
    private static String formatIso(String iso){try{SimpleDateFormat in=new SimpleDateFormat("yyyy-MM-dd",Locale.US);Date d=in.parse(iso);return d==null?iso:new SimpleDateFormat("dd/MM/yyyy",Locale.US).format(d);}catch(Exception e){return iso;}}

    private static void append(StringBuilder sb, String value) {
        if (sb.length() > 0) sb.append(" · ");
        sb.append(value);
    }

    private static String dateOffset(int days) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, days);
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime());
    }

    private static String addDays(String iso, int days) throws Exception {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        Date d = f.parse(iso);
        Calendar c = Calendar.getInstance();
        c.setTime(d);
        c.add(Calendar.DAY_OF_YEAR, days);
        return f.format(c.getTime());
    }
}
