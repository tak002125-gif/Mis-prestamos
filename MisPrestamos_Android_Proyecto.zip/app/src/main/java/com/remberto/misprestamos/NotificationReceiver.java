package com.remberto.misprestamos;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class NotificationReceiver extends BroadcastReceiver {
    public static final String ACTION_DAILY = "com.remberto.misprestamos.DAILY_ALERT";
    public static final String ACTION_TEST = "com.remberto.misprestamos.TEST_ALERT";
    private static final String CHANNEL_ID = "taca_recordatorios_v28";

    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences("taca_alerts", Context.MODE_PRIVATE);
        int hour = prefs.getInt("hour", 8);
        int minute = prefs.getInt("minute", 0);
        boolean enabled = prefs.getBoolean("alerts_enabled", false);

        String action = intent == null ? "" : intent.getAction();
        if (!enabled) {
            cancelAll(context);
            return;
        }
        if (ACTION_TEST.equals(action)) {
            prefs.edit().putLong("last_test_fired_at", System.currentTimeMillis()).putLong("test_alarm_at", 0L).apply();
            showTestNotification(context);
            return;
        }
        if (!ACTION_DAILY.equals(action)) {
            // Reinicia la programación después de reinicio, cambio de hora/zona o actualización de la APK.
            schedule(context, hour, minute);
            return;
        }

        showSummary(context, prefs.getString("alerts_json", "[]"));
        // Reprograma el siguiente aviso como alarma de una sola vez para reducir retrasos
        // respecto de setInexactRepeating, sin exigir permisos especiales de alarma exacta.
        schedule(context, hour, minute);
    }

    public static void schedule(Context context, int hour, int minute) {
        SharedPreferences prefs = context.getSharedPreferences("taca_alerts", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("alerts_enabled", false)) {
            cancelAll(context);
            return;
        }
        hour = Math.max(0, Math.min(23, hour));
        minute = Math.max(0, Math.min(59, minute));

        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        Intent i = new Intent(context, NotificationReceiver.class);
        i.setAction(ACTION_DAILY);
        PendingIntent pi = PendingIntent.getBroadcast(context, 9001, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, hour);c.set(Calendar.MINUTE, minute);c.set(Calendar.SECOND, 0);c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1);

        am.cancel(pi);
        boolean exactUsed = false;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (am.canScheduleExactAlarms()) {am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);exactUsed = true;}
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);exactUsed = true;}
            else {am.setExact(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);exactUsed = true;}
        } catch (SecurityException denied) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
            else am.set(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
        }
        context.getSharedPreferences("taca_alerts", Context.MODE_PRIVATE).edit()
                .putLong("next_alarm_at", c.getTimeInMillis())
                .putLong("last_scheduled_at", System.currentTimeMillis())
                .putBoolean("last_schedule_exact", exactUsed)
                .apply();
    }

    public static void cancelAll(Context context) {
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am != null) {
                Intent daily = new Intent(context, NotificationReceiver.class);
                daily.setAction(ACTION_DAILY);
                PendingIntent dailyPi = PendingIntent.getBroadcast(context, 9001, daily, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                am.cancel(dailyPi);

                Intent test = new Intent(context, NotificationReceiver.class);
                test.setAction(ACTION_TEST);
                PendingIntent testPi = PendingIntent.getBroadcast(context, 9003, test, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                am.cancel(testPi);
            }
        } catch (Exception ignored) {}
        context.getSharedPreferences("taca_alerts", Context.MODE_PRIVATE).edit()
                .putBoolean("alerts_enabled", false)
                .putString("alerts_json", "[]")
                .putLong("next_alarm_at", 0L)
                .putLong("test_alarm_at", 0L)
                .apply();
    }

    public static long scheduleTest(Context context, long delayMs) {
        long when = System.currentTimeMillis() + Math.max(10_000L, delayMs);
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return 0L;
        Intent i = new Intent(context, NotificationReceiver.class);i.setAction(ACTION_TEST);
        PendingIntent pi = PendingIntent.getBroadcast(context, 9003, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else am.set(AlarmManager.RTC_WAKEUP, when, pi);
        } catch (SecurityException denied) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else am.set(AlarmManager.RTC_WAKEUP, when, pi);
        }
        context.getSharedPreferences("taca_alerts", Context.MODE_PRIVATE).edit().putLong("test_alarm_at", when).apply();
        return when;
    }

    private static void showSummary(Context context, String json) {
        try {
            JSONArray arr = new JSONArray(json == null ? "[]" : json);
            String today = dateOffset(0), tomorrow = dateOffset(1);
            int dueToday = 0, dueTomorrow = 0, overdueCount = 0, grace = 0, graceExpired = 0, reminders = 0, guaranteeExecution = 0;
            String firstClient = "";

            for (int n = 0; n < arr.length(); n++) {
                JSONObject o = arr.optJSONObject(n);if (o == null) continue;
                String client=o.optString("client", ""),frequency=o.optString("collectionFrequency","daily"),weeklyMode=o.optString("weeklyPaymentMode","");
                String due=o.optString("dueDate","");boolean hasCollateral=o.optBoolean("hasCollateral",false);
                int paid=Math.max(0,o.optInt("paidInstallments",0));int dailyGrace=Math.max(0,o.optInt("dailyGraceMisses",2));
                int weeklyMisses=Math.max(1,o.optInt("weeklyCollateralMisses",2));int collateralGrace=Math.max(0,o.optInt("collateralGraceDays",3));
                int penaltyCount=Math.max(0,o.optInt("penaltyCountAccrued",0));double balance=Math.max(0,o.optDouble("baseBalance",0));
                JSONArray dates=o.optJSONArray("scheduleDates");int before=0,throughToday=0;String next="";
                if(dates!=null){
                    for(int d=0;d<dates.length();d++){
                        String iso=dates.optString(d,"");if(iso.isEmpty())continue;
                        if(iso.compareTo(today)<0)before++;if(iso.compareTo(today)<=0)throughToday++;
                        if(next.isEmpty()&&d>=paid)next=iso;
                    }
                }
                if(next.isEmpty())next=due;

                int overdue=0;
                if("weekly".equals(frequency)&&!"installments".equals(weeklyMode)){
                    if(!due.isEmpty()&&due.compareTo(today)<0&&balance>0.005){int days=Math.max(1,daysBetween(due,today));overdue=1+Math.max(0,(days-1)/7);}
                } else overdue=Math.max(0,before-paid);

                boolean weeklyGuarantee=hasCollateral&&"weekly".equals(frequency)&&"installments".equals(weeklyMode)&&overdue>=weeklyMisses&&balance>0.005;
                String stage="";
                if (!("daily".equals(frequency)&&(overdue>dailyGrace||penaltyCount>0)) && !weeklyGuarantee && !("weekly".equals(frequency)&&overdue>weeklyMisses)) {
                    if(overdue==2)stage="late2";else if(overdue==1)stage="late1";else if(dates!=null&&containsDate(dates,today)&&paid<throughToday)stage="today";
                }
                if(!stage.isEmpty()){reminders++;if(firstClient.isEmpty())firstClient=client;}
                if(weeklyGuarantee)guaranteeExecution++;
                if(today.equals(next))dueToday++;else if(tomorrow.equals(next))dueTomorrow++;else if(overdue>0||(!next.isEmpty()&&next.compareTo(today)<0))overdueCount++;

                if(hasCollateral&&!due.isEmpty()&&due.compareTo(today)<0){
                    String graceEnd=addDays(due,collateralGrace);if(today.compareTo(graceEnd)<=0)grace++;else graceExpired++;
                }
            }

            if(dueToday+dueTomorrow+overdueCount+grace+graceExpired+reminders+guaranteeExecution==0)return;
            NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);if(nm==null)return;
            Uri soundUri=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);long[] vibration=new long[]{0,350,180,350};
            ensureChannel(nm,soundUri,vibration);

            StringBuilder text=new StringBuilder();
            if(reminders>0)text.append(reminders).append(" recordatorio(s) para revisar y enviar");
            if(guaranteeExecution>0)append(text,guaranteeExecution+" garantía(s) requieren revisión");
            if(dueToday>0&&reminders==0)append(text,dueToday+" vence(n) hoy");
            if(overdueCount>0)append(text,overdueCount+" atrasado(s)");
            if(dueTomorrow>0)append(text,dueTomorrow+" vence(n) mañana");
            if(grace>0)append(text,grace+" garantía(s) en plazo adicional");
            if(graceExpired>0)append(text,graceExpired+" garantía(s) con plazo adicional vencido");

            Intent open=new Intent(context,MainActivity.class);open.putExtra("open_reminders",true);open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent content=PendingIntent.getActivity(context,9002,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            android.app.Notification.Builder b=Build.VERSION.SDK_INT>=Build.VERSION_CODES.O?new android.app.Notification.Builder(context,CHANNEL_ID):new android.app.Notification.Builder(context);
            b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("PrestaPro · Recordatorios").setContentText(text.toString())
                    .setStyle(new android.app.Notification.BigTextStyle().bigText(text.toString()+(firstClient.isEmpty()?"":". Toca para abrir el recordatorio de "+firstClient+".")))
                    .setContentIntent(content).setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER).setPriority(Notification.PRIORITY_HIGH)
                    .setSound(soundUri).setVibrate(vibration).setDefaults(Notification.DEFAULT_SOUND|Notification.DEFAULT_VIBRATE);
            nm.notify(1901,b.build());
        } catch(Exception ignored){}
    }

    private static void showTestNotification(Context context){
        try{
            NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);if(nm==null)return;
            Uri soundUri=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);long[] vibration=new long[]{0,350,180,350};ensureChannel(nm,soundUri,vibration);
            Intent open=new Intent(context,MainActivity.class);open.putExtra("open_reminders",true);open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent content=PendingIntent.getActivity(context,9004,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            android.app.Notification.Builder b=Build.VERSION.SDK_INT>=Build.VERSION_CODES.O?new android.app.Notification.Builder(context,CHANNEL_ID):new android.app.Notification.Builder(context);
            b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("PrestaPro · Prueba correcta").setContentText("La alarma de prueba se ejecutó correctamente.")
                    .setContentIntent(content).setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER).setPriority(Notification.PRIORITY_HIGH)
                    .setSound(soundUri).setVibrate(vibration).setDefaults(Notification.DEFAULT_SOUND|Notification.DEFAULT_VIBRATE);
            nm.notify(1902,b.build());
        }catch(Exception ignored){}
    }

    private static void ensureChannel(NotificationManager nm, Uri soundUri, long[] vibration){
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
            NotificationChannel ch=new NotificationChannel(CHANNEL_ID,"Recordatorios PrestaPro",NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Avisos con sonido y vibración para revisar cobros y recordatorios");ch.enableVibration(true);ch.setVibrationPattern(vibration);ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            AudioAttributes attrs=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();ch.setSound(soundUri,attrs);nm.createNotificationChannel(ch);
        }
    }

    private static boolean containsDate(JSONArray dates,String target){for(int i=0;i<dates.length();i++)if(target.equals(dates.optString(i,"")))return true;return false;}
    private static int daysBetween(String start,String end){try{SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);Date a=f.parse(start),b=f.parse(end);if(a==null||b==null)return 0;return (int)Math.floor((b.getTime()-a.getTime())/86400000d);}catch(Exception e){return 0;}}

    private static void append(StringBuilder sb, String value) {
        if (sb.length() > 0) sb.append(" · ");
        sb.append(value);
    }

    private static String dateOffset(int days) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, days);
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime());
    }

    private static String addDays(String iso, int days) throws Exception {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        Date d = f.parse(iso);
        Calendar c = Calendar.getInstance();
        c.setTime(d);
        c.add(Calendar.DAY_OF_YEAR, days);
        return f.format(c.getTime());
    }
}
