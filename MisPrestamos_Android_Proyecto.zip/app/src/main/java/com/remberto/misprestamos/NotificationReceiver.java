package com.remberto.misprestamos;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class NotificationReceiver extends BroadcastReceiver {
    public static final String ACTION_DAILY = "com.remberto.misprestamos.DAILY_ALERT";
    private static final String CHANNEL_ID = "taca_vencimientos";

    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences("taca_alerts", Context.MODE_PRIVATE);
        int hour = prefs.getInt("hour", 8);
        int minute = prefs.getInt("minute", 0);
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            schedule(context, hour, minute);
            return;
        }
        showSummary(context, prefs.getString("alerts_json", "[]"));
    }

    public static void schedule(Context context, int hour, int minute) {
        hour = Math.max(0, Math.min(23, hour));
        minute = Math.max(0, Math.min(59, minute));
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(context, NotificationReceiver.class);
        i.setAction(ACTION_DAILY);
        PendingIntent pi = PendingIntent.getBroadcast(context, 9001, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, hour);
        c.set(Calendar.MINUTE, minute);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1);
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pi);
    }

    private static void showSummary(Context context, String json) {
        try {
            JSONArray arr = new JSONArray(json == null ? "[]" : json);
            String today = dateOffset(0), tomorrow = dateOffset(1);
            int dueToday = 0, dueTomorrow = 0, overdue = 0, grace = 0, graceExpired = 0;
            String firstClient = "";

            for (int n = 0; n < arr.length(); n++) {
                JSONObject o = arr.optJSONObject(n);
                if (o == null) continue;
                String next = o.optString("nextDate", "");
                String due = o.optString("dueDate", "");
                boolean hasCollateral = o.optBoolean("hasCollateral", false);
                if (firstClient.isEmpty()) firstClient = o.optString("client", "");

                if (today.equals(next)) dueToday++;
                else if (tomorrow.equals(next)) dueTomorrow++;
                else if (!next.isEmpty() && next.compareTo(today) < 0) overdue++;

                if (hasCollateral && !due.isEmpty() && due.compareTo(today) < 0) {
                    String graceEnd = addDays(due, 3);
                    if (today.compareTo(graceEnd) <= 0) grace++;
                    else graceExpired++;
                }
            }

            if (dueToday + dueTomorrow + overdue + grace + graceExpired == 0) return;

            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Vencimientos TACA Money", NotificationManager.IMPORTANCE_DEFAULT);
                ch.setDescription("Recordatorios de cobros, atrasos y garantías");
                nm.createNotificationChannel(ch);
            }

            StringBuilder text = new StringBuilder();
            if (dueToday > 0) text.append(dueToday).append(" vence(n) hoy");
            if (overdue > 0) append(text, overdue + " atrasado(s)");
            if (dueTomorrow > 0) append(text, dueTomorrow + " vence(n) mañana");
            if (grace > 0) append(text, grace + " garantía(s) en plazo adicional");
            if (graceExpired > 0) append(text, graceExpired + " garantía(s) con plazo adicional vencido");

            Intent open = new Intent(context, MainActivity.class);
            PendingIntent content = PendingIntent.getActivity(context, 9002, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            android.app.Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? new android.app.Notification.Builder(context, CHANNEL_ID)
                    : new android.app.Notification.Builder(context);
            b.setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("TACA Money · Recordatorios")
                    .setContentText(text.toString())
                    .setStyle(new android.app.Notification.BigTextStyle().bigText(text.toString() + (firstClient.isEmpty() ? "" : ". Revisa la app para ver los clientes.")))
                    .setContentIntent(content)
                    .setAutoCancel(true);
            nm.notify(1901, b.build());
        } catch (Exception ignored) {}
    }

    private static void append(StringBuilder sb, String value) {
        if (sb.length() > 0) sb.append(" · ");
        sb.append(value);
    }

    private static String dateOffset(int days) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, days);
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime());
    }

    private static String addDays(String iso, int days) throws Exception {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        Date d = f.parse(iso);
        Calendar c = Calendar.getInstance();
        c.setTime(d);
        c.add(Calendar.DAY_OF_YEAR, days);
        return f.format(c.getTime());
    }
}
