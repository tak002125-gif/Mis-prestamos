package com.remberto.misprestamos;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONArray;
import org.json.JSONObject;

import com.google.android.gms.auth.api.identity.AuthorizationClient;
import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.ApiException;

public class MainActivity extends Activity {
    private static final int REQ_FILE_CHOOSER = 1001;
    private static final int REQ_SAVE_BACKUP = 1002;
    private static final int REQ_NOTIFICATIONS = 1003;
    private static final int REQ_DRIVE_BACKUP_DEST = 1004;
    private static final int REQ_DRIVE_RESTORE = 1005;
    private static final int REQ_GOOGLE_AUTH = 1006;
    private static final String DRIVE_APPDATA_SCOPE = "https://www.googleapis.com/auth/drive.appdata";
    private static final String DRIVE_BACKUP_NAME = "PrestaPro_Respaldo.json";
    private static final String DRIVE_BACKUP_PREFIX = "PrestaPro_Backup_";
    private static final int DRIVE_BACKUP_KEEP = 5;
    private static final String TAG = "TACA_GOOGLE";
    private static final String LICENSE_PUBLIC_KEY_B64 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwEJVsnE7fPN7b8e5tHPK6n3QLP5aBXXag1+Gxggh1Ln4+YPv4K8zJcb8tjIMfkJ/nS7VURz2vwywQ8n6unh/Z+UyhWvp6L57TweqlRVzlFHoeWTIRgDPMukYAlMuBjOYCCOD86d9+FuCC4LXWt5XOT/BQ6kEPlCp1UppFrKp0zg8TR0KYoqbySBo3bohFaD27py69RMDNvcJ3ipCBl3g0fxXpS28UVjUfq7hTLm1bz9VGwM7RxnG77s3On5hT0clmKSxoxbNpqZCAX9CxPi+Ra1EGpmiarHrbgu1GwBmb8PaGkCOD6aaKSt0GOW3uTO/HTauHt4P8wpuq9ZjxzijbQIDAQAB";
    private static final int GOOGLE_ACTION_NONE = 0;
    private static final int GOOGLE_ACTION_BACKUP = 1;
    private static final int GOOGLE_ACTION_RESTORE = 2;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingBackupJson;
    private String pendingDriveBackupJson;
    private Uri pendingCameraUri;
    private boolean pendingImageChooser;
    private AuthorizationClient authorizationClient;
    private final ExecutorService cloudExecutor = Executors.newSingleThreadExecutor();
    private int pendingGoogleAction = GOOGLE_ACTION_NONE;
    private boolean pendingForceAccountSelection = false;
    private boolean pendingOpenReminders = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Solución ya probada en HyperOS: el contenido comienza debajo de la barra de estado.
        getWindow().setStatusBarColor(Color.rgb(246, 247, 251));
        getWindow().setNavigationBarColor(Color.BLACK);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(246, 247, 251));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(246, 247, 251));

        int statusBarHeight = 0;
        int statusBarId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (statusBarId > 0) statusBarHeight = getResources().getDimensionPixelSize(statusBarId);
        FrameLayout.LayoutParams webParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        );
        webParams.topMargin = statusBarHeight;
        root.addView(webView, webParams);
        setContentView(root);

        authorizationClient = Identity.getAuthorizationClient(this);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);
        webView.setInitialScale(100);

        pendingOpenReminders = getIntent() != null && getIntent().getBooleanExtra("open_reminders", false);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (pendingOpenReminders) {
                    pendingOpenReminders = false;
                    view.evaluateJavascript("if(window.openPendingRemindersFromNotification){window.openPendingRemindersFromNotification();}", null);
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> filePath,
                    FileChooserParams fileChooserParams) {

                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = filePath;
                pendingCameraUri = null;
                pendingImageChooser = false;

                String accept = "";
                try {
                    String[] types = fileChooserParams.getAcceptTypes();
                    if (types != null && types.length > 0 && types[0] != null) accept = types[0];
                } catch (Exception ignored) {}

                try {
                    if (accept.startsWith("image/")) {
                        pendingImageChooser = true;
                        Intent gallery = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        gallery.addCategory(Intent.CATEGORY_OPENABLE);
                        gallery.setType("image/*");

                        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        if (camera.resolveActivity(getPackageManager()) != null) {
                            ContentValues values = new ContentValues();
                            values.put(MediaStore.Images.Media.DISPLAY_NAME, "garantia_" + System.currentTimeMillis() + ".jpg");
                            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PrestaPro/Garantias");
                            }
                            pendingCameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                            if (pendingCameraUri != null) {
                                camera.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
                                camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                Intent chooser = Intent.createChooser(gallery, "Foto de la garantía");
                                chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                                startActivityForResult(chooser, REQ_FILE_CHOOSER);
                                return true;
                            }
                        }
                        startActivityForResult(gallery, REQ_FILE_CHOOSER);
                        return true;
                    }

                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    startActivityForResult(intent, REQ_FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    pendingCameraUri = null;
                    pendingImageChooser = false;
                    Toast.makeText(MainActivity.this, "No se pudo abrir el selector de archivos", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidApp");
        webView.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reprogramar desde preferencias nativas hace que el aviso no dependa de abrir/renderizar el WebView.
        android.content.SharedPreferences prefs = getSharedPreferences("taca_alerts", MODE_PRIVATE);
        NotificationReceiver.schedule(this, prefs.getInt("hour", 14), prefs.getInt("minute", 0));
        if (webView != null) {
            webView.postDelayed(() -> webView.evaluateJavascript("window.refreshNotificationStatus && window.refreshNotificationStatus()", null), 250);
        }
    }

    private boolean notificationsEnabled() {
        try {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return false;
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            return nm == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.N || nm.areNotificationsEnabled();
        } catch (Exception e) {
            return false;
        }
    }

    private boolean exactAlarmAllowed() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        try {
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            return am != null && am.canScheduleExactAlarms();
        } catch (Exception e) {
            return false;
        }
    }

    private void openNotificationSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            startActivity(intent);
        } catch (Exception e) {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATIONS && webView != null) {
            webView.postDelayed(() -> webView.evaluateJavascript("window.refreshNotificationStatus && window.refreshNotificationStatus()", null), 300);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra("open_reminders", false)) {
            if (webView != null) {
                webView.evaluateJavascript("if(window.openPendingRemindersFromNotification){window.openPendingRemindersFromNotification();}", null);
            } else {
                pendingOpenReminders = true;
            }
        }
    }


    private String stableDeviceCode() {
        try {
            String androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            if (androidId == null || androidId.trim().isEmpty()) androidId = "unknown";
            String raw = getPackageName() + "|" + androidId;
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(raw.getBytes(StandardCharsets.UTF_8));
            final char[] HEX = "0123456789ABCDEF".toCharArray();
            StringBuilder hex = new StringBuilder();
            for (int i = 0; i < 10; i++) {
                int v = digest[i] & 0xFF;
                hex.append(HEX[v >>> 4]).append(HEX[v & 0x0F]);
            }
            String s = hex.toString();
            return "PP-" + s.substring(0,4) + "-" + s.substring(4,8) + "-" + s.substring(8,12) + "-" + s.substring(12,16) + "-" + s.substring(16,20);
        } catch (Exception e) {
            return "PP-DEVICE-ERROR";
        }
    }

    private PublicKey licensePublicKey() throws Exception {
        byte[] der = Base64.decode(LICENSE_PUBLIC_KEY_B64, Base64.DEFAULT);
        return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(der));
    }

    private JSONObject verifyLicenseInternal(String code) {
        JSONObject out = new JSONObject();
        try {
            out.put("status", "invalid");
            out.put("message", "Código de licencia no válido.");
            out.put("deviceCode", stableDeviceCode());
            if (code == null) return out;
            String[] parts = code.trim().split("\\.");
            if (parts.length != 3 || !"PP1".equals(parts[0])) return out;

            byte[] payloadBytes = Base64.decode(parts[1], Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
            byte[] signatureBytes = Base64.decode(parts[2], Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);

            Signature verifier = Signature.getInstance("SHA256withRSA");
            verifier.initVerify(licensePublicKey());
            verifier.update(payloadBytes);
            if (!verifier.verify(signatureBytes)) {
                out.put("message", "La firma de la licencia no es válida.");
                return out;
            }

            JSONObject payload = new JSONObject(new String(payloadBytes, StandardCharsets.UTF_8));
            if (payload.optInt("v", 0) != 1) {
                out.put("message", "Versión de licencia no compatible.");
                return out;
            }

            String currentDevice = stableDeviceCode();
            boolean deviceMatch = false;
            String single = payload.optString("device", "");
            if (!single.isEmpty() && currentDevice.equalsIgnoreCase(single)) deviceMatch = true;
            JSONArray devices = payload.optJSONArray("devices");
            if (devices != null) {
                for (int i = 0; i < devices.length(); i++) {
                    if (currentDevice.equalsIgnoreCase(devices.optString(i, ""))) {
                        deviceMatch = true;
                        break;
                    }
                }
            }

            out.put("signatureValid", true);
            out.put("deviceMatch", deviceMatch);
            out.put("licenseId", payload.optString("licenseId", ""));
            out.put("customer", payload.optString("customer", ""));
            out.put("plan", payload.optString("plan", "Estándar"));
            out.put("issuedAt", payload.optLong("issuedAt", 0L));
            out.put("expiresAt", payload.optLong("expiresAt", 0L));
            out.put("maxDevices", Math.max(1, payload.optInt("maxDevices", devices != null ? devices.length() : 1)));
            out.put("permanent", payload.optLong("expiresAt", 0L) <= 0L);

            if (!deviceMatch) {
                out.put("status", "device_mismatch");
                out.put("message", "Esta licencia fue emitida para otro dispositivo.");
                return out;
            }

            long expiresAt = payload.optLong("expiresAt", 0L);
            if (expiresAt > 0L && System.currentTimeMillis() > expiresAt) {
                out.put("status", "expired");
                out.put("message", "La licencia está vencida.");
                return out;
            }

            out.put("status", "active");
            out.put("valid", true);
            out.put("message", "Licencia válida.");
            return out;
        } catch (Exception e) {
            try { out.put("message", "No se pudo interpretar el código de licencia."); } catch (Exception ignored) {}
            return out;
        }
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void exportBackup(String json) {
            runOnUiThread(() -> {
                pendingBackupJson = json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "respaldo-prestapro.json");
                try {
                    startActivityForResult(intent, REQ_SAVE_BACKUP);
                } catch (Exception e) {
                    pendingBackupJson = null;
                    Toast.makeText(MainActivity.this, "No se pudo abrir el guardado de archivos", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void backupToDrive(String json) {
            runOnUiThread(() -> {
                pendingDriveBackupJson = json;
                startGoogleAuthorization(GOOGLE_ACTION_BACKUP, false);
            });
        }

        @JavascriptInterface
        public void chooseDriveBackupLocation(String json) {
            runOnUiThread(() -> {
                pendingDriveBackupJson = json;
                startGoogleAuthorization(GOOGLE_ACTION_BACKUP, true);
            });
        }

        @JavascriptInterface
        public void restoreFromDrive() {
            runOnUiThread(() -> startGoogleAuthorization(GOOGLE_ACTION_RESTORE, false));
        }

        @JavascriptInterface
        public void linkGoogleAccount() {
            runOnUiThread(() -> startGoogleAuthorization(GOOGLE_ACTION_NONE, true));
        }

        @JavascriptInterface
        public String getDeviceCode() {
            return stableDeviceCode();
        }

        @JavascriptInterface
        public String verifyLicense(String licenseCode) {
            return verifyLicenseInternal(licenseCode).toString();
        }

        @JavascriptInterface
        public void copyText(String value) {
            runOnUiThread(() -> {
                try {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("PrestaPro", value == null ? "" : value));
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public String getAppVersion() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "2.8";
            }
        }

        @JavascriptInterface
        public String getCloudBackupStatus() {
            long last = getSharedPreferences("taca_backup", MODE_PRIVATE).getLong("last_backup_at", 0L);
            String email = getSharedPreferences("taca_backup", MODE_PRIVATE).getString("google_email", "");
            boolean linked = email != null && !email.isEmpty();
            JSONObject out = new JSONObject();
            try {
                out.put("linked", linked);
                out.put("email", email == null ? "" : email);
                out.put("lastBackupAt", last);
            } catch (Exception ignored) {}
            return out.toString();
        }

        @JavascriptInterface
        public void shareReceipt(String dataUrl, String fileName) {
            runOnUiThread(() -> {
                try {
                    String base64 = dataUrl;
                    int comma = dataUrl.indexOf(',');
                    if (comma >= 0) base64 = dataUrl.substring(comma + 1);
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);

                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName == null ? "recibo-prestapro.png" : fileName);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PrestaPro");
                        values.put(MediaStore.Images.Media.IS_PENDING, 1);
                    }

                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("No se pudo crear el archivo del recibo");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("No se pudo escribir el recibo");
                        out.write(bytes);
                        out.flush();
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues ready = new ContentValues();
                        ready.put(MediaStore.Images.Media.IS_PENDING, 0);
                        getContentResolver().update(uri, ready, null, null);
                    }

                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("image/png");
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share, "Compartir recibo"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No se pudo compartir el recibo", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void shareToWhatsApp(String dataUrl, String fileName) {
            runOnUiThread(() -> {
                try {
                    String base64 = dataUrl;
                    int comma = dataUrl.indexOf(',');
                    if (comma >= 0) base64 = dataUrl.substring(comma + 1);
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);

                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName == null ? "recordatorio-prestapro.png" : fileName);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PrestaPro");
                        values.put(MediaStore.Images.Media.IS_PENDING, 1);
                    }

                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("No se pudo crear la imagen del recordatorio");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("No se pudo escribir la imagen del recordatorio");
                        out.write(bytes);
                        out.flush();
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues ready = new ContentValues();
                        ready.put(MediaStore.Images.Media.IS_PENDING, 0);
                        getContentResolver().update(uri, ready, null, null);
                    }

                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("image/png");
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                    try {
                        share.setPackage("com.whatsapp");
                        startActivity(share);
                    } catch (Exception normalMissing) {
                        try {
                            share.setPackage("com.whatsapp.w4b");
                            startActivity(share);
                        } catch (Exception businessMissing) {
                            share.setPackage(null);
                            startActivity(Intent.createChooser(share, "Compartir recordatorio"));
                        }
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No se pudo compartir el recordatorio", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public String getNotificationStatus() {
            android.content.SharedPreferences prefs = getSharedPreferences("taca_alerts", MODE_PRIVATE);
            JSONObject out = new JSONObject();
            try {
                out.put("notificationsEnabled", notificationsEnabled());
                out.put("exactAlarmRequired", Build.VERSION.SDK_INT >= Build.VERSION_CODES.S);
                out.put("exactAlarmAllowed", exactAlarmAllowed());
                out.put("nextAlarmAt", prefs.getLong("next_alarm_at", 0L));
                out.put("lastScheduledAt", prefs.getLong("last_scheduled_at", 0L));
                out.put("lastScheduleExact", prefs.getBoolean("last_schedule_exact", false));
                out.put("testAlarmAt", prefs.getLong("test_alarm_at", 0L));
                out.put("lastTestFiredAt", prefs.getLong("last_test_fired_at", 0L));
            } catch (Exception ignored) {}
            return out.toString();
        }

        @JavascriptInterface
        public void reviewNotificationPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
                } else if (!notificationsEnabled()) {
                    openNotificationSettings();
                } else {
                    Toast.makeText(MainActivity.this, "Las notificaciones de PrestaPro están permitidas", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void reviewExactAlarmPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                    Toast.makeText(MainActivity.this, "Este Android no requiere permiso especial de alarmas exactas", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (exactAlarmAllowed()) {
                    Toast.makeText(MainActivity.this, "Las alarmas exactas están permitidas", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    Intent exact = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                    exact.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(exact);
                } catch (Exception e) {
                    Intent details = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
                    startActivity(details);
                }
            });
        }

        @JavascriptInterface
        public void scheduleNotificationTest() {
            runOnUiThread(() -> {
                if (!notificationsEnabled()) {
                    Toast.makeText(MainActivity.this, "Primero permite las notificaciones de PrestaPro", Toast.LENGTH_LONG).show();
                    return;
                }
                long when = NotificationReceiver.scheduleTest(MainActivity.this, 60_000L);
                Toast.makeText(MainActivity.this, "Prueba programada en aproximadamente 1 minuto", Toast.LENGTH_LONG).show();
                if (webView != null) webView.evaluateJavascript("window.refreshNotificationStatus && window.refreshNotificationStatus()", null);
            });
        }

        @JavascriptInterface
        public void syncAlerts(String json, int hour, int minute) {
            getSharedPreferences("taca_alerts", MODE_PRIVATE)
                    .edit()
                    .putString("alerts_json", json == null ? "[]" : json)
                    .putInt("hour", Math.max(0, Math.min(23, hour)))
                    .putInt("minute", Math.max(0, Math.min(59, minute)))
                    .apply();
            NotificationReceiver.schedule(MainActivity.this, hour, minute);
        }
    }

    private void startGoogleAuthorization(int action, boolean forceAccountSelection) {
        pendingGoogleAction = action;
        pendingForceAccountSelection = forceAccountSelection;

        Scope driveScope = new Scope(DRIVE_APPDATA_SCOPE);
        AuthorizationRequest.Builder builder = AuthorizationRequest.builder()
                .setRequestedScopes(Arrays.asList(driveScope));

        if (forceAccountSelection) {
            builder.setPrompt(AuthorizationRequest.Prompt.SELECT_ACCOUNT);
        }

        authorizationClient.authorize(builder.build())
                .addOnSuccessListener(this::handleAuthorizationResult)
                .addOnFailureListener(e -> {
                    pendingGoogleAction = GOOGLE_ACTION_NONE;
                    pendingForceAccountSelection = false;
                    Toast.makeText(this, "No se pudo conectar con Google", Toast.LENGTH_LONG).show();
                    Log.e(TAG, "Authorization failed", e);
                });
    }

    private void handleAuthorizationResult(AuthorizationResult result) {
        if (result == null) {
            Toast.makeText(this, "No se pudo autorizar Google Drive", Toast.LENGTH_SHORT).show();
            return;
        }
        if (result.hasResolution()) {
            PendingIntent pendingIntent = result.getPendingIntent();
            if (pendingIntent == null) {
                Toast.makeText(this, "No se pudo abrir la selección de cuenta", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                startIntentSenderForResult(
                        pendingIntent.getIntentSender(),
                        REQ_GOOGLE_AUTH,
                        null,
                        0, 0, 0
                );
            } catch (IntentSender.SendIntentException e) {
                Toast.makeText(this, "No se pudo abrir Google", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Resolution launch failed", e);
            }
            return;
        }
        handleAuthorizedToken(result);
    }

    private void handleAuthorizedToken(AuthorizationResult result) {
        final String accessToken = result.getAccessToken();
        if (accessToken == null || accessToken.isEmpty()) {
            Toast.makeText(this, "Google no devolvió autorización para Drive", Toast.LENGTH_LONG).show();
            pendingGoogleAction = GOOGLE_ACTION_NONE;
            return;
        }

        final int action = pendingGoogleAction;
        pendingGoogleAction = GOOGLE_ACTION_NONE;
        pendingForceAccountSelection = false;

        cloudExecutor.execute(() -> {
            try {
                String email = fetchGoogleDriveEmail(accessToken);
                if (email != null && !email.isEmpty()) {
                    getSharedPreferences("taca_backup", MODE_PRIVATE)
                            .edit()
                            .putString("google_email", email)
                            .apply();
                }

                if (action == GOOGLE_ACTION_BACKUP) {
                    String json = pendingDriveBackupJson;
                    if (json == null) throw new Exception("No hay datos para respaldar");
                    saveBackupToGoogleDrive(accessToken, json);
                    long now = System.currentTimeMillis();
                    getSharedPreferences("taca_backup", MODE_PRIVATE)
                            .edit()
                            .putLong("last_backup_at", now)
                            .apply();
                    pendingDriveBackupJson = null;
                    runOnUiThread(() -> {
                        notifyBackupSaved(now);
                        Toast.makeText(this, "Copia guardada en la cuenta de Google", Toast.LENGTH_SHORT).show();
                    });
                } else if (action == GOOGLE_ACTION_RESTORE) {
                    String json = readBackupFromGoogleDrive(accessToken);
                    runOnUiThread(() -> {
                        String js = "window.receiveCloudBackup && window.receiveCloudBackup(" + JSONObject.quote(json) + ")";
                        webView.evaluateJavascript(js, null);
                        Toast.makeText(this, "Copia encontrada en Google Drive", Toast.LENGTH_SHORT).show();
                    });
                } else {
                    runOnUiThread(() -> {
                        if (webView != null) webView.evaluateJavascript("window.refreshGoogleBackupStatus && window.refreshGoogleBackupStatus()", null);
                        Toast.makeText(this, "Cuenta de Google vinculada", Toast.LENGTH_SHORT).show();
                    });
                }
            } catch (Exception e) {
                Log.e(TAG, "Drive operation failed", e);
                runOnUiThread(() -> Toast.makeText(this, e.getMessage() == null ? "No se pudo completar la operación en Google Drive" : e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private String fetchGoogleDriveEmail(String accessToken) throws Exception {
        String response = httpRequest(
                "GET",
                "https://www.googleapis.com/drive/v3/about?fields=user(emailAddress)",
                accessToken,
                null,
                null
        );
        JSONObject obj = new JSONObject(response);
        JSONObject user = obj.optJSONObject("user");
        return user == null ? "" : user.optString("emailAddress", "");
    }

    private void saveBackupToGoogleDrive(String accessToken, String json) throws Exception {
        String name = DRIVE_BACKUP_PREFIX + System.currentTimeMillis() + ".json";
        JSONObject metadata = new JSONObject();
        metadata.put("name", name);
        JSONArray parents = new JSONArray();
        parents.put("appDataFolder");
        metadata.put("parents", parents);

        String created = httpRequest(
                "POST",
                "https://www.googleapis.com/drive/v3/files?fields=id",
                accessToken,
                "application/json; charset=UTF-8",
                metadata.toString().getBytes(StandardCharsets.UTF_8)
        );
        String fileId = new JSONObject(created).optString("id", "");
        if (fileId.isEmpty()) throw new Exception("No se pudo crear la copia en Google Drive");

        httpRequest(
                "PATCH",
                "https://www.googleapis.com/upload/drive/v3/files/" + URLEncoder.encode(fileId, "UTF-8") + "?uploadType=media",
                accessToken,
                "application/json; charset=UTF-8",
                json.getBytes(StandardCharsets.UTF_8)
        );
        cleanupOldDriveBackups(accessToken);
    }

    private String readBackupFromGoogleDrive(String accessToken) throws Exception {
        String fileId = findDriveBackupFileId(accessToken);
        if (fileId == null || fileId.isEmpty()) {
            throw new Exception("No se encontró una copia de PrestaPro en esta cuenta");
        }
        return httpRequest(
                "GET",
                "https://www.googleapis.com/drive/v3/files/" + URLEncoder.encode(fileId, "UTF-8") + "?alt=media",
                accessToken,
                null,
                null
        );
    }

    private JSONArray listDriveBackupFiles(String accessToken) throws Exception {
        String q = URLEncoder.encode("'appDataFolder' in parents", "UTF-8");
        String url = "https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&pageSize=50&fields=files(id,name,modifiedTime)&orderBy=modifiedTime%20desc&q=" + q;
        String response = httpRequest("GET", url, accessToken, null, null);
        JSONArray all = new JSONObject(response).optJSONArray("files");
        JSONArray backups = new JSONArray();
        if (all != null) {
            for (int i = 0; i < all.length(); i++) {
                JSONObject f = all.getJSONObject(i);
                String n = f.optString("name", "");
                if (n.startsWith(DRIVE_BACKUP_PREFIX) || n.equals(DRIVE_BACKUP_NAME) || n.equals("TACA_Money_Respaldo.json")) backups.put(f);
            }
        }
        return backups;
    }

    private String findDriveBackupFileId(String accessToken) throws Exception {
        JSONArray files = listDriveBackupFiles(accessToken);
        if (files.length() == 0) return null;
        return files.getJSONObject(0).optString("id", null);
    }

    private void cleanupOldDriveBackups(String accessToken) {
        try {
            JSONArray files = listDriveBackupFiles(accessToken);
            int keptGenerations = 0;
            for (int i = 0; i < files.length(); i++) {
                JSONObject f = files.getJSONObject(i);
                String name = f.optString("name", "");
                if (!name.startsWith(DRIVE_BACKUP_PREFIX)) continue;
                keptGenerations++;
                if (keptGenerations > DRIVE_BACKUP_KEEP) {
                    String id = f.optString("id", "");
                    if (!id.isEmpty()) {
                        httpRequest("DELETE",
                                "https://www.googleapis.com/drive/v3/files/" + URLEncoder.encode(id, "UTF-8"),
                                accessToken, null, null);
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private String httpRequest(String method, String urlText, String accessToken, String contentType, byte[] body) throws Exception {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlText);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod(method);
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(30000);
            conn.setRequestProperty("Authorization", "Bearer " + accessToken);
            conn.setRequestProperty("Accept", "application/json");
            if (contentType != null) conn.setRequestProperty("Content-Type", contentType);

            if (body != null) {
                conn.setDoOutput(true);
                conn.setFixedLengthStreamingMode(body.length);
                try (OutputStream out = conn.getOutputStream()) {
                    out.write(body);
                    out.flush();
                }
            }

            int code = conn.getResponseCode();
            InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
            StringBuilder sb = new StringBuilder();
            if (stream != null) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) sb.append(line);
                }
            }

            if (code < 200 || code >= 300) {
                String detail = sb.toString();
                if (code == 401 || code == 403) throw new Exception("Google Drive rechazó el acceso. Revisa la cuenta y los permisos.");
                throw new Exception("Error de Google Drive (" + code + ")" + (detail.isEmpty() ? "" : ": " + detail));
            }
            return sb.toString();
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private void writeBackupToUri(Uri uri, String json) throws Exception {
        try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
            if (out == null) throw new Exception("No se pudo abrir el respaldo");
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.flush();
        }
    }

    private String readTextFromUri(Uri uri) throws Exception {
        StringBuilder sb = new StringBuilder();
        InputStream input = getContentResolver().openInputStream(uri);
        if (input == null) throw new Exception("No se pudo abrir el respaldo");
        try (InputStream in = input;
             BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private void notifyBackupSaved(long timestamp) {
        if (webView != null) {
            webView.evaluateJavascript("window.onCloudBackupSaved && window.onCloudBackupSaved(" + timestamp + ")", null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_FILE_CHOOSER) {
            if (filePathCallback != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK) {
                    Uri chosen = null;
                    if (data != null && data.getData() != null) chosen = data.getData();
                    else if (pendingImageChooser && pendingCameraUri != null) chosen = pendingCameraUri;
                    if (chosen != null) result = new Uri[]{chosen};
                }

                if (pendingImageChooser && pendingCameraUri != null && (result == null || result[0] == null || !pendingCameraUri.equals(result[0]))) {
                    try { getContentResolver().delete(pendingCameraUri, null, null); } catch (Exception ignored) {}
                }
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
            pendingCameraUri = null;
            pendingImageChooser = false;
            return;
        }

        if (requestCode == REQ_GOOGLE_AUTH) {
            if (resultCode == RESULT_OK && data != null) {
                try {
                    AuthorizationResult result = authorizationClient.getAuthorizationResultFromIntent(data);
                    handleAuthorizedToken(result);
                } catch (ApiException e) {
                    Toast.makeText(this, "No se pudo autorizar la cuenta de Google", Toast.LENGTH_LONG).show();
                    Log.e(TAG, "Authorization result failed", e);
                }
            } else {
                pendingGoogleAction = GOOGLE_ACTION_NONE;
                pendingDriveBackupJson = null;
                Toast.makeText(this, "Operación cancelada", Toast.LENGTH_SHORT).show();
            }
            return;
        }

        if (requestCode == REQ_SAVE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) {
                        out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                        out.flush();
                        Toast.makeText(this, "Respaldo guardado", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "No se pudo guardar el respaldo", Toast.LENGTH_SHORT).show();
                }
            }
            pendingBackupJson = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        cloudExecutor.shutdownNow();
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidApp");
            webView.destroy();
        }
        super.onDestroy();
    }
}
