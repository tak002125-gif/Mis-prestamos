package com.remberto.misprestamos;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQ_FILE_CHOOSER = 1001;
    private static final int REQ_SAVE_BACKUP = 1002;
    private static final int REQ_NOTIFICATIONS = 1003;
    private static final int REQ_DRIVE_BACKUP_DEST = 1004;
    private static final int REQ_DRIVE_RESTORE = 1005;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingBackupJson;
    private String pendingDriveBackupJson;
    private Uri pendingCameraUri;
    private boolean pendingImageChooser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Solución ya probada en HyperOS: el contenido comienza debajo de la barra de estado.
        getWindow().setStatusBarColor(Color.rgb(246, 247, 251));
        getWindow().setNavigationBarColor(Color.BLACK);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(246, 247, 251));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(246, 247, 251));

        int statusBarHeight = 0;
        int statusBarId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (statusBarId > 0) statusBarHeight = getResources().getDimensionPixelSize(statusBarId);
        FrameLayout.LayoutParams webParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        );
        webParams.topMargin = statusBarHeight;
        root.addView(webView, webParams);
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);
        webView.setInitialScale(100);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> filePath,
                    FileChooserParams fileChooserParams) {

                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = filePath;
                pendingCameraUri = null;
                pendingImageChooser = false;

                String accept = "";
                try {
                    String[] types = fileChooserParams.getAcceptTypes();
                    if (types != null && types.length > 0 && types[0] != null) accept = types[0];
                } catch (Exception ignored) {}

                try {
                    if (accept.startsWith("image/")) {
                        pendingImageChooser = true;
                        Intent gallery = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        gallery.addCategory(Intent.CATEGORY_OPENABLE);
                        gallery.setType("image/*");

                        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        if (camera.resolveActivity(getPackageManager()) != null) {
                            ContentValues values = new ContentValues();
                            values.put(MediaStore.Images.Media.DISPLAY_NAME, "garantia_" + System.currentTimeMillis() + ".jpg");
                            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/TACA Money/Garantias");
                            }
                            pendingCameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                            if (pendingCameraUri != null) {
                                camera.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
                                camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                Intent chooser = Intent.createChooser(gallery, "Foto de la garantía");
                                chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                                startActivityForResult(chooser, REQ_FILE_CHOOSER);
                                return true;
                            }
                        }
                        startActivityForResult(gallery, REQ_FILE_CHOOSER);
                        return true;
                    }

                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    startActivityForResult(intent, REQ_FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    pendingCameraUri = null;
                    pendingImageChooser = false;
                    Toast.makeText(MainActivity.this, "No se pudo abrir el selector de archivos", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidApp");
        webView.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void exportBackup(String json) {
            runOnUiThread(() -> {
                pendingBackupJson = json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "respaldo-taca-money.json");
                try {
                    startActivityForResult(intent, REQ_SAVE_BACKUP);
                } catch (Exception e) {
                    pendingBackupJson = null;
                    Toast.makeText(MainActivity.this, "No se pudo abrir el guardado de archivos", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void backupToDrive(String json) {
            runOnUiThread(() -> {
                pendingDriveBackupJson = json;
                String savedUri = getSharedPreferences("taca_backup", MODE_PRIVATE).getString("drive_uri", "");
                if (savedUri != null && !savedUri.isEmpty()) {
                    try {
                        writeBackupToUri(Uri.parse(savedUri), json);
                        long now = System.currentTimeMillis();
                        getSharedPreferences("taca_backup", MODE_PRIVATE).edit().putLong("last_backup_at", now).apply();
                        notifyBackupSaved(now);
                        Toast.makeText(MainActivity.this, "Copia actualizada en Google Drive", Toast.LENGTH_SHORT).show();
                        pendingDriveBackupJson = null;
                        return;
                    } catch (Exception ignored) {
                        getSharedPreferences("taca_backup", MODE_PRIVATE).edit().remove("drive_uri").apply();
                    }
                }
                chooseDriveBackupDestination();
            });
        }

        @JavascriptInterface
        public void chooseDriveBackupLocation(String json) {
            runOnUiThread(() -> {
                pendingDriveBackupJson = json;
                chooseDriveBackupDestination();
            });
        }

        @JavascriptInterface
        public void restoreFromDrive() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                try {
                    startActivityForResult(intent, REQ_DRIVE_RESTORE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No se pudo abrir Google Drive", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public String getCloudBackupStatus() {
            long last = getSharedPreferences("taca_backup", MODE_PRIVATE).getLong("last_backup_at", 0L);
            String uri = getSharedPreferences("taca_backup", MODE_PRIVATE).getString("drive_uri", "");
            boolean linked = uri != null && !uri.isEmpty();
            return "{\"linked\":" + linked + ",\"lastBackupAt\":" + last + "}";
        }

        @JavascriptInterface
        public void shareReceipt(String dataUrl, String fileName) {
            runOnUiThread(() -> {
                try {
                    String base64 = dataUrl;
                    int comma = dataUrl.indexOf(',');
                    if (comma >= 0) base64 = dataUrl.substring(comma + 1);
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);

                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName == null ? "recibo-taca-money.png" : fileName);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/TACA Money");
                        values.put(MediaStore.Images.Media.IS_PENDING, 1);
                    }

                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("No se pudo crear el archivo del recibo");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("No se pudo escribir el recibo");
                        out.write(bytes);
                        out.flush();
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues ready = new ContentValues();
                        ready.put(MediaStore.Images.Media.IS_PENDING, 0);
                        getContentResolver().update(uri, ready, null, null);
                    }

                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("image/png");
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share, "Compartir recibo"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No se pudo compartir el recibo", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void syncAlerts(String json, int hour, int minute) {
            getSharedPreferences("taca_alerts", MODE_PRIVATE)
                    .edit()
                    .putString("alerts_json", json == null ? "[]" : json)
                    .putInt("hour", Math.max(0, Math.min(23, hour)))
                    .putInt("minute", Math.max(0, Math.min(59, minute)))
                    .apply();
            NotificationReceiver.schedule(MainActivity.this, hour, minute);
        }
    }

    private void chooseDriveBackupDestination() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "TACA_Money_Respaldo.json");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQ_DRIVE_BACKUP_DEST);
        } catch (Exception e) {
            pendingDriveBackupJson = null;
            Toast.makeText(this, "No se pudo abrir Google Drive", Toast.LENGTH_SHORT).show();
        }
    }

    private void writeBackupToUri(Uri uri, String json) throws Exception {
        try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
            if (out == null) throw new Exception("No se pudo abrir el respaldo");
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.flush();
        }
    }

    private String readTextFromUri(Uri uri) throws Exception {
        StringBuilder sb = new StringBuilder();
        InputStream input = getContentResolver().openInputStream(uri);
        if (input == null) throw new Exception("No se pudo abrir el respaldo");
        try (InputStream in = input;
             BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private void notifyBackupSaved(long timestamp) {
        if (webView != null) {
            webView.evaluateJavascript("window.onCloudBackupSaved && window.onCloudBackupSaved(" + timestamp + ")", null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_FILE_CHOOSER) {
            if (filePathCallback != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK) {
                    Uri chosen = null;
                    if (data != null && data.getData() != null) chosen = data.getData();
                    else if (pendingImageChooser && pendingCameraUri != null) chosen = pendingCameraUri;
                    if (chosen != null) result = new Uri[]{chosen};
                }

                if (pendingImageChooser && pendingCameraUri != null && (result == null || result[0] == null || !pendingCameraUri.equals(result[0]))) {
                    try { getContentResolver().delete(pendingCameraUri, null, null); } catch (Exception ignored) {}
                }
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
            pendingCameraUri = null;
            pendingImageChooser = false;
            return;
        }

        if (requestCode == REQ_DRIVE_BACKUP_DEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingDriveBackupJson != null) {
                Uri uri = data.getData();
                try {
                    int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    try { getContentResolver().takePersistableUriPermission(uri, flags); } catch (Exception ignored) {}
                    writeBackupToUri(uri, pendingDriveBackupJson);
                    long now = System.currentTimeMillis();
                    getSharedPreferences("taca_backup", MODE_PRIVATE).edit()
                            .putString("drive_uri", uri.toString())
                            .putLong("last_backup_at", now)
                            .apply();
                    notifyBackupSaved(now);
                    Toast.makeText(this, "Copia guardada en Google Drive", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "No se pudo guardar la copia", Toast.LENGTH_SHORT).show();
                }
            }
            pendingDriveBackupJson = null;
            return;
        }

        if (requestCode == REQ_DRIVE_RESTORE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                try {
                    int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    try { getContentResolver().takePersistableUriPermission(uri, flags); } catch (Exception ignored) {}
                    String json = readTextFromUri(uri);
                    getSharedPreferences("taca_backup", MODE_PRIVATE).edit().putString("drive_uri", uri.toString()).apply();
                    String js = "window.receiveCloudBackup && window.receiveCloudBackup(" + JSONObject.quote(json) + ")";
                    webView.evaluateJavascript(js, null);
                } catch (Exception e) {
                    Toast.makeText(this, "No se pudo restaurar la copia", Toast.LENGTH_SHORT).show();
                }
            }
            return;
        }

        if (requestCode == REQ_SAVE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) {
                        out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                        out.flush();
                        Toast.makeText(this, "Respaldo guardado", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "No se pudo guardar el respaldo", Toast.LENGTH_SHORT).show();
                }
            }
            pendingBackupJson = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidApp");
            webView.destroy();
        }
        super.onDestroy();
    }
}
