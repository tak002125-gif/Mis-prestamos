package com.remberto.misprestamos;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.NotificationManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.InputFilter;
import android.text.InputType;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.Gravity;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.charset.Charset;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SecureRandom;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

import org.json.JSONArray;
import org.json.JSONObject;

import androidx.core.content.FileProvider;
import androidx.core.content.ContextCompat;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.auth.api.identity.AuthorizationClient;
import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.ApiException;
import com.google.android.billingclient.api.AcknowledgePurchaseParams;
import com.google.android.billingclient.api.BillingClient;
import com.google.android.billingclient.api.BillingClientStateListener;
import com.google.android.billingclient.api.BillingFlowParams;
import com.google.android.billingclient.api.BillingResult;
import com.google.android.billingclient.api.PendingPurchasesParams;
import com.google.android.billingclient.api.ProductDetails;
import com.google.android.billingclient.api.Purchase;
import com.google.android.billingclient.api.QueryProductDetailsParams;
import com.google.android.billingclient.api.QueryProductDetailsResult;
import com.google.android.billingclient.api.QueryPurchasesParams;

public class MainActivity extends FragmentActivity {
    private static final int REQ_FILE_CHOOSER = 1001;
    private static final int REQ_SAVE_BACKUP = 1002;
    private static final int REQ_NOTIFICATIONS = 1003;
    private static final int REQ_DRIVE_BACKUP_DEST = 1004;
    private static final int REQ_DRIVE_RESTORE = 1005;
    private static final int REQ_GOOGLE_AUTH = 1006;
    private static final int REQ_SAVE_RECEIPT_PDF = 1007;
    private static final int REQ_BLUETOOTH_CONNECT = 1008;
    private static final int REQ_SAVE_FINANCE_XLSX = 1009;
    private static final int REQ_SAVE_FINANCE_CSV = 1010;
    private static final String SECURITY_PREFS = "prestapro_security_v1";
    private static final String SECURITY_PIN_HASH = "pin_hash";
    private static final String SECURITY_PIN_SALT = "pin_salt";
    private static final String SECURITY_BIOMETRIC = "biometric_enabled";
    private static final String SECURITY_AUTO_LOCK = "auto_lock_minutes";
    private static final String BILLING_PREFS = "prestapro_play_billing_v1";
    private static final String PLAY_PRODUCT_ANNUAL = "prestapro_anual";
    private static final String PLAY_PRODUCT_PERMANENT = "prestapro_permanente";
    private static final UUID THERMAL_SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final String DRIVE_APPDATA_SCOPE = "https://www.googleapis.com/auth/drive.appdata";
    private static final String DRIVE_BACKUP_NAME = "PrestaPro_Respaldo.json";
    private static final String DRIVE_BACKUP_PREFIX = "PrestaPro_Backup_";
    private static final int DRIVE_BACKUP_KEEP = 5;
    private static final String TAG = "TACA_GOOGLE";
    private static final String LICENSE_PUBLIC_KEY_ADMIN_B64 = "MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAveK2oqbClMelvhSckAv35q3nRtDymx2LNjzCm2AgChBAv1sm9EuYaTFq6CUN3A3Jf5nJEnJV2aWCgdNT64oWPKqOBg2IWBB8qYMJmvmyRzHdxHHKsCFF55lvgw64BgtSeD3QHlPJ5QkdrQ/uIn8WNBNxhOyei2wezwEGd5krIQpIkxklPCMgRjOoREu9cx8EMIzDh21e6sgVgGuXMOmMM4teLQfcvVfwt6wEubsOmb0wZZPRe/eWaOkPIrTfXIA/oeKq6t0BxrOfXYHVNq4LH30f9uHu7ybfdgduJEbrEhI67aVW2OywBf8ufgXhSLsrWTn8H3wqemZHD0vwgT3E6lzvNdBKxtyG9ABJI/m5xcrJTUp4/SWVPESYTS6QxzHuf0AY7WeDe5tQaMTXHpE7VDvMjWI+ITCkJYIRX4/jjNvCcqsLbZMxN7ysIrdfxd++JYEDZGY9+JEwG2yeS/twrrE0wBj8AKFg0T/h57eghv8vYUz5Qkg6x1Fd4K0jJG6TAgMBAAE=";
    private static final String LICENSE_PUBLIC_KEY_LEGACY_B64 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwEJVsnE7fPN7b8e5tHPK6n3QLP5aBXXag1+Gxggh1Ln4+YPv4K8zJcb8tjIMfkJ/nS7VURz2vwywQ8n6unh/Z+UyhWvp6L57TweqlRVzlFHoeWTIRgDPMukYAlMuBjOYCCOD86d9+FuCC4LXWt5XOT/BQ6kEPlCp1UppFrKp0zg8TR0KYoqbySBo3bohFaD27py69RMDNvcJ3ipCBl3g0fxXpS28UVjUfq7hTLm1bz9VGwM7RxnG77s3On5hT0clmKSxoxbNpqZCAX9CxPi+Ra1EGpmiarHrbgu1GwBmb8PaGkCOD6aaKSt0GOW3uTO/HTauHt4P8wpuq9ZjxzijbQIDAQAB";
    private static final String LICENSE_PUBLIC_KEY_V2_B64 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1H3MTaOubr0PIUlgKupvY9+I1ig/ThCwzMFmMeXUJqhH/Ck13u9lS6Cbn8DqYyr2p9PkOwkOBLMj/cz1UmMdDSl9+OQGmZWaag7VB/g8vPxH0bggHqDZMevWbEsUMnCcrVrz9W60NHpGUY4rahHR03Z8Vqnh9LGfNGGPzvHPUs3B2dQjvz9vFSZ0NGnxrwEh7MG2FewOy4chT661WPPMu1YV40vCXcyrjtPEcixLyPDc0lFBkf7jKZD+paxVv8LFQZax1Zz28a/z6VKNmr4JRuDImsW4lOZt5nKhcJqpYQwUmd+aeeQ9WbBYr6JvuQG/L9vVyRCqqu6XyKIPuzqv7QIDAQAB";
    private static final int GOOGLE_ACTION_NONE = 0;
    private static final int GOOGLE_ACTION_BACKUP = 1;
    private static final int GOOGLE_ACTION_RESTORE = 2;

    private WebView webView;
    private FrameLayout rootContainer;
    private View securityOverlay;
    private EditText securityPinInput;
    private TextView securityErrorText;
    private Button securityBiometricButton;
    private boolean securityLocked = false;
    private boolean biometricPromptVisible = false;
    private long securityBackgroundAt = 0L;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingBackupJson;
    private String pendingDriveBackupJson;
    private Uri pendingCameraUri;
    private boolean pendingImageChooser;
    private AuthorizationClient authorizationClient;
    private final ExecutorService cloudExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService receiptExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService thermalExecutor = Executors.newSingleThreadExecutor();
    private byte[] pendingReceiptPdfBytes;
    private String pendingReceiptPdfName;
    private byte[] pendingFinanceBytes;
    private String pendingFinanceName;
    private String pendingFinanceMime;
    private int pendingGoogleAction = GOOGLE_ACTION_NONE;
    private boolean pendingForceAccountSelection = false;
    private boolean pendingOpenReminders = false;
    private BillingClient billingClient;
    private ProductDetails playAnnualDetails;
    private ProductDetails playPermanentDetails;
    private ProductDetails.SubscriptionOfferDetails playAnnualOffer;
    private ProductDetails.OneTimePurchaseOfferDetails playPermanentOffer;
    private boolean playBillingReady = false;
    private String pendingPlayPlan = null;
    private int playPurchaseQueryPending = 0;
    private boolean playPurchaseQueryHadError = false;
    private boolean playPurchaseRestoreRequested = false;
    private final List<Purchase> playLatestInApp = new ArrayList<>();
    private final List<Purchase> playLatestSubs = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Solución ya probada en HyperOS: el contenido comienza debajo de la barra de estado.
        getWindow().setStatusBarColor(Color.rgb(246, 247, 251));
        getWindow().setNavigationBarColor(Color.BLACK);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        FrameLayout root = new FrameLayout(this);
        rootContainer = root;
        root.setBackgroundColor(Color.rgb(246, 247, 251));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(246, 247, 251));

        int statusBarHeight = 0;
        int statusBarId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (statusBarId > 0) statusBarHeight = getResources().getDimensionPixelSize(statusBarId);
        FrameLayout.LayoutParams webParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        );
        webParams.topMargin = statusBarHeight;
        root.addView(webView, webParams);
        setContentView(root);

        authorizationClient = Identity.getAuthorizationClient(this);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);
        webView.setInitialScale(100);

        pendingOpenReminders = getIntent() != null && getIntent().getBooleanExtra("open_reminders", false);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (pendingOpenReminders) {
                    pendingOpenReminders = false;
                    view.evaluateJavascript("if(window.openPendingRemindersFromNotification){window.openPendingRemindersFromNotification();}", null);
                }
                view.evaluateJavascript("if(window.processPendingAutoCashClose){window.processPendingAutoCashClose();}", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> filePath,
                    FileChooserParams fileChooserParams) {

                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = filePath;
                pendingCameraUri = null;
                pendingImageChooser = false;

                String accept = "";
                try {
                    String[] types = fileChooserParams.getAcceptTypes();
                    if (types != null && types.length > 0 && types[0] != null) accept = types[0];
                } catch (Exception ignored) {}

                try {
                    if (accept.startsWith("image/")) {
                        pendingImageChooser = true;
                        Intent gallery = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        gallery.addCategory(Intent.CATEGORY_OPENABLE);
                        gallery.setType("image/*");

                        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        if (camera.resolveActivity(getPackageManager()) != null) {
                            ContentValues values = new ContentValues();
                            values.put(MediaStore.Images.Media.DISPLAY_NAME, "garantia_" + System.currentTimeMillis() + ".jpg");
                            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PrestaPro/Garantias");
                            }
                            pendingCameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                            if (pendingCameraUri != null) {
                                camera.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
                                camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                Intent chooser = Intent.createChooser(gallery, "Foto de la garantía");
                                chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                                startActivityForResult(chooser, REQ_FILE_CHOOSER);
                                return true;
                            }
                        }
                        startActivityForResult(gallery, REQ_FILE_CHOOSER);
                        return true;
                    }

                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    startActivityForResult(intent, REQ_FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    pendingCameraUri = null;
                    pendingImageChooser = false;
                    Toast.makeText(MainActivity.this, "No se pudo abrir el selector de archivos", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidApp");
        webView.loadUrl("file:///android_asset/index.html");
        setupPlayBilling();

        if (securityPinConfigured()) {
            securityLocked = true;
            webView.setVisibility(View.INVISIBLE);
            webView.postDelayed(() -> showSecurityLock(true), 120);
        }

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!securityPinConfigured() || securityLocked) return;
        if (securityBackgroundAt <= 0L) return;
        long elapsed = Math.max(0L, System.currentTimeMillis() - securityBackgroundAt);
        int minutes = securityPrefs().getInt(SECURITY_AUTO_LOCK, 1);
        if (minutes <= 0 || elapsed >= minutes * 60_000L) {
            showSecurityLock(true);
        }
        securityBackgroundAt = 0L;
    }

    @Override
    protected void onStop() {
        if (securityPinConfigured() && !securityLocked) {
            securityBackgroundAt = System.currentTimeMillis();
        }
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reprogramar desde preferencias nativas hace que el aviso no dependa de abrir/renderizar el WebView.
        android.content.SharedPreferences prefs = getSharedPreferences("taca_alerts", MODE_PRIVATE);
        if (prefs.getBoolean("alerts_enabled", false)) {
            NotificationReceiver.schedule(this, prefs.getInt("hour", 14), prefs.getInt("minute", 0));
        } else {
            NotificationReceiver.cancelAll(this);
        }
        android.content.SharedPreferences cashPrefs = getSharedPreferences(AutoCashCloseReceiver.PREFS, MODE_PRIVATE);
        if (cashPrefs.getBoolean("enabled", false)) {
            AutoCashCloseReceiver.schedule(this, cashPrefs.getInt("hour", 22), cashPrefs.getInt("minute", 0), cashPrefs.getInt("warn_minutes", 15));
        } else {
            AutoCashCloseReceiver.cancel(this);
        }
        if (webView != null) {
            webView.postDelayed(() -> {
                webView.evaluateJavascript("window.refreshNotificationStatus && window.refreshNotificationStatus()", null);
                webView.evaluateJavascript("window.processPendingAutoCashClose && window.processPendingAutoCashClose()", null);
                webView.evaluateJavascript("window.refreshPlayBillingStatus && window.refreshPlayBillingStatus()", null);
            }, 250);
        }
        if (playBillingReady) refreshPlayPurchases(false);
        else connectPlayBilling();
    }

    private android.content.SharedPreferences playBillingPrefs() {
        return getSharedPreferences(BILLING_PREFS, MODE_PRIVATE);
    }

    private boolean installedFromPlayStore() {
        try {
            String installer;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                installer = getPackageManager().getInstallSourceInfo(getPackageName()).getInstallingPackageName();
            } else {
                installer = getPackageManager().getInstallerPackageName(getPackageName());
            }
            return "com.android.vending".equals(installer);
        } catch (Exception e) {
            return false;
        }
    }

    private void setupPlayBilling() {
        if (billingClient != null) return;
        try {
            PendingPurchasesParams pendingParams = PendingPurchasesParams.newBuilder()
                    .enableOneTimeProducts()
                    .build();
            billingClient = BillingClient.newBuilder(this)
                    .setListener((billingResult, purchases) -> {
                        int code = billingResult.getResponseCode();
                        if (code == BillingClient.BillingResponseCode.OK && purchases != null) {
                            processNewPlayPurchases(purchases);
                        } else if (code == BillingClient.BillingResponseCode.USER_CANCELED) {
                            notifyPlayBillingJs("Compra cancelada", false);
                        } else {
                            notifyPlayBillingJs(playBillingMessage(billingResult), false);
                        }
                    })
                    .enablePendingPurchases(pendingParams)
                    .enableAutoServiceReconnection()
                    .build();
            connectPlayBilling();
        } catch (Exception e) {
            Log.e(TAG, "Play Billing init failed", e);
            notifyPlayBillingJs("Google Play Billing no está disponible en este dispositivo", false);
        }
    }

    private void connectPlayBilling() {
        if (billingClient == null) return;
        if (billingClient.isReady()) {
            playBillingReady = true;
            queryPlayProducts();
            return;
        }
        try {
            billingClient.startConnection(new BillingClientStateListener() {
                @Override public void onBillingSetupFinished(BillingResult billingResult) {
                    playBillingReady = billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK;
                    if (playBillingReady) {
                        queryPlayProducts();
                        refreshPlayPurchases(false);
                        if (pendingPlayPlan != null) {
                            String plan = pendingPlayPlan;
                            pendingPlayPlan = null;
                            launchPlayPurchase(plan);
                        }
                    } else {
                        notifyPlayBillingJs(playBillingMessage(billingResult), false);
                    }
                }
                @Override public void onBillingServiceDisconnected() {
                    playBillingReady = false;
                    notifyPlayBillingJs("Conexión con Google Play interrumpida. Se reintentará automáticamente.", false);
                }
            });
        } catch (Exception e) {
            playBillingReady = false;
            notifyPlayBillingJs("No se pudo conectar con Google Play", false);
        }
    }

    private String playBillingMessage(BillingResult result) {
        if (result == null) return "No se pudo conectar con Google Play";
        switch (result.getResponseCode()) {
            case BillingClient.BillingResponseCode.BILLING_UNAVAILABLE:
                return installedFromPlayStore() ? "Google Play Billing no está disponible en este dispositivo" : "Las compras se habilitan al instalar PrestaPro desde Google Play";
            case BillingClient.BillingResponseCode.ITEM_UNAVAILABLE:
                return "Los planes todavía no están disponibles en Google Play";
            case BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED:
                return "Este plan ya pertenece a tu cuenta de Google Play. Usa Restaurar compra.";
            case BillingClient.BillingResponseCode.NETWORK_ERROR:
            case BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE:
                return "Sin conexión con Google Play. Intenta nuevamente.";
            case BillingClient.BillingResponseCode.USER_CANCELED:
                return "Compra cancelada";
            default:
                String d = result.getDebugMessage();
                return (d == null || d.trim().isEmpty()) ? "Google Play no pudo completar la operación" : d;
        }
    }

    private void queryPlayProducts() {
        if (billingClient == null || !billingClient.isReady()) return;
        try {
            List<QueryProductDetailsParams.Product> products = new ArrayList<>();
            products.add(QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(PLAY_PRODUCT_ANNUAL)
                    .setProductType(BillingClient.ProductType.SUBS)
                    .build());
            products.add(QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(PLAY_PRODUCT_PERMANENT)
                    .setProductType(BillingClient.ProductType.INAPP)
                    .build());
            QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder().setProductList(products).build();
            billingClient.queryProductDetailsAsync(params, (billingResult, result) -> {
                if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.OK || result == null) {
                    notifyPlayBillingJs(playBillingMessage(billingResult), false);
                    return;
                }
                playAnnualDetails = null;
                playPermanentDetails = null;
                playAnnualOffer = null;
                playPermanentOffer = null;
                for (ProductDetails detail : result.getProductDetailsList()) {
                    if (PLAY_PRODUCT_ANNUAL.equals(detail.getProductId())) {
                        playAnnualDetails = detail;
                        List<ProductDetails.SubscriptionOfferDetails> offers = detail.getSubscriptionOfferDetails();
                        if (offers != null && !offers.isEmpty()) {
                            for (ProductDetails.SubscriptionOfferDetails offer : offers) {
                                if (offer.getOfferId() == null) { playAnnualOffer = offer; break; }
                            }
                            if (playAnnualOffer == null) playAnnualOffer = offers.get(0);
                        }
                    } else if (PLAY_PRODUCT_PERMANENT.equals(detail.getProductId())) {
                        playPermanentDetails = detail;
                        playPermanentOffer = detail.getOneTimePurchaseOfferDetails();
                        if (playPermanentOffer == null) {
                            List<ProductDetails.OneTimePurchaseOfferDetails> offers = detail.getOneTimePurchaseOfferDetailsList();
                            if (offers != null && !offers.isEmpty()) playPermanentOffer = offers.get(0);
                        }
                    }
                }
                notifyPlayBillingJs("", false);
            });
        } catch (Exception e) {
            Log.e(TAG, "Play product query failed", e);
            notifyPlayBillingJs("No se pudieron consultar los planes de Google Play", false);
        }
    }

    private String annualPrice() {
        try {
            if (playAnnualOffer == null) return "";
            List<ProductDetails.PricingPhase> phases = playAnnualOffer.getPricingPhases().getPricingPhaseList();
            if (phases == null || phases.isEmpty()) return "";
            return phases.get(phases.size() - 1).getFormattedPrice();
        } catch (Exception e) { return ""; }
    }

    private String permanentPrice() {
        try { return playPermanentOffer == null ? "" : playPermanentOffer.getFormattedPrice(); }
        catch (Exception e) { return ""; }
    }

    private void launchPlayPurchase(String plan) {
        runOnUiThread(() -> {
            if (billingClient == null || !billingClient.isReady()) {
                pendingPlayPlan = plan;
                connectPlayBilling();
                Toast.makeText(MainActivity.this, "Conectando con Google Play…", Toast.LENGTH_SHORT).show();
                return;
            }
            ProductDetails detail;
            String offerToken = "";
            if ("annual".equals(plan)) {
                detail = playAnnualDetails;
                if (playAnnualOffer != null) offerToken = playAnnualOffer.getOfferToken();
            } else {
                detail = playPermanentDetails;
                if (playPermanentOffer != null) offerToken = playPermanentOffer.getOfferToken();
            }
            if (detail == null) {
                queryPlayProducts();
                Toast.makeText(MainActivity.this, installedFromPlayStore() ? "El plan todavía no está disponible en Google Play" : "Instala PrestaPro desde Google Play para comprar este plan", Toast.LENGTH_LONG).show();
                notifyPlayBillingJs(installedFromPlayStore() ? "El plan todavía no está disponible en Google Play" : "Las compras se habilitan al instalar PrestaPro desde Google Play", false);
                return;
            }
            try {
                BillingFlowParams.ProductDetailsParams.Builder pd = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(detail);
                if (offerToken != null && !offerToken.isEmpty()) pd.setOfferToken(offerToken);
                BillingFlowParams flow = BillingFlowParams.newBuilder()
                        .setProductDetailsParamsList(Collections.singletonList(pd.build()))
                        .build();
                BillingResult result = billingClient.launchBillingFlow(MainActivity.this, flow);
                if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                    notifyPlayBillingJs(playBillingMessage(result), false);
                }
            } catch (Exception e) {
                Log.e(TAG, "Play purchase flow failed", e);
                notifyPlayBillingJs("No se pudo abrir la compra de Google Play", false);
            }
        });
    }

    private void processNewPlayPurchases(List<Purchase> purchases) {
        boolean hasPurchased = false;
        boolean hasPending = false;
        for (Purchase purchase : purchases) {
            if (purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                hasPurchased = true;
                acknowledgePlayPurchaseIfNeeded(purchase);
            } else if (purchase.getPurchaseState() == Purchase.PurchaseState.PENDING) {
                hasPending = true;
            }
        }
        if (hasPurchased) {
            refreshPlayPurchases(false);
            notifyPlayBillingJs("Compra confirmada por Google Play", true);
        } else if (hasPending) {
            notifyPlayBillingJs("Pago pendiente. El plan se activará cuando Google Play confirme el cobro.", true);
        }
    }

    private void acknowledgePlayPurchaseIfNeeded(Purchase purchase) {
        if (purchase == null || purchase.isAcknowledged() || purchase.getPurchaseState() != Purchase.PurchaseState.PURCHASED || billingClient == null) return;
        try {
            AcknowledgePurchaseParams params = AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.getPurchaseToken()).build();
            billingClient.acknowledgePurchase(params, result -> {
                if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                    Log.w(TAG, "Purchase acknowledgement failed: " + result.getDebugMessage());
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Purchase acknowledgement failed", e);
        }
    }

    private void refreshPlayPurchases(boolean userRequested) {
        if (billingClient == null || !billingClient.isReady()) {
            if (userRequested) playPurchaseRestoreRequested = true;
            connectPlayBilling();
            return;
        }
        playLatestInApp.clear();
        playLatestSubs.clear();
        playPurchaseQueryPending = 2;
        playPurchaseQueryHadError = false;
        playPurchaseRestoreRequested = userRequested;
        queryPlayPurchaseType(BillingClient.ProductType.INAPP, playLatestInApp);
        queryPlayPurchaseType(BillingClient.ProductType.SUBS, playLatestSubs);
    }

    private void queryPlayPurchaseType(String type, List<Purchase> target) {
        try {
            QueryPurchasesParams params = QueryPurchasesParams.newBuilder().setProductType(type).build();
            billingClient.queryPurchasesAsync(params, (billingResult, purchases) -> {
                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    if (purchases != null) target.addAll(purchases);
                } else {
                    playPurchaseQueryHadError = true;
                }
                finishPlayPurchaseQuery();
            });
        } catch (Exception e) {
            playPurchaseQueryHadError = true;
            finishPlayPurchaseQuery();
        }
    }

    private void finishPlayPurchaseQuery() {
        playPurchaseQueryPending--;
        if (playPurchaseQueryPending > 0) return;
        boolean permanent = false;
        boolean annual = false;
        boolean pending = false;
        for (Purchase p : playLatestInApp) {
            if (p.getProducts().contains(PLAY_PRODUCT_PERMANENT)) {
                if (p.getPurchaseState() == Purchase.PurchaseState.PURCHASED) { permanent = true; acknowledgePlayPurchaseIfNeeded(p); }
                else if (p.getPurchaseState() == Purchase.PurchaseState.PENDING) pending = true;
            }
        }
        for (Purchase p : playLatestSubs) {
            if (p.getProducts().contains(PLAY_PRODUCT_ANNUAL)) {
                if (p.getPurchaseState() == Purchase.PurchaseState.PURCHASED) { annual = true; acknowledgePlayPurchaseIfNeeded(p); }
                else if (p.getPurchaseState() == Purchase.PurchaseState.PENDING) pending = true;
            }
        }
        android.content.SharedPreferences prefs = playBillingPrefs();
        if (!playPurchaseQueryHadError) {
            String plan = permanent ? "PERMANENTE" : (annual ? "ANUAL" : "GRATIS");
            prefs.edit()
                    .putBoolean("active", permanent || annual)
                    .putString("plan", plan)
                    .putLong("verified_at", System.currentTimeMillis())
                    .putBoolean("pending", pending)
                    .apply();
        }
        String msg = "";
        if (playPurchaseRestoreRequested) {
            if (playPurchaseQueryHadError) msg = "No se pudo comprobar la compra. Revisa tu conexión e intenta nuevamente.";
            else if (permanent) msg = "Compra Permanente restaurada con tu cuenta de Google Play.";
            else if (annual) msg = "Suscripción Anual restaurada con tu cuenta de Google Play.";
            else if (pending) msg = "Hay una compra pendiente de confirmación en Google Play.";
            else msg = "No encontramos una compra activa con la cuenta de Google Play de este dispositivo.";
        }
        notifyPlayBillingJs(msg, playPurchaseRestoreRequested);
        playPurchaseRestoreRequested = false;
    }

    private JSONObject playBillingStatusJson(String message) {
        JSONObject out = new JSONObject();
        try {
            android.content.SharedPreferences prefs = playBillingPrefs();
            out.put("ready", billingClient != null && billingClient.isReady());
            out.put("installedFromPlay", installedFromPlayStore());
            out.put("active", prefs.getBoolean("active", false));
            out.put("plan", prefs.getString("plan", "GRATIS"));
            out.put("pending", prefs.getBoolean("pending", false));
            out.put("verifiedAt", prefs.getLong("verified_at", 0L));
            out.put("annualProductId", PLAY_PRODUCT_ANNUAL);
            out.put("permanentProductId", PLAY_PRODUCT_PERMANENT);
            out.put("annualAvailable", playAnnualDetails != null && playAnnualOffer != null);
            out.put("permanentAvailable", playPermanentDetails != null);
            out.put("annualPrice", annualPrice());
            out.put("permanentPrice", permanentPrice());
            out.put("message", message == null ? "" : message);
        } catch (Exception ignored) {}
        return out;
    }

    private void notifyPlayBillingJs(String message, boolean toastUser) {
        final String payload = playBillingStatusJson(message).toString();
        runOnUiThread(() -> {
            if (webView != null) {
                String encoded = Base64.encodeToString(payload.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                webView.evaluateJavascript("window.onPlayBillingUpdated && window.onPlayBillingUpdated(JSON.parse(atob('" + encoded + "')))", null);
            }
            if (toastUser && message != null && !message.isEmpty()) Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
        });
    }

    private void openPlaySubscriptionManagement() {
        runOnUiThread(() -> {
            try {
                Uri uri = Uri.parse("https://play.google.com/store/account/subscriptions?sku=" + PLAY_PRODUCT_ANNUAL + "&package=" + getPackageName());
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "No se pudo abrir Google Play", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean notificationsEnabled() {
        try {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return false;
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            return nm == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.N || nm.areNotificationsEnabled();
        } catch (Exception e) {
            return false;
        }
    }

    private boolean exactAlarmAllowed() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        try {
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            return am != null && am.canScheduleExactAlarms();
        } catch (Exception e) {
            return false;
        }
    }

    private void openNotificationSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            startActivity(intent);
        } catch (Exception e) {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATIONS && webView != null) {
            webView.postDelayed(() -> webView.evaluateJavascript("window.refreshNotificationStatus && window.refreshNotificationStatus()", null), 300);
        }
        if (requestCode == REQ_BLUETOOTH_CONNECT && webView != null) {
            boolean granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                    (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED);
            final String js = "window.onThermalBluetoothPermissionResult && window.onThermalBluetoothPermissionResult(" + (granted ? "true" : "false") + ")";
            webView.postDelayed(() -> webView.evaluateJavascript(js, null), 250);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra("open_reminders", false)) {
            if (webView != null) {
                webView.evaluateJavascript("if(window.openPendingRemindersFromNotification){window.openPendingRemindersFromNotification();}", null);
            } else {
                pendingOpenReminders = true;
            }
        }
    }


    private String stableDeviceCode() {
        try {
            String androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            if (androidId == null || androidId.trim().isEmpty()) androidId = "unknown";
            String raw = getPackageName() + "|" + androidId;
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(raw.getBytes(StandardCharsets.UTF_8));
            final char[] HEX = "0123456789ABCDEF".toCharArray();
            StringBuilder hex = new StringBuilder();
            for (int i = 0; i < 10; i++) {
                int v = digest[i] & 0xFF;
                hex.append(HEX[v >>> 4]).append(HEX[v & 0x0F]);
            }
            String s = hex.toString();
            return "PP-" + s.substring(0,4) + "-" + s.substring(4,8) + "-" + s.substring(8,12) + "-" + s.substring(12,16) + "-" + s.substring(16,20);
        } catch (Exception e) {
            return "PP-DEVICE-ERROR";
        }
    }

    private PublicKey[] licensePublicKeys() throws Exception {
        String[] encodedKeys = new String[]{LICENSE_PUBLIC_KEY_ADMIN_B64, LICENSE_PUBLIC_KEY_V2_B64, LICENSE_PUBLIC_KEY_LEGACY_B64};
        PublicKey[] keys = new PublicKey[encodedKeys.length];
        for (int i = 0; i < encodedKeys.length; i++) {
            byte[] der = Base64.decode(encodedKeys[i], Base64.DEFAULT);
            keys[i] = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(der));
        }
        return keys;
    }

    private JSONObject verifyLicenseInternal(String code) {
        JSONObject out = new JSONObject();
        try {
            out.put("status", "invalid");
            out.put("message", "Código de licencia no válido.");
            out.put("deviceCode", stableDeviceCode());
            if (code == null) return out;
            String[] parts = code.trim().split("\\.");
            if (parts.length != 3 || !"PP1".equals(parts[0])) return out;

            byte[] payloadBytes = Base64.decode(parts[1], Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
            byte[] signatureBytes = Base64.decode(parts[2], Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);

            boolean signatureValid = false;
            for (PublicKey key : licensePublicKeys()) {
                Signature verifier = Signature.getInstance("SHA256withRSA");
                verifier.initVerify(key);
                verifier.update(payloadBytes);
                if (verifier.verify(signatureBytes)) {
                    signatureValid = true;
                    break;
                }
            }
            if (!signatureValid) {
                out.put("message", "La firma de la licencia no es válida.");
                return out;
            }

            JSONObject payload = new JSONObject(new String(payloadBytes, StandardCharsets.UTF_8));
            if (payload.optInt("v", 0) != 1) {
                out.put("message", "Versión de licencia no compatible.");
                return out;
            }

            String currentDevice = stableDeviceCode();
            boolean deviceMatch = false;
            String single = payload.optString("device", "");
            if (!single.isEmpty() && currentDevice.equalsIgnoreCase(single)) deviceMatch = true;
            JSONArray devices = payload.optJSONArray("devices");
            if (devices != null) {
                for (int i = 0; i < devices.length(); i++) {
                    if (currentDevice.equalsIgnoreCase(devices.optString(i, ""))) {
                        deviceMatch = true;
                        break;
                    }
                }
            }

            out.put("signatureValid", true);
            out.put("deviceMatch", deviceMatch);
            out.put("licenseId", payload.optString("licenseId", ""));
            out.put("customer", payload.optString("customer", ""));
            String planName = payload.optString("plan", "Estándar");
            long issuedAt = payload.optLong("issuedAt", 0L);
            long expiryValue = payload.optLong("expiresAt", 0L);
            boolean isTrial = planName.toLowerCase(Locale.ROOT).contains("prueba");
            out.put("plan", planName);
            out.put("issuedAt", issuedAt);
            out.put("expiresAt", expiryValue);
            out.put("maxDevices", Math.max(1, payload.optInt("maxDevices", devices != null ? devices.length() : 1)));
            out.put("permanent", expiryValue <= 0L);
            out.put("trial", isTrial);
            if (expiryValue > 0L) {
                long remainingMs = Math.max(0L, expiryValue - System.currentTimeMillis());
                long daysRemaining = (remainingMs + 86399999L) / 86400000L;
                out.put("daysRemaining", daysRemaining);
            }

            if (!deviceMatch) {
                out.put("status", "device_mismatch");
                out.put("message", "Esta licencia fue emitida para otro dispositivo.");
                return out;
            }

            long expiresAt = payload.optLong("expiresAt", 0L);
            if (expiresAt > 0L && System.currentTimeMillis() > expiresAt) {
                out.put("status", "expired");
                out.put("message", "La licencia está vencida.");
                return out;
            }

            out.put("status", "active");
            out.put("valid", true);
            out.put("message", "Licencia válida.");
            return out;
        } catch (Exception e) {
            try { out.put("message", "No se pudo interpretar el código de licencia."); } catch (Exception ignored) {}
            return out;
        }
    }

    private static class ReceiptPdfData {
        final byte[] bytes;
        final int pageCount;
        ReceiptPdfData(byte[] bytes, int pageCount) {
            this.bytes = bytes;
            this.pageCount = pageCount;
        }
    }

    private String safePdfName(String requested) {
        String name = requested == null ? "recibo-prestapro.pdf" : requested.trim();
        if (name.isEmpty()) name = "recibo-prestapro.pdf";
        name = name.replaceAll("[^a-zA-Z0-9._-]+", "-");
        if (!name.toLowerCase(Locale.US).endsWith(".pdf")) name += ".pdf";
        return name;
    }

    private String normalizeReceiptPaperSize(String paperSize) {
        String v = paperSize == null ? "letter" : paperSize.trim().toLowerCase(Locale.US);
        if (!v.equals("a4") && !v.equals("auto") && !v.equals("letter")) v = "letter";
        return v;
    }

    private ReceiptPdfData buildReceiptPdf(String dataUrl) throws Exception {
        return buildReceiptPdf(dataUrl, "letter");
    }

    private ReceiptPdfData buildReceiptPdf(String dataUrl, String paperSize) throws Exception {
        if (dataUrl == null || dataUrl.isEmpty()) throw new Exception("Imagen de recibo vacía");
        String base64 = dataUrl;
        int comma = dataUrl.indexOf(',');
        if (comma >= 0) base64 = dataUrl.substring(comma + 1);
        byte[] imageBytes = Base64.decode(base64, Base64.DEFAULT);
        Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
        if (bitmap == null) throw new Exception("No se pudo leer el recibo");

        final String normalizedPaper = normalizeReceiptPaperSize(paperSize);
        // PDF necesita un tamaño físico fijo. En Automático usamos Carta para el archivo;
        // al imprimir, Android podrá elegir el papel disponible en la impresora.
        final boolean useA4 = "a4".equals(normalizedPaper);
        final int pageWidth = useA4 ? 595 : 612;   // A4 o Carta a ~72 dpi
        final int pageHeight = useA4 ? 842 : 792;
        final int margin = 28;
        final float contentWidth = pageWidth - (margin * 2f);
        final float contentHeight = pageHeight - (margin * 2f);
        final float scale = contentWidth / Math.max(1f, bitmap.getWidth());
        final int sourcePageHeight = Math.max(1, (int) Math.floor(contentHeight / scale));

        PdfDocument document = new PdfDocument();
        int pageNumber = 1;
        int srcTop = 0;
        try {
            while (srcTop < bitmap.getHeight()) {
                int srcBottom = Math.min(bitmap.getHeight(), srcTop + sourcePageHeight);
                PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create();
                PdfDocument.Page page = document.startPage(pageInfo);
                Canvas canvas = page.getCanvas();
                canvas.drawColor(Color.WHITE);

                Rect src = new Rect(0, srcTop, bitmap.getWidth(), srcBottom);
                float drawnHeight = (srcBottom - srcTop) * scale;
                RectF dst = new RectF(margin, margin, margin + contentWidth, margin + drawnHeight);
                canvas.drawBitmap(bitmap, src, dst, null);
                document.finishPage(page);

                srcTop = srcBottom;
                pageNumber++;
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            document.writeTo(out);
            return new ReceiptPdfData(out.toByteArray(), pageNumber - 1);
        } finally {
            document.close();
            bitmap.recycle();
        }
    }

    private void toastOnUi(String message) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
    }

    private static class ReceiptPrintAdapter extends PrintDocumentAdapter {
        private final byte[] pdfBytes;
        private final int pageCount;
        private final String documentName;

        ReceiptPrintAdapter(byte[] pdfBytes, int pageCount, String documentName) {
            this.pdfBytes = pdfBytes;
            this.pageCount = Math.max(1, pageCount);
            this.documentName = documentName;
        }

        @Override
        public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                             CancellationSignal cancellationSignal, LayoutResultCallback callback,
                             Bundle extras) {
            if (cancellationSignal.isCanceled()) {
                callback.onLayoutCancelled();
                return;
            }
            PrintDocumentInfo info = new PrintDocumentInfo.Builder(documentName)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(pageCount)
                    .build();
            callback.onLayoutFinished(info, true);
        }

        @Override
        public void onWrite(PageRange[] pages, ParcelFileDescriptor destination,
                            CancellationSignal cancellationSignal, WriteResultCallback callback) {
            if (cancellationSignal.isCanceled()) {
                callback.onWriteCancelled();
                return;
            }
            try (FileOutputStream out = new FileOutputStream(destination.getFileDescriptor())) {
                out.write(pdfBytes);
                out.flush();
                callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
            } catch (Exception e) {
                callback.onWriteFailed("No se pudo preparar el documento para imprimir");
            }
        }
    }

    private boolean thermalBluetoothPermissionGranted() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private String repeatChar(char c, int count) {
        StringBuilder sb = new StringBuilder(Math.max(0, count));
        for (int i = 0; i < count; i++) sb.append(c);
        return sb.toString();
    }

    private String sanitizeThermalText(String value) {
        if (value == null) return "";
        return value.replace('\r', ' ').replace('\n', ' ').replaceAll("\\s+", " ").trim();
    }

    private String centerThermal(String text, int cols) {
        text = sanitizeThermalText(text);
        if (text.length() >= cols) return text;
        int left = Math.max(0, (cols - text.length()) / 2);
        return repeatChar(' ', left) + text;
    }

    private String thermalPair(String label, String value, int cols) {
        label = sanitizeThermalText(label);
        value = sanitizeThermalText(value);
        int gap = cols - label.length() - value.length();
        if (gap >= 1) return label + repeatChar(' ', gap) + value;
        if (value.length() <= cols - 2) return label + "\n" + repeatChar(' ', Math.max(0, cols - value.length())) + value;
        return label + "\n" + value;
    }

    private void escposWriteText(OutputStream out, String text) throws Exception {
        Charset cp850 = Charset.forName("CP850");
        out.write(text.getBytes(cp850));
    }

    private void escposWriteRasterLogo(OutputStream out, String dataUrl, int maxWidth) {
        try {
            if (dataUrl == null || dataUrl.trim().isEmpty()) return;
            String base64 = dataUrl;
            int comma = base64.indexOf(',');
            if (comma >= 0) base64 = base64.substring(comma + 1);
            byte[] raw = Base64.decode(base64, Base64.DEFAULT);
            Bitmap original = BitmapFactory.decodeByteArray(raw, 0, raw.length);
            if (original == null) return;
            int targetWidth = Math.min(maxWidth, original.getWidth());
            int targetHeight = Math.max(1, Math.round(original.getHeight() * (targetWidth / (float) original.getWidth())));
            Bitmap bitmap = Bitmap.createScaledBitmap(original, targetWidth, targetHeight, true);
            int widthBytes = (bitmap.getWidth() + 7) / 8;
            int height = bitmap.getHeight();
            ByteArrayOutputStream data = new ByteArrayOutputStream(widthBytes * height);
            for (int y = 0; y < height; y++) {
                for (int xb = 0; xb < widthBytes; xb++) {
                    int b = 0;
                    for (int bit = 0; bit < 8; bit++) {
                        int x = xb * 8 + bit;
                        if (x >= bitmap.getWidth()) continue;
                        int color = bitmap.getPixel(x, y);
                        int gray = (Color.red(color) * 30 + Color.green(color) * 59 + Color.blue(color) * 11) / 100;
                        if (gray < 180 && Color.alpha(color) > 32) b |= (1 << (7 - bit));
                    }
                    data.write(b);
                }
            }
            out.write(new byte[]{0x1D, 0x76, 0x30, 0x00,
                    (byte) (widthBytes & 0xFF), (byte) ((widthBytes >> 8) & 0xFF),
                    (byte) (height & 0xFF), (byte) ((height >> 8) & 0xFF)});
            out.write(data.toByteArray());
            out.write('\n');
            if (bitmap != original) bitmap.recycle();
            original.recycle();
        } catch (Exception ignored) {
            // El logo es opcional: si una impresora no acepta raster, el ticket continúa en texto.
        }
    }

    private void printThermalPayload(String payloadJson, String macAddress, int paperWidthMm) {
        thermalExecutor.execute(() -> {
            BluetoothSocket socket = null;
            try {
                if (!thermalBluetoothPermissionGranted()) {
                    toastOnUi("Autoriza Bluetooth para imprimir");
                    return;
                }
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) throw new Exception("Este teléfono no tiene Bluetooth");
                if (!adapter.isEnabled()) throw new Exception("Activa Bluetooth antes de imprimir");
                if (macAddress == null || macAddress.trim().isEmpty()) throw new Exception("Selecciona una impresora térmica");

                BluetoothDevice device = adapter.getRemoteDevice(macAddress.trim());
                adapter.cancelDiscovery();
                socket = device.createRfcommSocketToServiceRecord(THERMAL_SPP_UUID);
                socket.connect();
                OutputStream out = socket.getOutputStream();

                JSONObject payload = new JSONObject(payloadJson == null ? "{}" : payloadJson);
                int cols = paperWidthMm >= 80 ? 48 : 32;
                out.write(new byte[]{0x1B, 0x40}); // initialize
                out.write(new byte[]{0x1B, 0x74, 0x02}); // CP850 en la mayoría de ESC/POS
                out.write(new byte[]{0x1B, 0x61, 0x01}); // center
                escposWriteRasterLogo(out, payload.optString("logoDataUrl", ""), paperWidthMm >= 80 ? 560 : 360);
                out.write(new byte[]{0x1B, 0x45, 0x01}); // bold
                escposWriteText(out, centerThermal(payload.optString("businessName", "PrestaPro"), cols) + "\n");
                out.write(new byte[]{0x1B, 0x45, 0x00});
                String contact = payload.optString("contact", "");
                if (!contact.isEmpty()) escposWriteText(out, centerThermal(contact, cols) + "\n");
                String receipt = payload.optString("receiptNo", "");
                String loan = payload.optString("loanCode", "");
                if (!loan.isEmpty()) receipt = receipt + " · " + loan;
                if (!receipt.isEmpty()) escposWriteText(out, centerThermal(receipt, cols) + "\n");
                escposWriteText(out, repeatChar('-', cols) + "\n");

                out.write(new byte[]{0x1B, 0x61, 0x00}); // left
                JSONArray rows = payload.optJSONArray("rows");
                if (rows != null) {
                    for (int i = 0; i < rows.length(); i++) {
                        JSONObject row = rows.optJSONObject(i);
                        if (row == null) continue;
                        String label = row.optString("label", "");
                        String value = row.optString("value", "");
                        escposWriteText(out, thermalPair(label, value, cols) + "\n");
                    }
                }
                escposWriteText(out, repeatChar('-', cols) + "\n");

                out.write(new byte[]{0x1B, 0x61, 0x01});
                out.write(new byte[]{0x1B, 0x45, 0x01});
                String status = payload.optString("status", "");
                if (!status.isEmpty()) escposWriteText(out, centerThermal(status, cols) + "\n");
                out.write(new byte[]{0x1B, 0x45, 0x00});
                String footer = payload.optString("footer", "");
                if (!footer.isEmpty()) escposWriteText(out, centerThermal(footer, cols) + "\n");
                String creator = payload.optString("creator", "");
                if (!creator.isEmpty()) escposWriteText(out, centerThermal(creator, cols) + "\n");
                escposWriteText(out, "\n\n\n");
                out.flush();
                toastOnUi("Ticket enviado a la impresora");
            } catch (Exception e) {
                String msg = e.getMessage();
                if (msg == null || msg.trim().isEmpty()) msg = "No se pudo conectar con la impresora";
                toastOnUi(msg);
            } finally {
                try { if (socket != null) socket.close(); } catch (Exception ignored) {}
            }
        });
    }

    private SharedPreferences securityPrefs() {
        return getSharedPreferences(SECURITY_PREFS, MODE_PRIVATE);
    }

    private boolean securityPinConfigured() {
        String hash = securityPrefs().getString(SECURITY_PIN_HASH, "");
        String salt = securityPrefs().getString(SECURITY_PIN_SALT, "");
        return hash != null && !hash.isEmpty() && salt != null && !salt.isEmpty();
    }

    private boolean biometricAvailable() {
        try {
            int authenticators = BiometricManager.Authenticators.BIOMETRIC_WEAK;
            return BiometricManager.from(this).canAuthenticate(authenticators) == BiometricManager.BIOMETRIC_SUCCESS;
        } catch (Exception e) {
            return false;
        }
    }

    private String derivePinHash(String pin, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(pin.toCharArray(), salt, 120000, 256);
        byte[] encoded = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).getEncoded();
        spec.clearPassword();
        return Base64.encodeToString(encoded, Base64.NO_WRAP);
    }

    private boolean saveSecurityPin(String pin) {
        if (pin == null || !pin.matches("\\d{4,6}")) return false;
        try {
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);
            String hash = derivePinHash(pin, salt);
            securityPrefs().edit()
                    .putString(SECURITY_PIN_HASH, hash)
                    .putString(SECURITY_PIN_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
                    .putInt(SECURITY_AUTO_LOCK, securityPrefs().getInt(SECURITY_AUTO_LOCK, 1))
                    .apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean verifySecurityPin(String pin) {
        if (!securityPinConfigured() || pin == null) return false;
        try {
            byte[] salt = Base64.decode(securityPrefs().getString(SECURITY_PIN_SALT, ""), Base64.DEFAULT);
            String expected = securityPrefs().getString(SECURITY_PIN_HASH, "");
            String actual = derivePinHash(pin, salt);
            return MessageDigest.isEqual(expected.getBytes(StandardCharsets.UTF_8), actual.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            return false;
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable roundedBg(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp((int) radiusDp));
        return d;
    }

    private TextView lockText(String text, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER);
        if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return v;
    }

    private void showSecurityLock(boolean autoBiometric) {
        if (!securityPinConfigured()) return;
        runOnUiThread(() -> {
            securityLocked = true;
            if (webView != null) webView.setVisibility(View.INVISIBLE);
            if (securityOverlay != null) {
                securityOverlay.setVisibility(View.VISIBLE);
                if (autoBiometric) maybePromptBiometric();
                return;
            }

            FrameLayout overlay = new FrameLayout(MainActivity.this);
            overlay.setBackgroundColor(Color.rgb(246, 247, 251));
            overlay.setClickable(true);
            overlay.setFocusable(true);

            LinearLayout card = new LinearLayout(MainActivity.this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER_HORIZONTAL);
            card.setPadding(dp(24), dp(24), dp(24), dp(24));
            card.setBackground(roundedBg(Color.WHITE, 24));
            FrameLayout.LayoutParams cardLp = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
            cardLp.gravity = Gravity.CENTER;
            cardLp.leftMargin = dp(22);
            cardLp.rightMargin = dp(22);
            overlay.addView(card, cardLp);

            ImageView icon = new ImageView(MainActivity.this);
            icon.setImageResource(com.remberto.misprestamos.R.drawable.app_icon);
            icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
            LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(76), dp(76));
            iconLp.bottomMargin = dp(14);
            card.addView(icon, iconLp);

            TextView title = lockText("PrestaPro bloqueado", 23, Color.rgb(9, 39, 77), true);
            card.addView(title, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

            TextView subtitle = lockText("Ingresa tu PIN para proteger clientes, préstamos y garantías.", 13, Color.rgb(96, 112, 133), false);
            LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            subLp.topMargin = dp(7);
            subLp.bottomMargin = dp(18);
            card.addView(subtitle, subLp);

            EditText pin = new EditText(MainActivity.this);
            pin.setHint("PIN de 4 a 6 dígitos");
            pin.setTextSize(20);
            pin.setGravity(Gravity.CENTER);
            pin.setSingleLine(true);
            pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
            pin.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
            pin.setBackground(roundedBg(Color.rgb(242, 246, 251), 14));
            pin.setPadding(dp(14), dp(13), dp(14), dp(13));
            LinearLayout.LayoutParams pinLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
            card.addView(pin, pinLp);
            securityPinInput = pin;

            TextView error = lockText("", 12, Color.rgb(190, 36, 52), false);
            LinearLayout.LayoutParams errLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            errLp.topMargin = dp(7);
            card.addView(error, errLp);
            securityErrorText = error;

            Button unlock = new Button(MainActivity.this);
            unlock.setText("Desbloquear");
            unlock.setTextColor(Color.WHITE);
            unlock.setTextSize(14);
            unlock.setAllCaps(false);
            unlock.setBackground(roundedBg(Color.rgb(11, 99, 217), 14));
            LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
            btnLp.topMargin = dp(12);
            card.addView(unlock, btnLp);
            unlock.setOnClickListener(v -> tryUnlockWithPin());
            pin.setOnEditorActionListener((v, actionId, event) -> { tryUnlockWithPin(); return true; });

            Button bio = new Button(MainActivity.this);
            bio.setText("Usar huella / biometría");
            bio.setTextColor(Color.rgb(11, 91, 196));
            bio.setTextSize(13);
            bio.setAllCaps(false);
            bio.setBackground(roundedBg(Color.rgb(234, 243, 255), 14));
            LinearLayout.LayoutParams bioLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
            bioLp.topMargin = dp(9);
            card.addView(bio, bioLp);
            securityBiometricButton = bio;
            boolean bioEnabled = securityPrefs().getBoolean(SECURITY_BIOMETRIC, false) && biometricAvailable();
            bio.setVisibility(bioEnabled ? View.VISIBLE : View.GONE);
            bio.setOnClickListener(v -> promptBiometricUnlock());

            TextView footer = lockText("PrestaPro · by Taca", 10, Color.rgb(130, 143, 160), false);
            LinearLayout.LayoutParams footLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            footLp.topMargin = dp(16);
            card.addView(footer, footLp);

            securityOverlay = overlay;
            if (rootContainer != null) rootContainer.addView(overlay, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            if (autoBiometric) overlay.postDelayed(this::maybePromptBiometric, 300);
        });
    }

    private void tryUnlockWithPin() {
        String pin = securityPinInput == null ? "" : securityPinInput.getText().toString();
        if (verifySecurityPin(pin)) {
            unlockSecurity();
        } else {
            if (securityErrorText != null) securityErrorText.setText("PIN incorrecto. Inténtalo nuevamente.");
            if (securityPinInput != null) {
                securityPinInput.setText("");
                securityPinInput.requestFocus();
            }
        }
    }

    private void unlockSecurity() {
        runOnUiThread(() -> {
            securityLocked = false;
            biometricPromptVisible = false;
            securityBackgroundAt = 0L;
            if (securityPinInput != null) securityPinInput.setText("");
            if (securityErrorText != null) securityErrorText.setText("");
            if (securityOverlay != null) securityOverlay.setVisibility(View.GONE);
            if (webView != null) webView.setVisibility(View.VISIBLE);
        });
    }

    private void maybePromptBiometric() {
        if (securityLocked && securityPrefs().getBoolean(SECURITY_BIOMETRIC, false) && biometricAvailable()) {
            promptBiometricUnlock();
        }
    }

    private void promptBiometricUnlock() {
        if (!securityLocked || biometricPromptVisible || !biometricAvailable()) return;
        biometricPromptVisible = true;
        java.util.concurrent.Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                unlockSecurity();
            }

            @Override
            public void onAuthenticationError(int errorCode, CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                biometricPromptVisible = false;
                if (securityErrorText != null && errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON && errorCode != BiometricPrompt.ERROR_USER_CANCELED) {
                    securityErrorText.setText("No se pudo validar la biometría. Usa tu PIN.");
                }
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                if (securityErrorText != null) securityErrorText.setText("Biometría no reconocida. Inténtalo de nuevo o usa tu PIN.");
            }
        });
        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Desbloquear PrestaPro")
                .setSubtitle("Confirma tu identidad")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
                .setNegativeButtonText("Usar PIN")
                .build();
        try {
            prompt.authenticate(info);
        } catch (Exception e) {
            biometricPromptVisible = false;
        }
    }

    @Override
    public void onBackPressed() {
        if (securityLocked) {
            moveTaskToBack(true);
            return;
        }
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void exportBackup(String json) {
            runOnUiThread(() -> {
                pendingBackupJson = json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "respaldo-prestapro.json");
                try {
                    startActivityForResult(intent, REQ_SAVE_BACKUP);
                } catch (Exception e) {
                    pendingBackupJson = null;
                    Toast.makeText(MainActivity.this, "No se pudo abrir el guardado de archivos", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void exportFinanceCsv(String csv, String fileName) {
            runOnUiThread(() -> {
                try {
                    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                    bytes.write(new byte[]{(byte)0xEF,(byte)0xBB,(byte)0xBF});
                    bytes.write((csv == null ? "" : csv).getBytes(StandardCharsets.UTF_8));
                    pendingFinanceBytes = bytes.toByteArray();
                    pendingFinanceName = safeExportName(fileName, "prestapro-finanzas.csv");
                    pendingFinanceMime = "text/csv";
                    launchFinanceSave(REQ_SAVE_FINANCE_CSV);
                } catch (Exception e) {
                    pendingFinanceBytes = null;
                    Toast.makeText(MainActivity.this, "No se pudo preparar el CSV", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void exportFinanceExcel(String json, String fileName) {
            receiptExecutor.execute(() -> {
                try {
                    byte[] bytes = buildFinanceXlsx(json == null ? "{}" : json);
                    runOnUiThread(() -> {
                        pendingFinanceBytes = bytes;
                        pendingFinanceName = safeExportName(fileName, "prestapro-finanzas.xlsx");
                        pendingFinanceMime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                        launchFinanceSave(REQ_SAVE_FINANCE_XLSX);
                    });
                } catch (Exception e) {
                    Log.e(TAG, "Finance XLSX export failed", e);
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "No se pudo preparar el archivo Excel", Toast.LENGTH_LONG).show());
                }
            });
        }

        @JavascriptInterface
        public void backupToDrive(String json) {
            runOnUiThread(() -> {
                pendingDriveBackupJson = json;
                startGoogleAuthorization(GOOGLE_ACTION_BACKUP, false);
            });
        }

        @JavascriptInterface
        public void chooseDriveBackupLocation(String json) {
            runOnUiThread(() -> {
                pendingDriveBackupJson = json;
                startGoogleAuthorization(GOOGLE_ACTION_BACKUP, true);
            });
        }

        @JavascriptInterface
        public void restoreFromDrive() {
            runOnUiThread(() -> startGoogleAuthorization(GOOGLE_ACTION_RESTORE, false));
        }

        @JavascriptInterface
        public void linkGoogleAccount() {
            runOnUiThread(() -> startGoogleAuthorization(GOOGLE_ACTION_NONE, true));
        }

        @JavascriptInterface
        public String getDeviceCode() {
            return stableDeviceCode();
        }

        @JavascriptInterface
        public String verifyLicense(String licenseCode) {
            return verifyLicenseInternal(licenseCode).toString();
        }
        @JavascriptInterface
        public String getPlayBillingStatus() {
            return playBillingStatusJson("").toString();
        }

        @JavascriptInterface
        public void buyPlayAnnual() {
            launchPlayPurchase("annual");
        }

        @JavascriptInterface
        public void buyPlayPermanent() {
            launchPlayPurchase("permanent");
        }

        @JavascriptInterface
        public void restorePlayPurchases() {
            runOnUiThread(() -> refreshPlayPurchases(true));
        }

        @JavascriptInterface
        public void managePlayAnnualSubscription() {
            openPlaySubscriptionManagement();
        }


        @JavascriptInterface
        public void copyText(String value) {
            runOnUiThread(() -> {
                try {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("PrestaPro", value == null ? "" : value));
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public String getAppVersion() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "2.8";
            }
        }

        @JavascriptInterface
        public String getSecurityStatus() {
            JSONObject out = new JSONObject();
            try {
                out.put("pinEnabled", securityPinConfigured());
                out.put("biometricAvailable", biometricAvailable());
                out.put("biometricEnabled", securityPrefs().getBoolean(SECURITY_BIOMETRIC, false) && biometricAvailable());
                out.put("autoLockMinutes", securityPrefs().getInt(SECURITY_AUTO_LOCK, 1));
                out.put("locked", securityLocked);
            } catch (Exception ignored) {}
            return out.toString();
        }

        @JavascriptInterface
        public String setSecurityPin(String pin) {
            JSONObject out = new JSONObject();
            try {
                boolean ok = saveSecurityPin(pin == null ? "" : pin.trim());
                out.put("ok", ok);
                out.put("message", ok ? "PIN guardado" : "El PIN debe tener de 4 a 6 dígitos");
            } catch (Exception e) {
                try { out.put("ok", false); out.put("message", "No se pudo guardar el PIN"); } catch (Exception ignored) {}
            }
            return out.toString();
        }

        @JavascriptInterface
        public String setSecurityBiometric(boolean enabled) {
            JSONObject out = new JSONObject();
            try {
                boolean allowed = !enabled || (securityPinConfigured() && biometricAvailable());
                if (allowed) securityPrefs().edit().putBoolean(SECURITY_BIOMETRIC, enabled).apply();
                out.put("ok", allowed);
                out.put("enabled", allowed && enabled);
                out.put("message", allowed ? (enabled ? "Biometría activada" : "Biometría desactivada") : "Configura primero un PIN y registra una huella en Android");
            } catch (Exception ignored) {}
            return out.toString();
        }

        @JavascriptInterface
        public void setSecurityAutoLockMinutes(int minutes) {
            int safe = (minutes == 0 || minutes == 1 || minutes == 5 || minutes == 15 || minutes == 30) ? minutes : 1;
            securityPrefs().edit().putInt(SECURITY_AUTO_LOCK, safe).apply();
        }

        @JavascriptInterface
        public void disableSecurityLock() {
            runOnUiThread(() -> {
                securityPrefs().edit()
                        .remove(SECURITY_PIN_HASH)
                        .remove(SECURITY_PIN_SALT)
                        .putBoolean(SECURITY_BIOMETRIC, false)
                        .apply();
                unlockSecurity();
            });
        }

        @JavascriptInterface
        public void lockPrestaProNow() {
            runOnUiThread(() -> showSecurityLock(true));
        }

        @JavascriptInterface
        public String getCloudBackupStatus() {
            long last = getSharedPreferences("taca_backup", MODE_PRIVATE).getLong("last_backup_at", 0L);
            String email = getSharedPreferences("taca_backup", MODE_PRIVATE).getString("google_email", "");
            boolean linked = email != null && !email.isEmpty();
            JSONObject out = new JSONObject();
            try {
                out.put("linked", linked);
                out.put("email", email == null ? "" : email);
                out.put("lastBackupAt", last);
            } catch (Exception ignored) {}
            return out.toString();
        }

        @JavascriptInterface
        public String getPairedThermalPrinters() {
            JSONObject result = new JSONObject();
            JSONArray devices = new JSONArray();
            try {
                if (!thermalBluetoothPermissionGranted()) {
                    result.put("permissionRequired", true);
                    result.put("bluetoothEnabled", false);
                    result.put("devices", devices);
                    return result.toString();
                }
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) {
                    result.put("unsupported", true);
                    result.put("devices", devices);
                    return result.toString();
                }
                result.put("bluetoothEnabled", adapter.isEnabled());
                if (adapter.isEnabled()) {
                    Set<BluetoothDevice> bonded = adapter.getBondedDevices();
                    if (bonded != null) {
                        for (BluetoothDevice d : bonded) {
                            JSONObject item = new JSONObject();
                            String name = d.getName();
                            item.put("name", name == null || name.trim().isEmpty() ? "Dispositivo Bluetooth" : name);
                            item.put("address", d.getAddress());
                            devices.put(item);
                        }
                    }
                }
                result.put("devices", devices);
            } catch (Exception e) {
                try { result.put("error", "No se pudo leer los dispositivos Bluetooth emparejados"); result.put("devices", devices); } catch (Exception ignored) {}
            }
            return result.toString();
        }

        @JavascriptInterface
        public void requestThermalBluetoothPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !thermalBluetoothPermissionGranted()) {
                    requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BLUETOOTH_CONNECT);
                } else if (webView != null) {
                    webView.evaluateJavascript("window.onThermalBluetoothPermissionResult && window.onThermalBluetoothPermissionResult(true)", null);
                }
            });
        }

        @JavascriptInterface
        public void openBluetoothSettings() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_SETTINGS));
                }
            });
        }

        @JavascriptInterface
        public void printThermalReceipt(String payloadJson, String macAddress, int paperWidthMm) {
            if (!thermalBluetoothPermissionGranted()) {
                requestThermalBluetoothPermission();
                return;
            }
            printThermalPayload(payloadJson, macAddress, paperWidthMm);
        }

        @JavascriptInterface
        public void shareReceipt(String dataUrl, String fileName) {
            runOnUiThread(() -> {
                try {
                    String base64 = dataUrl;
                    int comma = dataUrl.indexOf(',');
                    if (comma >= 0) base64 = dataUrl.substring(comma + 1);
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);

                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName == null ? "recibo-prestapro.png" : fileName);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PrestaPro");
                        values.put(MediaStore.Images.Media.IS_PENDING, 1);
                    }

                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("No se pudo crear el archivo del recibo");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("No se pudo escribir el recibo");
                        out.write(bytes);
                        out.flush();
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues ready = new ContentValues();
                        ready.put(MediaStore.Images.Media.IS_PENDING, 0);
                        getContentResolver().update(uri, ready, null, null);
                    }

                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("image/png");
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share, "Compartir recibo"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No se pudo compartir el recibo", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void saveReceiptPdf(String dataUrl, String fileName) {
            saveReceiptPdfWithSize(dataUrl, fileName, "letter");
        }

        @JavascriptInterface
        public void saveReceiptPdfWithSize(String dataUrl, String fileName, String paperSize) {
            receiptExecutor.execute(() -> {
                try {
                    ReceiptPdfData pdf = buildReceiptPdf(dataUrl, paperSize);
                    pendingReceiptPdfBytes = pdf.bytes;
                    pendingReceiptPdfName = safePdfName(fileName);
                    runOnUiThread(() -> {
                        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("application/pdf");
                        intent.putExtra(Intent.EXTRA_TITLE, pendingReceiptPdfName);
                        try {
                            startActivityForResult(intent, REQ_SAVE_RECEIPT_PDF);
                        } catch (Exception e) {
                            pendingReceiptPdfBytes = null;
                            pendingReceiptPdfName = null;
                            Toast.makeText(MainActivity.this, "No se pudo abrir el guardado del PDF", Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (Exception e) {
                    toastOnUi("No se pudo generar el PDF");
                }
            });
        }

        @JavascriptInterface
        public void shareReceiptPdf(String dataUrl, String fileName) {
            shareReceiptPdfWithSize(dataUrl, fileName, "letter");
        }

        @JavascriptInterface
        public void shareReceiptPdfWithSize(String dataUrl, String fileName, String paperSize) {
            receiptExecutor.execute(() -> {
                try {
                    ReceiptPdfData pdf = buildReceiptPdf(dataUrl, paperSize);
                    String safeName = safePdfName(fileName);
                    File dir = new File(getCacheDir(), "shared_receipts");
                    if (!dir.exists() && !dir.mkdirs()) throw new Exception("No se pudo crear la carpeta temporal");
                    File file = new File(dir, safeName);
                    try (FileOutputStream out = new FileOutputStream(file)) {
                        out.write(pdf.bytes);
                        out.flush();
                    }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file);
                    runOnUiThread(() -> {
                        try {
                            Intent share = new Intent(Intent.ACTION_SEND);
                            share.setType("application/pdf");
                            share.putExtra(Intent.EXTRA_STREAM, uri);
                            share.putExtra(Intent.EXTRA_SUBJECT, "Recibo PrestaPro");
                            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            startActivity(Intent.createChooser(share, "Compartir recibo PDF"));
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "No se pudo compartir el PDF", Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (Exception e) {
                    toastOnUi("No se pudo generar el PDF");
                }
            });
        }

        @JavascriptInterface
        public void printReceipt(String dataUrl, String fileName) {
            printReceiptWithSize(dataUrl, fileName, "letter");
        }

        @JavascriptInterface
        public void printReceiptWithSize(String dataUrl, String fileName, String paperSize) {
            final String normalizedPaper = normalizeReceiptPaperSize(paperSize);
            receiptExecutor.execute(() -> {
                try {
                    ReceiptPdfData pdf = buildReceiptPdf(dataUrl, normalizedPaper);
                    String safeName = safePdfName(fileName);
                    runOnUiThread(() -> {
                        try {
                            PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
                            PrintAttributes.Builder builder = new PrintAttributes.Builder()
                                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR);
                            if ("a4".equals(normalizedPaper)) {
                                builder.setMediaSize(PrintAttributes.MediaSize.ISO_A4);
                            } else if ("letter".equals(normalizedPaper)) {
                                builder.setMediaSize(PrintAttributes.MediaSize.NA_LETTER);
                            }
                            // En Automático no forzamos MediaSize: Android/servicio de impresión decide.
                            printManager.print("PrestaPro - " + safeName,
                                    new ReceiptPrintAdapter(pdf.bytes, pdf.pageCount, safeName), builder.build());
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "No se pudo abrir la impresión", Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (Exception e) {
                    toastOnUi("No se pudo preparar la impresión");
                }
            });
        }

        @JavascriptInterface
        public void shareToWhatsApp(String dataUrl, String fileName) {
            runOnUiThread(() -> {
                try {
                    String base64 = dataUrl;
                    int comma = dataUrl.indexOf(',');
                    if (comma >= 0) base64 = dataUrl.substring(comma + 1);
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);

                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName == null ? "recordatorio-prestapro.png" : fileName);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PrestaPro");
                        values.put(MediaStore.Images.Media.IS_PENDING, 1);
                    }

                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("No se pudo crear la imagen del recordatorio");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("No se pudo escribir la imagen del recordatorio");
                        out.write(bytes);
                        out.flush();
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues ready = new ContentValues();
                        ready.put(MediaStore.Images.Media.IS_PENDING, 0);
                        getContentResolver().update(uri, ready, null, null);
                    }

                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("image/png");
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                    try {
                        share.setPackage("com.whatsapp");
                        startActivity(share);
                    } catch (Exception normalMissing) {
                        try {
                            share.setPackage("com.whatsapp.w4b");
                            startActivity(share);
                        } catch (Exception businessMissing) {
                            share.setPackage(null);
                            startActivity(Intent.createChooser(share, "Compartir recordatorio"));
                        }
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No se pudo compartir el recordatorio", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void syncAutoCash(String summaryJson, boolean enabled, int hour, int minute, int warnMinutes) {
            android.content.SharedPreferences prefs = getSharedPreferences(AutoCashCloseReceiver.PREFS, MODE_PRIVATE);
            prefs.edit()
                    .putBoolean("enabled", enabled)
                    .putString("summary_json", summaryJson == null ? "{}" : summaryJson)
                    .putInt("hour", Math.max(0, Math.min(23, hour)))
                    .putInt("minute", Math.max(0, Math.min(59, minute)))
                    .putInt("warn_minutes", Math.max(0, Math.min(60, warnMinutes)))
                    .apply();
            if (enabled) AutoCashCloseReceiver.schedule(MainActivity.this, hour, minute, warnMinutes);
            else AutoCashCloseReceiver.cancel(MainActivity.this);
        }

        @JavascriptInterface
        public void disableAutoCash() {
            getSharedPreferences(AutoCashCloseReceiver.PREFS, MODE_PRIVATE)
                    .edit().putBoolean("enabled", false).apply();
            AutoCashCloseReceiver.cancel(MainActivity.this);
        }

        @JavascriptInterface
        public String getAutoCashStatus() {
            android.content.SharedPreferences prefs = getSharedPreferences(AutoCashCloseReceiver.PREFS, MODE_PRIVATE);
            JSONObject out = new JSONObject();
            try {
                out.put("enabled", prefs.getBoolean("enabled", false));
                out.put("nextCloseAt", prefs.getLong("next_close_at", 0L));
                out.put("nextWarnAt", prefs.getLong("next_warn_at", 0L));
                out.put("lastCloseAt", prefs.getLong("last_close_at", 0L));
                out.put("lastCloseDate", prefs.getString("last_close_date", ""));
                out.put("lastScheduleExact", prefs.getBoolean("last_schedule_exact", false));
                out.put("exactAlarmRequired", Build.VERSION.SDK_INT >= Build.VERSION_CODES.S);
                out.put("exactAlarmAllowed", exactAlarmAllowed());
            } catch (Exception ignored) {}
            return out.toString();
        }

        @JavascriptInterface
        public String getPendingAutoCashClosure() {
            return getSharedPreferences(AutoCashCloseReceiver.PREFS, MODE_PRIVATE)
                    .getString("pending_close_json", "");
        }

        @JavascriptInterface
        public void ackAutoCashClosure(String date) {
            android.content.SharedPreferences prefs = getSharedPreferences(AutoCashCloseReceiver.PREFS, MODE_PRIVATE);
            try {
                String raw = prefs.getString("pending_close_json", "");
                if (raw == null || raw.isEmpty()) return;
                JSONObject obj = new JSONObject(raw);
                if (date == null || date.isEmpty() || date.equals(obj.optString("date", ""))) {
                    prefs.edit().remove("pending_close_json").apply();
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public String getNotificationStatus() {
            android.content.SharedPreferences prefs = getSharedPreferences("taca_alerts", MODE_PRIVATE);
            JSONObject out = new JSONObject();
            try {
                out.put("notificationsEnabled", notificationsEnabled());
                out.put("exactAlarmRequired", Build.VERSION.SDK_INT >= Build.VERSION_CODES.S);
                out.put("exactAlarmAllowed", exactAlarmAllowed());
                out.put("nextAlarmAt", prefs.getLong("next_alarm_at", 0L));
                out.put("lastScheduledAt", prefs.getLong("last_scheduled_at", 0L));
                out.put("lastScheduleExact", prefs.getBoolean("last_schedule_exact", false));
                out.put("testAlarmAt", prefs.getLong("test_alarm_at", 0L));
                out.put("lastTestFiredAt", prefs.getLong("last_test_fired_at", 0L));
            } catch (Exception ignored) {}
            return out.toString();
        }

        @JavascriptInterface
        public void reviewNotificationPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
                } else if (!notificationsEnabled()) {
                    openNotificationSettings();
                } else {
                    Toast.makeText(MainActivity.this, "Las notificaciones de PrestaPro están permitidas", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void reviewExactAlarmPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                    Toast.makeText(MainActivity.this, "Este Android no requiere permiso especial de alarmas exactas", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (exactAlarmAllowed()) {
                    Toast.makeText(MainActivity.this, "Las alarmas exactas están permitidas", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    Intent exact = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                    exact.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(exact);
                } catch (Exception e) {
                    Intent details = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
                    startActivity(details);
                }
            });
        }

        @JavascriptInterface
        public void scheduleNotificationTest() {
            runOnUiThread(() -> {
                if (!getSharedPreferences("taca_alerts", MODE_PRIVATE).getBoolean("alerts_enabled", false)) {
                    Toast.makeText(MainActivity.this, "Activa una licencia válida para programar recordatorios", Toast.LENGTH_LONG).show();
                    return;
                }
                if (!notificationsEnabled()) {
                    Toast.makeText(MainActivity.this, "Primero permite las notificaciones de PrestaPro", Toast.LENGTH_LONG).show();
                    return;
                }
                long when = NotificationReceiver.scheduleTest(MainActivity.this, 60_000L);
                Toast.makeText(MainActivity.this, "Prueba programada en aproximadamente 1 minuto", Toast.LENGTH_LONG).show();
                if (webView != null) webView.evaluateJavascript("window.refreshNotificationStatus && window.refreshNotificationStatus()", null);
            });
        }

        @JavascriptInterface
        public void syncAlerts(String json, int hour, int minute) {
            getSharedPreferences("taca_alerts", MODE_PRIVATE)
                    .edit()
                    .putBoolean("alerts_enabled", true)
                    .putString("alerts_json", json == null ? "[]" : json)
                    .putInt("hour", Math.max(0, Math.min(23, hour)))
                    .putInt("minute", Math.max(0, Math.min(59, minute)))
                    .apply();
            NotificationReceiver.schedule(MainActivity.this, hour, minute);
        }

        @JavascriptInterface
        public void disableAlerts() {
            getSharedPreferences("taca_alerts", MODE_PRIVATE)
                    .edit()
                    .putBoolean("alerts_enabled", false)
                    .putString("alerts_json", "[]")
                    .apply();
            NotificationReceiver.cancelAll(MainActivity.this);
            if (webView != null) {
                webView.postDelayed(() -> webView.evaluateJavascript("window.refreshNotificationStatus && window.refreshNotificationStatus()", null), 150);
            }
        }
    }

    private String safeExportName(String candidate, String fallback) {
        String name = candidate == null ? "" : candidate.trim();
        if (name.isEmpty()) name = fallback;
        return name.replaceAll("[\\\\/:*?\"<>|]", "-");
    }

    private void launchFinanceSave(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(pendingFinanceMime == null ? "application/octet-stream" : pendingFinanceMime);
        intent.putExtra(Intent.EXTRA_TITLE, pendingFinanceName == null ? "prestapro-finanzas" : pendingFinanceName);
        try {
            startActivityForResult(intent, requestCode);
        } catch (Exception e) {
            pendingFinanceBytes = null;
            pendingFinanceName = null;
            pendingFinanceMime = null;
            Toast.makeText(this, "No se pudo abrir el guardado de archivos", Toast.LENGTH_SHORT).show();
        }
    }

    private byte[] buildFinanceXlsx(String json) throws Exception {
        JSONObject root = new JSONObject(json);
        JSONArray sheets = root.optJSONArray("sheets");
        if (sheets == null || sheets.length() == 0) throw new IllegalArgumentException("No hay datos para exportar");
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(buffer)) {
            StringBuilder types = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
            for (int i=0;i<sheets.length();i++) types.append("<Override PartName=\"/xl/worksheets/sheet").append(i+1).append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
            types.append("</Types>");
            putZip(zip, "[Content_Types].xml", types.toString());
            putZip(zip, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");

            StringBuilder workbook = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");
            StringBuilder rels = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
            for (int i=0;i<sheets.length();i++) {
                JSONObject sheet = sheets.optJSONObject(i); String nm = sheet == null ? "Hoja " + (i+1) : sheet.optString("name", "Hoja " + (i+1));
                workbook.append("<sheet name=\"").append(xmlAttr(cleanSheetName(nm))).append("\" sheetId=\"").append(i+1).append("\" r:id=\"rId").append(i+1).append("\"/>");
                rels.append("<Relationship Id=\"rId").append(i+1).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet").append(i+1).append(".xml\"/>");
            }
            workbook.append("</sheets></workbook>");
            rels.append("<Relationship Id=\"rId").append(sheets.length()+1).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
            putZip(zip, "xl/workbook.xml", workbook.toString());
            putZip(zip, "xl/_rels/workbook.xml.rels", rels.toString());
            putZip(zip, "xl/styles.xml", xlsxStyles());
            for (int i=0;i<sheets.length();i++) {
                JSONObject sheet = sheets.optJSONObject(i); JSONArray rows = sheet == null ? null : sheet.optJSONArray("rows");
                putZip(zip, "xl/worksheets/sheet"+(i+1)+".xml", buildSheetXml(rows));
            }
        }
        return buffer.toByteArray();
    }

    private void putZip(ZipOutputStream zip, String path, String text) throws Exception {
        zip.putNextEntry(new ZipEntry(path));
        zip.write(text.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private String cleanSheetName(String name) {
        String n = name == null ? "Hoja" : name.replaceAll("[\\\\/\\?\\*\\[\\]:]", " ").trim();
        if (n.isEmpty()) n = "Hoja";
        return n.length() > 31 ? n.substring(0,31) : n;
    }

    private String xmlText(String value) {
        if (value == null) return "";
        StringBuilder out = new StringBuilder();
        for (int i=0;i<value.length();i++) { char c=value.charAt(i); if (c==9||c==10||c==13||c>=32) out.append(c); }
        return out.toString().replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
    }
    private String xmlAttr(String value) { return xmlText(value).replace("\"","&quot;").replace("'","&apos;"); }

    private String xlsxStyles() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><numFmts count=\"1\"><numFmt numFmtId=\"164\" formatCode=\"#,##0.00\"/></numFmts><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/></font></fonts><fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF0B63D9\"/><bgColor indexed=\"64\"/></patternFill></fill></fills><borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"3\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/><xf numFmtId=\"164\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/></cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>";
    }

    private String buildSheetXml(JSONArray rows) {
        if (rows == null) rows = new JSONArray();
        int maxCols=1; for(int r=0;r<rows.length();r++){JSONArray row=rows.optJSONArray(r);if(row!=null)maxCols=Math.max(maxCols,row.length());}
        String end=colName(maxCols)+Math.max(1,rows.length());
        StringBuilder xml=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><dimension ref=\"A1:").append(end).append("\"/><sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight=\"15\"/><cols>");
        JSONArray header=rows.optJSONArray(0);
        for(int c=0;c<maxCols;c++){int width=12;String h=header==null?"":header.optString(c,"");width=Math.max(width,Math.min(32,h.length()+4));xml.append("<col min=\"").append(c+1).append("\" max=\"").append(c+1).append("\" width=\"").append(width).append("\" customWidth=\"1\"/>");}
        xml.append("</cols><sheetData>");
        for(int r=0;r<rows.length();r++){
            JSONArray row=rows.optJSONArray(r);if(row==null)continue;xml.append("<row r=\"").append(r+1).append("\">");
            for(int c=0;c<row.length();c++){
                Object val=row.opt(c);String ref=colName(c+1)+(r+1);String h=header==null?"":header.optString(c,"").toLowerCase(Locale.ROOT);boolean moneyCol=h.contains("monto")||h.contains("saldo")||h.contains("total")||h.contains("capital")||h.contains("ganancia")||h.contains("cobrado")||h.contains("efectivo")||h.equals("qr")||h.contains("penalidad")||h.contains("pagado")||h.contains("prestado")||h.contains("valor");
                if(r>0 && val instanceof Number){xml.append("<c r=\"").append(ref).append("\"");if(moneyCol)xml.append(" s=\"2\"");xml.append("><v>").append(((Number)val).doubleValue()).append("</v></c>");}
                else {xml.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"");if(r==0)xml.append(" s=\"1\"");xml.append("><is><t xml:space=\"preserve\">").append(xmlText(val==null?"":String.valueOf(val))).append("</t></is></c>");}
            }
            xml.append("</row>");
        }
        xml.append("</sheetData>");if(rows.length()>0&&maxCols>0)xml.append("<autoFilter ref=\"A1:").append(colName(maxCols)).append(Math.max(1,rows.length())).append("\"/>");xml.append("</worksheet>");return xml.toString();
    }

    private String colName(int col) { StringBuilder s=new StringBuilder();int n=col;while(n>0){n--;s.insert(0,(char)('A'+(n%26)));n/=26;}return s.toString(); }

    private void startGoogleAuthorization(int action, boolean forceAccountSelection) {
        pendingGoogleAction = action;
        pendingForceAccountSelection = forceAccountSelection;

        Scope driveScope = new Scope(DRIVE_APPDATA_SCOPE);
        AuthorizationRequest.Builder builder = AuthorizationRequest.builder()
                .setRequestedScopes(Arrays.asList(driveScope));

        if (forceAccountSelection) {
            builder.setPrompt(AuthorizationRequest.Prompt.SELECT_ACCOUNT);
        }

        authorizationClient.authorize(builder.build())
                .addOnSuccessListener(this::handleAuthorizationResult)
                .addOnFailureListener(e -> {
                    pendingGoogleAction = GOOGLE_ACTION_NONE;
                    pendingForceAccountSelection = false;
                    Toast.makeText(this, "No se pudo conectar con Google", Toast.LENGTH_LONG).show();
                    Log.e(TAG, "Authorization failed", e);
                });
    }

    private void handleAuthorizationResult(AuthorizationResult result) {
        if (result == null) {
            Toast.makeText(this, "No se pudo autorizar Google Drive", Toast.LENGTH_SHORT).show();
            return;
        }
        if (result.hasResolution()) {
            PendingIntent pendingIntent = result.getPendingIntent();
            if (pendingIntent == null) {
                Toast.makeText(this, "No se pudo abrir la selección de cuenta", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                startIntentSenderForResult(
                        pendingIntent.getIntentSender(),
                        REQ_GOOGLE_AUTH,
                        null,
                        0, 0, 0
                );
            } catch (IntentSender.SendIntentException e) {
                Toast.makeText(this, "No se pudo abrir Google", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Resolution launch failed", e);
            }
            return;
        }
        handleAuthorizedToken(result);
    }

    private void handleAuthorizedToken(AuthorizationResult result) {
        final String accessToken = result.getAccessToken();
        if (accessToken == null || accessToken.isEmpty()) {
            Toast.makeText(this, "Google no devolvió autorización para Drive", Toast.LENGTH_LONG).show();
            pendingGoogleAction = GOOGLE_ACTION_NONE;
            return;
        }

        final int action = pendingGoogleAction;
        pendingGoogleAction = GOOGLE_ACTION_NONE;
        pendingForceAccountSelection = false;

        cloudExecutor.execute(() -> {
            try {
                String email = fetchGoogleDriveEmail(accessToken);
                if (email != null && !email.isEmpty()) {
                    getSharedPreferences("taca_backup", MODE_PRIVATE)
                            .edit()
                            .putString("google_email", email)
                            .apply();
                }

                if (action == GOOGLE_ACTION_BACKUP) {
                    String json = pendingDriveBackupJson;
                    if (json == null) throw new Exception("No hay datos para respaldar");
                    saveBackupToGoogleDrive(accessToken, json);
                    long now = System.currentTimeMillis();
                    getSharedPreferences("taca_backup", MODE_PRIVATE)
                            .edit()
                            .putLong("last_backup_at", now)
                            .apply();
                    pendingDriveBackupJson = null;
                    runOnUiThread(() -> {
                        notifyBackupSaved(now);
                        Toast.makeText(this, "Copia guardada en la cuenta de Google", Toast.LENGTH_SHORT).show();
                    });
                } else if (action == GOOGLE_ACTION_RESTORE) {
                    String json = readBackupFromGoogleDrive(accessToken);
                    runOnUiThread(() -> {
                        String js = "window.receiveCloudBackup && window.receiveCloudBackup(" + JSONObject.quote(json) + ")";
                        webView.evaluateJavascript(js, null);
                        Toast.makeText(this, "Copia encontrada en Google Drive", Toast.LENGTH_SHORT).show();
                    });
                } else {
                    runOnUiThread(() -> {
                        if (webView != null) webView.evaluateJavascript("window.refreshGoogleBackupStatus && window.refreshGoogleBackupStatus()", null);
                        Toast.makeText(this, "Cuenta de Google vinculada", Toast.LENGTH_SHORT).show();
                    });
                }
            } catch (Exception e) {
                Log.e(TAG, "Drive operation failed", e);
                runOnUiThread(() -> Toast.makeText(this, e.getMessage() == null ? "No se pudo completar la operación en Google Drive" : e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private String fetchGoogleDriveEmail(String accessToken) throws Exception {
        String response = httpRequest(
                "GET",
                "https://www.googleapis.com/drive/v3/about?fields=user(emailAddress)",
                accessToken,
                null,
                null
        );
        JSONObject obj = new JSONObject(response);
        JSONObject user = obj.optJSONObject("user");
        return user == null ? "" : user.optString("emailAddress", "");
    }

    private void saveBackupToGoogleDrive(String accessToken, String json) throws Exception {
        String name = DRIVE_BACKUP_PREFIX + System.currentTimeMillis() + ".json";
        JSONObject metadata = new JSONObject();
        metadata.put("name", name);
        JSONArray parents = new JSONArray();
        parents.put("appDataFolder");
        metadata.put("parents", parents);

        String created = httpRequest(
                "POST",
                "https://www.googleapis.com/drive/v3/files?fields=id",
                accessToken,
                "application/json; charset=UTF-8",
                metadata.toString().getBytes(StandardCharsets.UTF_8)
        );
        String fileId = new JSONObject(created).optString("id", "");
        if (fileId.isEmpty()) throw new Exception("No se pudo crear la copia en Google Drive");

        httpRequest(
                "PATCH",
                "https://www.googleapis.com/upload/drive/v3/files/" + URLEncoder.encode(fileId, "UTF-8") + "?uploadType=media",
                accessToken,
                "application/json; charset=UTF-8",
                json.getBytes(StandardCharsets.UTF_8)
        );
        cleanupOldDriveBackups(accessToken);
    }

    private String readBackupFromGoogleDrive(String accessToken) throws Exception {
        String fileId = findDriveBackupFileId(accessToken);
        if (fileId == null || fileId.isEmpty()) {
            throw new Exception("No se encontró una copia de PrestaPro en esta cuenta");
        }
        return httpRequest(
                "GET",
                "https://www.googleapis.com/drive/v3/files/" + URLEncoder.encode(fileId, "UTF-8") + "?alt=media",
                accessToken,
                null,
                null
        );
    }

    private JSONArray listDriveBackupFiles(String accessToken) throws Exception {
        String q = URLEncoder.encode("'appDataFolder' in parents", "UTF-8");
        String url = "https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&pageSize=50&fields=files(id,name,modifiedTime)&orderBy=modifiedTime%20desc&q=" + q;
        String response = httpRequest("GET", url, accessToken, null, null);
        JSONArray all = new JSONObject(response).optJSONArray("files");
        JSONArray backups = new JSONArray();
        if (all != null) {
            for (int i = 0; i < all.length(); i++) {
                JSONObject f = all.getJSONObject(i);
                String n = f.optString("name", "");
                if (n.startsWith(DRIVE_BACKUP_PREFIX) || n.equals(DRIVE_BACKUP_NAME) || n.equals("TACA_Money_Respaldo.json")) backups.put(f);
            }
        }
        return backups;
    }

    private String findDriveBackupFileId(String accessToken) throws Exception {
        JSONArray files = listDriveBackupFiles(accessToken);
        if (files.length() == 0) return null;
        return files.getJSONObject(0).optString("id", null);
    }

    private void cleanupOldDriveBackups(String accessToken) {
        try {
            JSONArray files = listDriveBackupFiles(accessToken);
            int keptGenerations = 0;
            for (int i = 0; i < files.length(); i++) {
                JSONObject f = files.getJSONObject(i);
                String name = f.optString("name", "");
                if (!name.startsWith(DRIVE_BACKUP_PREFIX)) continue;
                keptGenerations++;
                if (keptGenerations > DRIVE_BACKUP_KEEP) {
                    String id = f.optString("id", "");
                    if (!id.isEmpty()) {
                        httpRequest("DELETE",
                                "https://www.googleapis.com/drive/v3/files/" + URLEncoder.encode(id, "UTF-8"),
                                accessToken, null, null);
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private String httpRequest(String method, String urlText, String accessToken, String contentType, byte[] body) throws Exception {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlText);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod(method);
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(30000);
            conn.setRequestProperty("Authorization", "Bearer " + accessToken);
            conn.setRequestProperty("Accept", "application/json");
            if (contentType != null) conn.setRequestProperty("Content-Type", contentType);

            if (body != null) {
                conn.setDoOutput(true);
                conn.setFixedLengthStreamingMode(body.length);
                try (OutputStream out = conn.getOutputStream()) {
                    out.write(body);
                    out.flush();
                }
            }

            int code = conn.getResponseCode();
            InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
            StringBuilder sb = new StringBuilder();
            if (stream != null) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) sb.append(line);
                }
            }

            if (code < 200 || code >= 300) {
                String detail = sb.toString();
                if (code == 401 || code == 403) throw new Exception("Google Drive rechazó el acceso. Revisa la cuenta y los permisos.");
                throw new Exception("Error de Google Drive (" + code + ")" + (detail.isEmpty() ? "" : ": " + detail));
            }
            return sb.toString();
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private void writeBackupToUri(Uri uri, String json) throws Exception {
        try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
            if (out == null) throw new Exception("No se pudo abrir el respaldo");
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.flush();
        }
    }

    private String readTextFromUri(Uri uri) throws Exception {
        StringBuilder sb = new StringBuilder();
        InputStream input = getContentResolver().openInputStream(uri);
        if (input == null) throw new Exception("No se pudo abrir el respaldo");
        try (InputStream in = input;
             BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private void notifyBackupSaved(long timestamp) {
        if (webView != null) {
            webView.evaluateJavascript("window.onCloudBackupSaved && window.onCloudBackupSaved(" + timestamp + ")", null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_FILE_CHOOSER) {
            if (filePathCallback != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK) {
                    Uri chosen = null;
                    if (data != null && data.getData() != null) chosen = data.getData();
                    else if (pendingImageChooser && pendingCameraUri != null) chosen = pendingCameraUri;
                    if (chosen != null) result = new Uri[]{chosen};
                }

                if (pendingImageChooser && pendingCameraUri != null && (result == null || result[0] == null || !pendingCameraUri.equals(result[0]))) {
                    try { getContentResolver().delete(pendingCameraUri, null, null); } catch (Exception ignored) {}
                }
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
            pendingCameraUri = null;
            pendingImageChooser = false;
            return;
        }

        if (requestCode == REQ_GOOGLE_AUTH) {
            if (resultCode == RESULT_OK && data != null) {
                try {
                    AuthorizationResult result = authorizationClient.getAuthorizationResultFromIntent(data);
                    handleAuthorizedToken(result);
                } catch (ApiException e) {
                    Toast.makeText(this, "No se pudo autorizar la cuenta de Google", Toast.LENGTH_LONG).show();
                    Log.e(TAG, "Authorization result failed", e);
                }
            } else {
                pendingGoogleAction = GOOGLE_ACTION_NONE;
                pendingDriveBackupJson = null;
                Toast.makeText(this, "Operación cancelada", Toast.LENGTH_SHORT).show();
            }
            return;
        }

        if (requestCode == REQ_SAVE_RECEIPT_PDF) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingReceiptPdfBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) {
                        out.write(pendingReceiptPdfBytes);
                        out.flush();
                        Toast.makeText(this, "PDF guardado", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "No se pudo guardar el PDF", Toast.LENGTH_SHORT).show();
                }
            }
            pendingReceiptPdfBytes = null;
            pendingReceiptPdfName = null;
            return;
        }

        if (requestCode == REQ_SAVE_FINANCE_XLSX || requestCode == REQ_SAVE_FINANCE_CSV) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingFinanceBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) {
                        out.write(pendingFinanceBytes);
                        out.flush();
                        Toast.makeText(this, requestCode == REQ_SAVE_FINANCE_XLSX ? "Excel guardado" : "CSV guardado", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "No se pudo guardar la exportación", Toast.LENGTH_SHORT).show();
                }
            }
            pendingFinanceBytes = null;
            pendingFinanceName = null;
            pendingFinanceMime = null;
            return;
        }

        if (requestCode == REQ_SAVE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) {
                        out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                        out.flush();
                        Toast.makeText(this, "Respaldo guardado", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "No se pudo guardar el respaldo", Toast.LENGTH_SHORT).show();
                }
            }
            pendingBackupJson = null;
        }
    }


    @Override
    protected void onDestroy() {
        cloudExecutor.shutdownNow();
        receiptExecutor.shutdownNow();
        try { if (billingClient != null) billingClient.endConnection(); } catch (Exception ignored) {}
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidApp");
            webView.destroy();
        }
        super.onDestroy();
    }
}
