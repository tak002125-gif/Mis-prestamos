package com.remberto.misprestamos;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONArray;
import org.json.JSONObject;

import com.google.android.gms.auth.api.identity.AuthorizationClient;
import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.ApiException;

public class MainActivity extends Activity {
    private static final int REQ_FILE_CHOOSER = 1001;
    private static final int REQ_SAVE_BACKUP = 1002;
    private static final int REQ_NOTIFICATIONS = 1003;
    private static final int REQ_DRIVE_BACKUP_DEST = 1004;
    private static final int REQ_DRIVE_RESTORE = 1005;
    private static final int REQ_GOOGLE_AUTH = 1006;
    private static final String DRIVE_APPDATA_SCOPE = "https://www.googleapis.com/auth/drive.appdata";
    private static final String DRIVE_BACKUP_NAME = "TACA_Money_Respaldo.json";
    private static final String TAG = "TACA_GOOGLE";
    private static final int GOOGLE_ACTION_NONE = 0;
    private static final int GOOGLE_ACTION_BACKUP = 1;
    private static final int GOOGLE_ACTION_RESTORE = 2;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingBackupJson;
    private String pendingDriveBackupJson;
    private Uri pendingCameraUri;
    private boolean pendingImageChooser;
    private AuthorizationClient authorizationClient;
    private final ExecutorService cloudExecutor = Executors.newSingleThreadExecutor();
    private int pendingGoogleAction = GOOGLE_ACTION_NONE;
    private boolean pendingForceAccountSelection = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Solución ya probada en HyperOS: el contenido comienza debajo de la barra de estado.
        getWindow().setStatusBarColor(Color.rgb(246, 247, 251));
        getWindow().setNavigationBarColor(Color.BLACK);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(246, 247, 251));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(246, 247, 251));

        int statusBarHeight = 0;
        int statusBarId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (statusBarId > 0) statusBarHeight = getResources().getDimensionPixelSize(statusBarId);
        FrameLayout.LayoutParams webParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        );
        webParams.topMargin = statusBarHeight;
        root.addView(webView, webParams);
        setContentView(root);

        authorizationClient = Identity.getAuthorizationClient(this);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);
        webView.setInitialScale(100);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> filePath,
                    FileChooserParams fileChooserParams) {

                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = filePath;
                pendingCameraUri = null;
                pendingImageChooser = false;

                String accept = "";
                try {
                    String[] types = fileChooserParams.getAcceptTypes();
                    if (types != null && types.length > 0 && types[0] != null) accept = types[0];
                } catch (Exception ignored) {}

                try {
                    if (accept.startsWith("image/")) {
                        pendingImageChooser = true;
                        Intent gallery = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        gallery.addCategory(Intent.CATEGORY_OPENABLE);
                        gallery.setType("image/*");

                        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        if (camera.resolveActivity(getPackageManager()) != null) {
                            ContentValues values = new ContentValues();
                            values.put(MediaStore.Images.Media.DISPLAY_NAME, "garantia_" + System.currentTimeMillis() + ".jpg");
                            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/TACA Money/Garantias");
                            }
                            pendingCameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                            if (pendingCameraUri != null) {
                                camera.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
                                camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                Intent chooser = Intent.createChooser(gallery, "Foto de la garantía");
                                chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                                startActivityForResult(chooser, REQ_FILE_CHOOSER);
                                return true;
                            }
                        }
                        startActivityForResult(gallery, REQ_FILE_CHOOSER);
                        return true;
                    }

                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    startActivityForResult(intent, REQ_FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    pendingCameraUri = null;
                    pendingImageChooser = false;
                    Toast.makeText(MainActivity.this, "No se pudo abrir el selector de archivos", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidApp");
        webView.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void exportBackup(String json) {
            runOnUiThread(() -> {
                pendingBackupJson = json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "respaldo-taca-money.json");
                try {
                    startActivityForResult(intent, REQ_SAVE_BACKUP);
                } catch (Exception e) {
                    pendingBackupJson = null;
                    Toast.makeText(MainActivity.this, "No se pudo abrir el guardado de archivos", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void backupToDrive(String json) {
            runOnUiThread(() -> {
                pendingDriveBackupJson = json;
                startGoogleAuthorization(GOOGLE_ACTION_BACKUP, false);
            });
        }

        @JavascriptInterface
        public void chooseDriveBackupLocation(String json) {
            runOnUiThread(() -> {
                pendingDriveBackupJson = json;
                startGoogleAuthorization(GOOGLE_ACTION_BACKUP, true);
            });
        }

        @JavascriptInterface
        public void restoreFromDrive() {
            runOnUiThread(() -> startGoogleAuthorization(GOOGLE_ACTION_RESTORE, false));
        }

        @JavascriptInterface
        public void linkGoogleAccount() {
            runOnUiThread(() -> startGoogleAuthorization(GOOGLE_ACTION_NONE, true));
        }

        @JavascriptInterface
        public String getAppVersion() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "2.7";
            }
        }

        @JavascriptInterface
        public String getCloudBackupStatus() {
            long last = getSharedPreferences("taca_backup", MODE_PRIVATE).getLong("last_backup_at", 0L);
            String email = getSharedPreferences("taca_backup", MODE_PRIVATE).getString("google_email", "");
            boolean linked = email != null && !email.isEmpty();
            JSONObject out = new JSONObject();
            try {
                out.put("linked", linked);
                out.put("email", email == null ? "" : email);
                out.put("lastBackupAt", last);
            } catch (Exception ignored) {}
            return out.toString();
        }

        @JavascriptInterface
        public void shareReceipt(String dataUrl, String fileName) {
            runOnUiThread(() -> {
                try {
                    String base64 = dataUrl;
                    int comma = dataUrl.indexOf(',');
                    if (comma >= 0) base64 = dataUrl.substring(comma + 1);
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);

                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName == null ? "recibo-taca-money.png" : fileName);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/TACA Money");
                        values.put(MediaStore.Images.Media.IS_PENDING, 1);
                    }

                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("No se pudo crear el archivo del recibo");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("No se pudo escribir el recibo");
                        out.write(bytes);
                        out.flush();
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues ready = new ContentValues();
                        ready.put(MediaStore.Images.Media.IS_PENDING, 0);
                        getContentResolver().update(uri, ready, null, null);
                    }

                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("image/png");
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share, "Compartir recibo"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No se pudo compartir el recibo", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void shareToWhatsApp(String dataUrl, String fileName) {
            runOnUiThread(() -> {
                try {
                    String base64 = dataUrl;
                    int comma = dataUrl.indexOf(',');
                    if (comma >= 0) base64 = dataUrl.substring(comma + 1);
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);

                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName == null ? "recordatorio-taca-money.png" : fileName);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/TACA Money");
                        values.put(MediaStore.Images.Media.IS_PENDING, 1);
                    }

                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("No se pudo crear la imagen del recordatorio");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("No se pudo escribir la imagen del recordatorio");
                        out.write(bytes);
                        out.flush();
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues ready = new ContentValues();
                        ready.put(MediaStore.Images.Media.IS_PENDING, 0);
                        getContentResolver().update(uri, ready, null, null);
                    }

                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("image/png");
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                    try {
                        share.setPackage("com.whatsapp");
                        startActivity(share);
                    } catch (Exception normalMissing) {
                        try {
                            share.setPackage("com.whatsapp.w4b");
                            startActivity(share);
                        } catch (Exception businessMissing) {
                            share.setPackage(null);
                            startActivity(Intent.createChooser(share, "Compartir recordatorio"));
                        }
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No se pudo compartir el recordatorio", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void syncAlerts(String json, int hour, int minute) {
            getSharedPreferences("taca_alerts", MODE_PRIVATE)
                    .edit()
                    .putString("alerts_json", json == null ? "[]" : json)
                    .putInt("hour", Math.max(0, Math.min(23, hour)))
                    .putInt("minute", Math.max(0, Math.min(59, minute)))
                    .apply();
            NotificationReceiver.schedule(MainActivity.this, hour, minute);
        }
    }

    private void startGoogleAuthorization(int action, boolean forceAccountSelection) {
        pendingGoogleAction = action;
        pendingForceAccountSelection = forceAccountSelection;

        Scope driveScope = new Scope(DRIVE_APPDATA_SCOPE);
        AuthorizationRequest.Builder builder = AuthorizationRequest.builder()
                .setRequestedScopes(Arrays.asList(driveScope));

        if (forceAccountSelection) {
            builder.setPrompt(AuthorizationRequest.Prompt.SELECT_ACCOUNT);
        }

        authorizationClient.authorize(builder.build())
                .addOnSuccessListener(this::handleAuthorizationResult)
                .addOnFailureListener(e -> {
                    pendingGoogleAction = GOOGLE_ACTION_NONE;
                    pendingForceAccountSelection = false;
                    Toast.makeText(this, "No se pudo conectar con Google", Toast.LENGTH_LONG).show();
                    Log.e(TAG, "Authorization failed", e);
                });
    }

    private void handleAuthorizationResult(AuthorizationResult result) {
        if (result == null) {
            Toast.makeText(this, "No se pudo autorizar Google Drive", Toast.LENGTH_SHORT).show();
            return;
        }
        if (result.hasResolution()) {
            PendingIntent pendingIntent = result.getPendingIntent();
            if (pendingIntent == null) {
                Toast.makeText(this, "No se pudo abrir la selección de cuenta", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                startIntentSenderForResult(
                        pendingIntent.getIntentSender(),
                        REQ_GOOGLE_AUTH,
                        null,
                        0, 0, 0
                );
            } catch (IntentSender.SendIntentException e) {
                Toast.makeText(this, "No se pudo abrir Google", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Resolution launch failed", e);
            }
            return;
        }
        handleAuthorizedToken(result);
    }

    private void handleAuthorizedToken(AuthorizationResult result) {
        final String accessToken = result.getAccessToken();
        if (accessToken == null || accessToken.isEmpty()) {
            Toast.makeText(this, "Google no devolvió autorización para Drive", Toast.LENGTH_LONG).show();
            pendingGoogleAction = GOOGLE_ACTION_NONE;
            return;
        }

        final int action = pendingGoogleAction;
        pendingGoogleAction = GOOGLE_ACTION_NONE;
        pendingForceAccountSelection = false;

        cloudExecutor.execute(() -> {
            try {
                String email = fetchGoogleDriveEmail(accessToken);
                if (email != null && !email.isEmpty()) {
                    getSharedPreferences("taca_backup", MODE_PRIVATE)
                            .edit()
                            .putString("google_email", email)
                            .apply();
                }

                if (action == GOOGLE_ACTION_BACKUP) {
                    String json = pendingDriveBackupJson;
                    if (json == null) throw new Exception("No hay datos para respaldar");
                    saveBackupToGoogleDrive(accessToken, json);
                    long now = System.currentTimeMillis();
                    getSharedPreferences("taca_backup", MODE_PRIVATE)
                            .edit()
                            .putLong("last_backup_at", now)
                            .apply();
                    pendingDriveBackupJson = null;
                    runOnUiThread(() -> {
                        notifyBackupSaved(now);
                        Toast.makeText(this, "Copia guardada en la cuenta de Google", Toast.LENGTH_SHORT).show();
                    });
                } else if (action == GOOGLE_ACTION_RESTORE) {
                    String json = readBackupFromGoogleDrive(accessToken);
                    runOnUiThread(() -> {
                        String js = "window.receiveCloudBackup && window.receiveCloudBackup(" + JSONObject.quote(json) + ")";
                        webView.evaluateJavascript(js, null);
                        Toast.makeText(this, "Copia encontrada en Google Drive", Toast.LENGTH_SHORT).show();
                    });
                } else {
                    runOnUiThread(() -> {
                        if (webView != null) webView.evaluateJavascript("window.refreshGoogleBackupStatus && window.refreshGoogleBackupStatus()", null);
                        Toast.makeText(this, "Cuenta de Google vinculada", Toast.LENGTH_SHORT).show();
                    });
                }
            } catch (Exception e) {
                Log.e(TAG, "Drive operation failed", e);
                runOnUiThread(() -> Toast.makeText(this, e.getMessage() == null ? "No se pudo completar la operación en Google Drive" : e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private String fetchGoogleDriveEmail(String accessToken) throws Exception {
        String response = httpRequest(
                "GET",
                "https://www.googleapis.com/drive/v3/about?fields=user(emailAddress)",
                accessToken,
                null,
                null
        );
        JSONObject obj = new JSONObject(response);
        JSONObject user = obj.optJSONObject("user");
        return user == null ? "" : user.optString("emailAddress", "");
    }

    private void saveBackupToGoogleDrive(String accessToken, String json) throws Exception {
        String fileId = findDriveBackupFileId(accessToken);
        if (fileId == null || fileId.isEmpty()) {
            JSONObject metadata = new JSONObject();
            metadata.put("name", DRIVE_BACKUP_NAME);
            JSONArray parents = new JSONArray();
            parents.put("appDataFolder");
            metadata.put("parents", parents);

            String created = httpRequest(
                    "POST",
                    "https://www.googleapis.com/drive/v3/files?fields=id",
                    accessToken,
                    "application/json; charset=UTF-8",
                    metadata.toString().getBytes(StandardCharsets.UTF_8)
            );
            fileId = new JSONObject(created).optString("id", "");
            if (fileId.isEmpty()) throw new Exception("No se pudo crear la copia en Google Drive");
        }

        httpRequest(
                "PATCH",
                "https://www.googleapis.com/upload/drive/v3/files/" + URLEncoder.encode(fileId, "UTF-8") + "?uploadType=media",
                accessToken,
                "application/json; charset=UTF-8",
                json.getBytes(StandardCharsets.UTF_8)
        );
    }

    private String readBackupFromGoogleDrive(String accessToken) throws Exception {
        String fileId = findDriveBackupFileId(accessToken);
        if (fileId == null || fileId.isEmpty()) {
            throw new Exception("No se encontró una copia de TACA Money en esta cuenta");
        }
        return httpRequest(
                "GET",
                "https://www.googleapis.com/drive/v3/files/" + URLEncoder.encode(fileId, "UTF-8") + "?alt=media",
                accessToken,
                null,
                null
        );
    }

    private String findDriveBackupFileId(String accessToken) throws Exception {
        String q = URLEncoder.encode("name='" + DRIVE_BACKUP_NAME.replace("'", "\\'") + "' and 'appDataFolder' in parents", "UTF-8");
        String url = "https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&pageSize=10&fields=files(id,name,modifiedTime)&orderBy=modifiedTime%20desc&q=" + q;
        String response = httpRequest("GET", url, accessToken, null, null);
        JSONArray files = new JSONObject(response).optJSONArray("files");
        if (files == null || files.length() == 0) return null;
        return files.getJSONObject(0).optString("id", null);
    }

    private String httpRequest(String method, String urlText, String accessToken, String contentType, byte[] body) throws Exception {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlText);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod(method);
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(30000);
            conn.setRequestProperty("Authorization", "Bearer " + accessToken);
            conn.setRequestProperty("Accept", "application/json");
            if (contentType != null) conn.setRequestProperty("Content-Type", contentType);

            if (body != null) {
                conn.setDoOutput(true);
                conn.setFixedLengthStreamingMode(body.length);
                try (OutputStream out = conn.getOutputStream()) {
                    out.write(body);
                    out.flush();
                }
            }

            int code = conn.getResponseCode();
            InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
            StringBuilder sb = new StringBuilder();
            if (stream != null) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) sb.append(line);
                }
            }

            if (code < 200 || code >= 300) {
                String detail = sb.toString();
                if (code == 401 || code == 403) throw new Exception("Google Drive rechazó el acceso. Revisa la cuenta y los permisos.");
                throw new Exception("Error de Google Drive (" + code + ")" + (detail.isEmpty() ? "" : ": " + detail));
            }
            return sb.toString();
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private void writeBackupToUri(Uri uri, String json) throws Exception {
        try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
            if (out == null) throw new Exception("No se pudo abrir el respaldo");
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.flush();
        }
    }

    private String readTextFromUri(Uri uri) throws Exception {
        StringBuilder sb = new StringBuilder();
        InputStream input = getContentResolver().openInputStream(uri);
        if (input == null) throw new Exception("No se pudo abrir el respaldo");
        try (InputStream in = input;
             BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private void notifyBackupSaved(long timestamp) {
        if (webView != null) {
            webView.evaluateJavascript("window.onCloudBackupSaved && window.onCloudBackupSaved(" + timestamp + ")", null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_FILE_CHOOSER) {
            if (filePathCallback != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK) {
                    Uri chosen = null;
                    if (data != null && data.getData() != null) chosen = data.getData();
                    else if (pendingImageChooser && pendingCameraUri != null) chosen = pendingCameraUri;
                    if (chosen != null) result = new Uri[]{chosen};
                }

                if (pendingImageChooser && pendingCameraUri != null && (result == null || result[0] == null || !pendingCameraUri.equals(result[0]))) {
                    try { getContentResolver().delete(pendingCameraUri, null, null); } catch (Exception ignored) {}
                }
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
            pendingCameraUri = null;
            pendingImageChooser = false;
            return;
        }

        if (requestCode == REQ_GOOGLE_AUTH) {
            if (resultCode == RESULT_OK && data != null) {
                try {
                    AuthorizationResult result = authorizationClient.getAuthorizationResultFromIntent(data);
                    handleAuthorizedToken(result);
                } catch (ApiException e) {
                    Toast.makeText(this, "No se pudo autorizar la cuenta de Google", Toast.LENGTH_LONG).show();
                    Log.e(TAG, "Authorization result failed", e);
                }
            } else {
                pendingGoogleAction = GOOGLE_ACTION_NONE;
                pendingDriveBackupJson = null;
                Toast.makeText(this, "Operación cancelada", Toast.LENGTH_SHORT).show();
            }
            return;
        }

        if (requestCode == REQ_SAVE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) {
                        out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                        out.flush();
                        Toast.makeText(this, "Respaldo guardado", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "No se pudo guardar el respaldo", Toast.LENGTH_SHORT).show();
                }
            }
            pendingBackupJson = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        cloudExecutor.shutdownNow();
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidApp");
            webView.destroy();
        }
        super.onDestroy();
    }
}
