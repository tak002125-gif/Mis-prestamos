
window.addEventListener('load',function(){setTimeout(function(){var s=document.getElementById('prestaproSplash');if(s)s.classList.add('hide');},650);});
