# 3.22.58
Selector semanal de cuota completa o abono parcial; saldo restante destacado, campos inactivos ocultos y deshabilitados, traducciones de los controles nuevos. Sin cambios de cálculo ni persistencia. Compilación Android pendiente.
