'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const originalStage=fs.readFileSync('CAMBIOS_3.22.52.md','utf8');
function slice(start,end){const a=html.indexOf(start),b=html.indexOf(end,a);assert(a>=0&&b>a,`sección ${start}`);return html.slice(a,b)}
const source=slice('  function manualReminderStage(l){','  function reminderStageLabel(stage)')
           +slice('  function reminderMessage(l,stage){','  function wrapCanvasText(ctx,text')
           +slice('  function logReminderShare(action){','  async function shareReminder(preferWhatsApp)')
           +'\nglobalThis.underTest={manualReminderStage,reminderMessage,logReminderShare};';
let saves=0,renders=0;const context={
  reminderStage:l=>l.formal||null,
  debtBalance:l=>Math.max(0,l.balance+l.penalty),
  baseBalance:l=>Math.max(0,l.balance),
  penaltyBalance:l=>Math.max(0,l.penalty),
  overdueBeforeToday:l=>l.overdue,
  reminderKey:()=>'followup|2026-11-17|15',
  reminderTargetDate:()=> '2026-11-17',
  todayISO:()=> '2026-11-18',
  dateLabel:s=>s,
  money:n=>'BOB '+n.toFixed(2),
  regional:()=>({language:'es'}),
  loans:[],currentReminder:null,save:()=>{saves++},render:()=>{renders++}
};
vm.createContext(context);vm.runInContext(source,context);const {manualReminderStage,reminderMessage,logReminderShare}=context.underTest;
const loan={id:'A',client:'Cliente de prueba',balance:500,penalty:50,overdue:3,installmentAmount:50,collectionFrequency:'daily',reminders:[]};const copy=JSON.stringify(loan);
assert.equal(manualReminderStage(loan),'followup','penalidad vencida activa permite seguimiento manual');
assert.equal(JSON.stringify(loan),copy,'consultar recordatorio no modifica deuda ni penalidad');
const message=reminderMessage(loan,'followup');
for(const text of ['Cliente de prueba','BOB 500.00','BOB 50.00','BOB 550.00'])assert(message.includes(text),text);
assert.equal(manualReminderStage({...loan,penalty:0}),'followup','deuda vencida sin penalidad');
assert.equal(manualReminderStage({...loan,collectionFrequency:'weekly'}),'followup','semanal vencido');
assert.equal(manualReminderStage({...loan,balance:0,penalty:50,overdue:0}),'followup','solo penalidad pendiente');
assert.equal(manualReminderStage({...loan,balance:0,penalty:0}),null,'préstamo saldado');
assert.equal(manualReminderStage({...loan,uncollectible:true}),null,'incobrable sin recordatorio');
assert.equal(manualReminderStage({...loan,closedWithCollateral:true}),null,'cerrado con garantía sin recordatorio');
assert.equal(manualReminderStage({...loan,penalty:0,overdue:0}),null,'no activa seguimiento antes del atraso');
assert.equal(manualReminderStage({...loan,formal:'late1'}),'late1','primer aviso formal conservado');
assert.equal(manualReminderStage({...loan,formal:'late2'}),'late2','segundo aviso formal conservado');
assert.equal(manualReminderStage({...loan,formal:'today'}),'today','recordatorio normal conservado');
// Cuando se comparte, cada seguimiento manual cuenta por separado, sin tocar monto o penalidad.
context.loans.push(loan);context.currentReminder={loanId:'A',stage:'followup',key:'followup|2026-11-17|15'};
logReminderShare('WhatsApp');logReminderShare('Compartido');
assert.equal(loan.reminders.length,2,'cada intento manual queda como entrada independiente');
assert.notEqual(loan.reminders[0].key,loan.reminders[1].key);
assert.equal(loan.reminders[0].stage,'followup');assert.equal(loan.reminders[1].stage,'followup');
assert.equal(loan.balance,500);assert.equal(loan.penalty,50);assert.equal(saves,2);assert.equal(renders,2);
// Asegura separación: ningún sistema de alarma crea followup automáticamente.
assert(html.includes('function reminderStageForNotification(l){const stage=reminderStage(l);'));
assert(!html.includes('function reminderStageForNotification(l){const stage=manualReminderStage(l);'));
assert(html.includes('const rStage=manualReminderStage(l),penaltyInfo='));
assert(html.includes("rStage==='followup'?t2.sendPendingReminder"));
assert(html.includes("const stage=manualReminderStage(l);if(!stage)"));
assert(html.includes("stage==='followup'?(regional().language==='en'?'PAYMENT PENDING'"));
assert(html.includes("stage==='followup'?t3.manualFollowup"));
assert(html.includes("Los avisos automáticos por atraso llegan como máximo hasta el segundo"));
assert(originalStage.includes('No agrega notificaciones automáticas'));
console.log('PASS v3.22.52: recordatorio manual por atraso con penalidad, importes correctos, diario/semanal, exclusiones, avisos formales, sin nuevas multas ni alarmas, historial de reenvíos');
