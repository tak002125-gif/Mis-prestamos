# Guía para probar PrestaPro 3.22.54

1. Confirmar respaldo reciente de PrestaPro en Google Drive. Instalar la APK firmada **encima** de la 3.22.53 (mismo applicationId/firma) sin desinstalar.
2. Verificar que sigan clientes, préstamos, 24 cuotas pagadas, historial, licencia y caja.
3. Entrar a Yessica → **Ver detalles y opciones**. Verificar que el botón **«Condonar penalización · Bs 50»** esté disponible y que el saldo sea Bs 50.
4. Abrir el botón: debe mostrar 24/24 cuotas, Bs 50 de penalización y saldo proyectado Bs 0.
5. Escribir el motivo, por ejemplo **«Excepción autorizada porque a la clienta le robaron el celular»**. La aplicación pide confirmación explícita antes de proceder.
6. Una vez confirmada la condonación, verificar: **Bs 1.200 realmente recibidos**, 24/24 cuotas, **Bs 50 condonados**, penalización pendiente Bs 0, saldo total Bs 0 y préstamo finalizado.
7. Abrir el historial de cambios y comprobar monto, motivo y fecha/hora. Verificar que no apareció un nuevo recibo de pago ni un ingreso nuevo en caja o Finanzas.
8. Cerrar y reabrir PrestaPro; confirmar que sigue en Bs 0 y no vuelve a cargarse la multa. Verificar que no existe opción de condonarla otra vez.
9. En otro préstamo diario ficticio con una cuota normal aún pendiente y multa pendiente, probar que solo se condona la multa y **permanece la cuota pendiente**, sin cierre falso.
10. Verificar que los préstamos semanales, las cuotas, los cobros mixtos, los recordatorios y «Buscar actualizaciones» funcionan como antes.

No utilizar cobros ficticios en los datos reales. Esta prueba requiere compilación de GitHub y verificación en el teléfono; las pruebas automatizadas no sustituyen la prueba de usuario.
