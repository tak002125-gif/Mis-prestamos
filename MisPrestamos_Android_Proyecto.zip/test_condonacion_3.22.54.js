const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const html=fs.readFileSync(path.join(__dirname,'app/src/main/assets/index.html'),'utf8');
const gradle=fs.readFileSync(path.join(__dirname,'app/build.gradle'),'utf8');
assert(gradle.includes('versionCode 131')&&gradle.includes('versionName "3.22.54"'));
function fn(name){const start=html.indexOf(`  function ${name}(`);assert(start>=0,`Falta ${name}`);const next=html.indexOf('\n  function ',start+5);return html.slice(start,next<0?undefined:next);}
function createLoan(overrides={}){
 return {id:'Y',client:'Yessica ferreira menacho',loanCode:'PRE-2026-0010',collectionFrequency:'daily',amount:1000,total:1200,paid:1200,penaltyCountAccrued:1,penaltyAmountAccrued:50,penaltyPaid:0,penaltyWaivedAmount:0,penaltyWaiverEvents:[],installments:24,installmentAmount:50,uncollectible:false,closedWithCollateral:false,auditTrail:[],payments:Array.from({length:17},(_,i)=>({paymentId:'test'+i,amount:i===16?50:0,voided:false})),...overrides};
}
let loan=createLoan(),saved=0,rendered=0,alerts=0,toasts=[],modalOpen=0,confirmationCount=0;
const els={'#penaltyWaiverSummary':{innerHTML:''},'#penaltyWaiverReason':{value:''}};
const ctx={loans:[loan],currentPenaltyWaiverLoanId:'',penaltyWaiverModal:{},$:id=>els[id],
 requireCommercialLicense:()=>true,money:n=>'Bs '+Number(n).toFixed(2),esc:x=>String(x).replace(/&/g,'&amp;'),
 todayISO:()=> '2026-11-20',overdueBeforeToday:()=> 5,loanRules:()=>({dailyPenaltyEnabled:true,dailyGraceMisses:2}),
 openModal:()=>modalOpen++,closeModal:()=>modalOpen--,save:()=>saved++,render:()=>rendered++,syncNativeAlerts:()=>alerts++,toast:m=>toasts.push(m),
 confirm:msg=>{confirmationCount++;assert(msg.includes('No se registrará ningún cobro'));return true;},
 weeklyGuaranteeDefault:()=>false};
vm.createContext(ctx);
vm.runInContext(['paidInstallments','penaltyAccrued','penaltyWaived','penaltyBalance','baseBalanceRaw','baseBalance','totalDebt','debtBalance','refreshPenalty','addAudit','statusOf','openPenaltyWaiverModal','confirmPenaltyWaiver'].map(fn).join('\n'),ctx);
assert.equal(vm.runInContext('penaltyBalance(loans[0])',ctx),50);
assert.equal(vm.runInContext('debtBalance(loans[0])',ctx),50);
assert.equal(vm.runInContext('statusOf(loans[0])',ctx),'late');
vm.runInContext("openPenaltyWaiverModal('Y')",ctx);
assert.equal(modalOpen,1);assert(els['#penaltyWaiverSummary'].innerHTML.includes('Bs 50.00'));
let count=loan.payments.length;
els['#penaltyWaiverReason'].value='Robo del celular de la clienta; excepción autorizada';
vm.runInContext('confirmPenaltyWaiver()',ctx);
assert.equal(saved,1);assert.equal(alerts,1);assert.equal(rendered,1);assert.equal(confirmationCount,1);
assert.equal(loan.paid,1200,'cuotas sin cambios');assert.equal(loan.penaltyPaid,0,'multa no figura como pagada');assert.equal(loan.payments.length,count,'no crea un recibo falso');
assert.equal(loan.penaltyWaivedAmount,50);assert.equal(loan.penaltyWaiverEvents.length,1);assert.equal(loan.penaltyWaiverEvents[0].amount,50);
assert(loan.auditTrail.some(a=>a.type==='daily_penalty_waived'&&a.reason.includes('Robo del celular')));
assert.equal(vm.runInContext('penaltyBalance(loans[0])',ctx),0);assert.equal(vm.runInContext('totalDebt(loans[0])',ctx),1200);
assert.equal(vm.runInContext('debtBalance(loans[0])',ctx),0);assert.equal(vm.runInContext('statusOf(loans[0])',ctx),'paid');
vm.runInContext('refreshPenalty(loans[0])',ctx);assert.equal(vm.runInContext('debtBalance(loans[0])',ctx),0,'la condonación no se reabre en la siguiente comprobación');
vm.runInContext('confirmPenaltyWaiver()',ctx);assert.equal(loan.penaltyWaiverEvents.length,1,'no permite doble condonación');
assert.equal(saved,1,'no duplica movimientos');
loan=createLoan({id:'B',paid:1150});ctx.loans=[loan];
vm.runInContext("openPenaltyWaiverModal('B')",ctx);els['#penaltyWaiverReason'].value='Atraso justificado, penalización perdonada';vm.runInContext('confirmPenaltyWaiver()',ctx);
assert.equal(vm.runInContext('debtBalance(loans[0])',ctx),50,'si queda cuota, sigue pendiente solo la cuota');
assert.equal(vm.runInContext('statusOf(loans[0])',ctx),'late','aún puede tener cuotas vencidas');
assert(html.includes('waivePenaltyBtn')&&html.includes('id="penaltyWaiverModal"'));
assert(html.includes('l.penaltyWaiverEvents=Array.isArray(l.penaltyWaiverEvents)'));
assert(html.includes('penaltyWaiverModal,uncollectibleModal'));
assert(html.includes('No se recibió dinero.'));
console.log('PASS v3.22.54: condonar 50 sin cobro, 24/24 cuotas, 1200 recibidos, saldo 0, auditado, idempotente, estado finalizado; otros saldos intactos.');
