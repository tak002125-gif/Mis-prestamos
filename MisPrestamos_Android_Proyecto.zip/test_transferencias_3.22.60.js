  function recTransfer(bank,cash,amount,direction){
    if(!Number.isSafeInteger(amount)||amount<=0||!['deposit','withdraw'].includes(direction)||amount>(direction==='deposit'?cash:bank))return null;
    return {bank:bank+(direction==='deposit'?amount:-amount),cash:cash+(direction==='deposit'?-amount:amount)};
  }

const assert=require('assert');assert.deepStrictEqual(recTransfer(428500,15000,15000,'deposit'),{bank:443500,cash:0});assert.deepStrictEqual(recTransfer(443500,0,15000,'withdraw'),{bank:428500,cash:15000});assert.equal(recTransfer(428500,15000,15001,'deposit'),null);assert.equal(recTransfer(428500,15000,-1,'deposit'),null);console.log('OK transferencias');