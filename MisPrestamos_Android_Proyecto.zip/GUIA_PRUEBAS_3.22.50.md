# Guía de prueba — PrestaPro 3.22.50

**Antes de instalar en el Xiaomi con datos reales:** crear una copia actualizada en Google Drive. Instalar la APK firmada sobre la versión 3.22.49, sin desinstalar ni borrar datos.

1. Abrir **Préstamos → Nuevo préstamo → Cliente existente**.
2. Escribir parte del nombre de un cliente que exista (por ejemplo, «Edison», cuando corresponda). Deben mostrarse **solo** los clientes cuyo nombre contenga ese texto.
3. Si solo queda uno, pulsar la tecla **Buscar / Enter** del teclado. Debe seleccionarse su ficha, sin intentar guardar el préstamo.
4. Si hay varios clientes con el mismo nombre parcial, pulsar Buscar / Enter. Debe conservar las varias coincidencias sin escoger una al azar.
5. Buscar por CI/DNI y, si existe el dato, por parte del teléfono. Debe filtrar correctamente.
6. Probar nombres con tildes y sin ellas. Por ejemplo, «Maria» encuentra «María» si existe.
7. Buscar un nombre inexistente: aparece el mensaje de no coincidencias. Borrar la búsqueda: vuelve la lista completa.
8. Elegir un cliente existente y verificar que conserva nombre/documento y su historial al crear un préstamo.
9. Comprobar que **Finanzas**, clientes activos/finalizados, notificaciones y respaldo conservan su comportamiento anterior.

La prueba de los **cinco clientes gratuitos tras reinstalación en Samsung S9 Plus** sigue pendiente y no forma parte de esta actualización.
