# PrestaPro 3.22.53 — versionCode 130

## Corrección de cobros y penalización diaria

1. **Las cuotas y la penalización se cobran por separado**. En el modal Cobrar, seleccionar 8 cuotas de Bs 50 calcula Bs 400 para cuotas. El campo opcional «Penalización a cobrar ahora» empieza en Bs 0,00: el sistema nunca le resta automáticamente una multa a las cuotas. Si el cobrador decide percibir una penalización de Bs 50 además de las ocho cuotas, el total recibido pasa explícitamente a Bs 450.
2. **Penalización diaria única**: al superar el número de cuotas vencidas sin penalización (por defecto 2), se genera como máximo una penalización equivalente a una cuota por préstamo diario. No se vuelve a sumar otra cuota por el cuarto, quinto o posteriores días atrasados. Las penalizaciones de otras modalidades semanales no se cambian.
3. **Corregir pagos anteriores sin duplicar ingresos**: nueva distribución editable en «Corregir pago». Se mantiene el total recibido y se indica explícitamente qué parte correspondió a penalización. El resto va a cuotas, con motivo obligatorio, auditoría y actualización de Finanzas y caja. Se conservan anulaciones históricas.
4. **Recibos**: se muestran por separado «Aplicado a cuotas» y «Aplicado a penalización» para reflejar exactamente la distribución del importe recibido.
5. **Protección de movimientos antiguos**: NO modifica automáticamente las distribuciones de cobros ya registrados. Si el saldo pagado a penalidades supera el máximo de la nueva regla, avisa para que el titular revise/corrija los recibos correspondientes en la app.
6. Los textos de aceptación y cláusulas predeterminadas de nuevos préstamos describen la penalización única. El texto predeterminado global anterior se actualiza cuando no era personalizado. Las cláusulas y comprobantes de préstamos pasados no se reescriben retroactivamente.

## Caso ficticio de regresión (no incluye datos privados)

- Préstamo de Bs 1.000; total pactado Bs 1.200; 24 cuotas de Bs 50.
- Antes: pagados Bs 750 en 15 cuotas; recibo de Bs 400 erróneamente asignado Bs 300 a 6 cuotas y Bs 100 a multas; otro recibo de Bs 100 anulado.
- Después de corregir el recibo de Bs 400 con **penalización cobrada Bs 0**: Bs 400 aplicados a 8 cuotas, **23/24 cuotas pagadas**, Bs 1.150 recibidos reales, multa única pendiente Bs 50 y **saldo total pendiente Bs 100** (una cuota Bs 50 + multa Bs 50).
- La corrección no crea otro cobro ni recupera el recibo anulado.

## Publicación

Subir **solo** `MisPrestamos_Android_Proyecto.zip` a GitHub, reemplazando el archivo anterior del mismo nombre. Compilar APK release con la firma permanente de GitHub. Hacer respaldo en Google Drive antes de instalar encima de 3.22.52. No desinstalar.
