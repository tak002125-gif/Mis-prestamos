# PrestaPro v3.13.4

Actualización de la pestaña Finanzas:
- Navegación por pestañas: Resumen, Caja diaria e Historial.
- Caja y rendición diaria reorganizada y más compacta.
- Conciliación visual de efectivo, QR, total, clientes, pendientes, atrasados y recordatorios.
- Movimientos del día con filtro y acciones de Recibo/Corregir.
- Cierre automático de caja configurable por hora.
- Aviso 15 minutos antes del cierre automático.
- Programación nativa de Android para que el cierre quede registrado aunque la app no esté abierta; al volver a abrir PrestaPro el cierre se sincroniza con el historial de caja.
- Si Google Drive está vinculado, el cierre automático intenta crear respaldo al volver a la app.
- Conserva datos, licencia, préstamos, pagos, configuración y respaldos al instalar encima de la versión anterior.
