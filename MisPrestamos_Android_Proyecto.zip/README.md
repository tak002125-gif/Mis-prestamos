# PrestaPro 3.22.58 — versionCode 135

Proyecto Android de PrestaPro para GitHub Actions (edición comercial externa).

**Nueva mejora:** detección voluntaria de actualizaciones al abrir la app y opción de comprobación manual en **Ajustes > Buscar actualizaciones**. Cuando la página oficial publique una versión mayor, la app mostrará un aviso con «Más tarde» y «Actualizar ahora». Ver `CAMBIOS_3.22.51.md` y `GUIA_PRUEBAS_3.22.51.md`.

Se mantienen intactos los clientes, préstamos, pagos, licencias, calendarios, Finanzas, recordatorios y la mejora de búsqueda de 3.22.50. Se conserva `com.remberto.misprestamos`, alias de firma `taca_money` y almacenamiento local.

**No hay descargas ocultas ni auto-instalación:** la app solamente abre la web oficial en el navegador. Requiere internet únicamente para consultar si hay actualización.

**Despliegue por etapas:** primero compilar esta versión firmada desde GitHub; después publicar esa APK en Cloudflare junto con el archivo `version.json` del mismo código. Los usuarios de la 3.22.50 harán esta actualización manual una vez; luego recibirán avisos de versiones posteriores.

Para GitHub, subir únicamente el ZIP `MisPrestamos_Android_Proyecto.zip` con este proyecto en su raíz, reemplazando el archivo anterior del mismo nombre.

**v3.22.52:** nuevo seguimiento manual del pago pendiente tras los avisos formales, sin notificaciones ni penalidades adicionales. Ver `CAMBIOS_3.22.52.md` y `GUIA_PRUEBAS_3.22.52.md`.

**v3.22.53:** cuotas y multas separadas al cobrar, penalización diaria única tras superar dos vencidas, corrección auditable de distribución de recibos sin duplicar ingresos. Ver `CAMBIOS_3.22.53.md`, `GUIA_PRUEBAS_3.22.53.md` y `test_penalidad_separada_3.22.53.js`. No se reparan automáticamente los recibos históricos.

**v3.22.54:** condonación voluntaria, explícita y auditada de penalizaciones pendientes de préstamos diarios, sin registrar dinero ficticio; conserva cuotas, pagos, caja e historial. Ver `CAMBIOS_3.22.54.md`, `GUIA_PRUEBAS_3.22.54.md` y `test_condonacion_3.22.54.js`.

**v3.22.55:** cláusulas y multas independientes por modalidad diaria/semanal, textos de contratos editables, porcentaje semanal inicial configurable para nuevos préstamos. Configuración no retroactiva. Ver `CAMBIOS_3.22.55.md`, `GUIA_PRUEBAS_3.22.55.md` y `test_clausulas_independientes_3.22.55.js`.

**v3.22.56:** mejoras de lectura en Ajustes → Cláusulas y reglas. Controles Sí/No visibles en dos columnas, etiquetas y ayudas encima, campos numéricos a ancho completo, pestañas más legibles. Los mismos valores internos y reglas anteriores. Ver CAMBIOS_3.22.56.md.

**v3.22.58:** selector visual de modalidad de cobro semanal; sin cambios en las fórmulas ni persistencia.
