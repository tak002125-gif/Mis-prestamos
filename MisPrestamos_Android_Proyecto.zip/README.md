# PrestaPro v3.11.0 · Bloque 6

Base: v3.10.1 aprobada.

Incluye:
- Ajustes > Mi licencia.
- Código de dispositivo.
- Licencia offline firmada RSA/SHA-256.
- La APK contiene solo la clave pública; la clave privada queda fuera del repositorio.
- Valida firma, dispositivo autorizado y vencimiento.
- Muestra titular, plan, ID, emisión, vencimiento y dispositivos permitidos.
- Admite licencia permanente o temporal.
- La licencia puede estar en el respaldo, pero solo funciona en dispositivos autorizados.
- En esta primera prueba no se bloquean funciones por falta de licencia.
- No modifica préstamos, pagos, respaldos, notificaciones, reglas ni personalización.
