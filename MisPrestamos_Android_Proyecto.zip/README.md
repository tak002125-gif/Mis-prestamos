# PrestaPro v3.9.0 · Bloque 4

Base: v3.8.0 aprobada.

Incluye:
- Manual / Cada día / Cada semana / Cada mes.
- Automático seguro al abrir la app cuando corresponde.
- No crea copias automáticas de una base vacía.
- Drive usa generaciones y conserva hasta 5 copias recientes.
- Historial local con fecha, préstamos y pagos.
- Restauración muestra fecha y resumen antes de reemplazar datos.
- Compatible con respaldo legado TACA_Money_Respaldo.json.
- Sin WorkManager todavía; primero se prueba esta base segura.
