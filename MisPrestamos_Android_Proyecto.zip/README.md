# PrestaPro v3.12.1

Bloque 6 comercial.

- Licenciamiento comercial activo.
- Sin licencia válida: modo restringido, sin borrar datos.
- Se mantiene consulta de préstamos, finanzas, ajustes y creación/exportación de copias de seguridad.
- Se bloquean nuevos préstamos, cotizaciones, cobros, edición/eliminación, correcciones/anulaciones de pagos, recordatorios operativos, cierres/devoluciones de garantía, cierre de caja, restauración e importación destructiva.
- Licencias activas mantienen acceso completo.
- Licencias vencidas, inválidas o de otro dispositivo muestran el estado y mantienen los datos intactos.
- Tu licencia permanente v3.11.1 sigue siendo compatible.

versionCode: 47
versionName: 3.12.1


## Bloque 6.1 · Cierre de recordatorios en modo restringido
- Sin licencia activa, la pantalla de Alertas y recordatorios queda disponible solo para consulta de permisos y estado.
- Se bloquea cambiar la hora del aviso diario.
- Se bloquea programar la prueba de notificación en 1 minuto.
- Al quitar o perder la licencia, PrestaPro cancela la alarma diaria y cualquier prueba pendiente a nivel nativo.
- Al reactivar una licencia válida, la programación diaria vuelve a habilitarse automáticamente.
