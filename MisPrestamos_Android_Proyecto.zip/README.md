# TACA Money v3.0

Base: v2.9 estable.

Cambios principales:
- Rediseño inicial fintech/comercial del Inicio.
- Cabecera adaptable y botones Nuevo préstamo / Cotizar.
- Versión retirada de la cabecera principal.
- Ajustes reorganizados.
- Nuevo módulo Mi negocio.
- Personalización: nombre, logo, colores, WhatsApp, dirección y texto de marca.
- Logo/nombre personalizados en recibos y recordatorios.
- La configuración viaja dentro del respaldo existente.
- Se conserva la lógica de préstamos, cobros, caja, recordatorios y Google Drive de v2.9.

# TACA Money v2.9

Base: v2.8.1 estable.

## Control y rendición de cuentas
- Corrección de pagos ya registrados: método Efectivo/QR y monto.
- Toda corrección exige motivo y conserva fecha/hora en el historial de cambios.
- Un pago puede anularse sin borrarlo: queda marcado ANULADO con motivo y fecha/hora.
- Los pagos anulados dejan de sumar en finanzas y caja.
- Reenvío de recibos desde el historial de pagos y desde Caja diaria.
- Los recibos corregidos muestran la fecha y el motivo de la corrección.

## Caja diaria
- Resumen por fecha: Efectivo, QR y total cobrado.
- Clientes que pagaron, pendientes del día, préstamos atrasados y recordatorios enviados.
- Filtro de movimientos: Todos / Efectivo / QR.
- Campo opcional Efectivo contado y cálculo de diferencia contra el efectivo registrado.
- Cierre de caja guardado con fecha/hora.
- Si Google Drive está vinculado, al cerrar caja se intenta crear un respaldo automáticamente.
- Si luego se corrige o anula un pago de una caja ya cerrada, ese día se reabre para evitar conservar un cierre desactualizado.

## Historial
- Historial de cambios por préstamo para correcciones y anulaciones.
- Los registros originales no se eliminan silenciosamente.

## No incluido por decisión del usuario
- Foto del comprobante de pago.
- Número/referencia de operación QR.

VersionCode: 22
VersionName: 2.9
