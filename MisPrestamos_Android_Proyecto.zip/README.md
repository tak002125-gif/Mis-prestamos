# PrestaPro v3.7.0 · Bloque 2

Base: v3.6.0 aprobada por el usuario.

Incluye:
- Personalización completa de Mi negocio.
- Nombre, WhatsApp, dirección y pie de documentos.
- Logo local optimizado y persistente.
- Colores principal/secundario y restauración a colores PrestaPro.
- Vista previa en vivo dentro de Mi negocio.
- Datos del negocio en recibos, cotizaciones y recordatorios.
- Firma discreta 'PrestaPro · by Taca' / 'Generado con PrestaPro · by Taca'.
- Mantiene el fallback seguro del logo PrestaPro para compartir imágenes.
- No toca licencias, cláusulas ni copias automáticas.
