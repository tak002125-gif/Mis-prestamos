# PrestaPro 3.22.49 — versionCode 126

Proyecto Android completo para cargar a GitHub (archivo raíz `MisPrestamos_Android_Proyecto.zip`). Basado en la versión **3.22.48**, manteniendo el `applicationId`, la configuración de firma de GitHub y el almacenamiento local de clientes, préstamos, recibos y licencia.

**Mejora única:** en Finanzas → Desglose de ganancias, los clientes con préstamos pendientes aparecen primero, ordenados por próximo vencimiento; los que no tienen préstamos activos quedan abajo, ordenados por finalización más reciente. Al conceder un préstamo nuevo a un cliente previamente finalizado, su grupo vuelve arriba automáticamente, aun sin recibir pagos del préstamo nuevo.

Los importes, préstamos, cobros y estadísticas no cambian. El orden depende del estado completo del cliente, aunque el desglose muestre solo pagos filtrados.

Ver `CAMBIOS_3.22.49.md` y `GUIA_PRUEBAS_3.22.49.md`.

Las pruebas de lógica y presentación con datos ficticios se ejecutaron localmente. La compilación APK, verificación de firma y prueba final en Android siguen pendientes hasta que GitHub Actions genere el instalador.
