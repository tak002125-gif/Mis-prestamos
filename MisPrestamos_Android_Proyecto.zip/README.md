# TACA Money v2.1

Base: v2.0.

## Respaldo con cuenta de Google
- Vincula una cuenta de Google mediante la autorización oficial de Google.
- Muestra el correo vinculado en la pantalla de copia de seguridad.
- Guarda `TACA_Money_Respaldo.json` en `appDataFolder`, el espacio privado de TACA Money en Google Drive.
- Permite crear/actualizar una copia, restaurarla en otro celular y cambiar la cuenta de Google.
- El respaldo contiene clientes, préstamos, pagos, recibos, finanzas, configuración y fotos de garantías almacenadas dentro de los datos de la app.
- La app no guarda la contraseña de Google.

## Garantías
- Mantiene la constancia final cuando el préstamo queda cancelado y la garantía fue devuelta.
- El recibo puede indicar “PRÉSTAMO CANCELADO · GARANTÍA DEVUELTA” y registrar fecha/hora de devolución.

## Google Cloud configurado para esta versión
- Paquete: `com.remberto.misprestamos`
- Scope: `https://www.googleapis.com/auth/drive.appdata`
- Requiere un cliente OAuth Android asociado a la firma permanente de TACA Money.

## Compilación firmada en GitHub
El workflow compila `assembleRelease` y espera dos GitHub Actions Secrets:
- `TACA_KEYSTORE_BASE64`
- `TACA_KEYSTORE_PASSWORD`

La clave `.jks`, su contraseña y el contenido de esos secretos NUNCA deben subirse como archivos del repositorio público.
