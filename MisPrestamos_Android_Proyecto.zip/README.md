# Mis Préstamos - Android

Micro app Android local para controlar préstamos y abonos.

## Funciones
- Registrar cliente, teléfono, capital, interés y fechas.
- Calcular total a cobrar.
- Registrar abonos y saldo.
- Estados: activo, vencido y pagado.
- Historial de pagos.
- Buscar y filtrar.
- Exportar/importar respaldo JSON.
- Funciona sin internet.
- Datos guardados localmente en el dispositivo.

## Generar APK
El proyecto incluye `.github/workflows/build-apk.yml`.
Al subirlo a GitHub, la acción `Build APK` genera:
`app/build/outputs/apk/debug/app-debug.apk`

También puede abrirse directamente en Android Studio y compilarse con:
`Build > Build APK(s)`.

## Paquete
`com.remberto.misprestamos`

## Nota
Esta versión es para control personal. Para comercializarla o usarla como sistema
financiero para terceros conviene añadir autenticación, cifrado, base de datos,
copias de seguridad y revisión de requisitos legales aplicables.


## Versión 1.1
- Interfaz compacta para Xiaomi 14T Pro.
- Mejor ajuste a pantallas pequeñas.
- Modales desplazables.
- El teclado ya no debe tapar los botones.
- Escalado de texto controlado.


## Versión 1.2
- Respeta barra de estado y navegación en Xiaomi/HyperOS/Android 15.
- Evita que el título y + Nuevo queden debajo de la hora o batería.
- Controles un poco más compactos para mejorar visibilidad.


## Versión 1.3
- Corrige solapamiento con la barra superior de HyperOS/Xiaomi mediante margen nativo.
- Recupera tamaño normal y legible de letras y controles.
- Mantiene la interfaz adaptable sin reducir excesivamente el texto.

## Versión 1.4 - TACA Money
- Marca TACA Money y logo incorporados.
- Icono de la APK estilo moneda.
- Cobros diarios configurables por días de la semana (lunes a sábado).
- Número de cuotas/días y cuota diaria calculada automáticamente.
- Registro de pagos por Efectivo o QR.
- Pago de una o varias cuotas a la vez.
- Numeración de recibos REC-0001, REC-0002, ...
- Recibo visual con logo, monto, método, saldo y próximo cobro.
- Compartir el recibo como imagen mediante WhatsApp u otras apps.


## Versión 1.5
- Dos modalidades: cuota fija en Bs o cobro por porcentaje.
- En modo fijo, el total se calcula como cuota diaria × número de cuotas.
- En modo porcentaje, el porcentaje se aplica una vez al capital y luego se divide entre las cuotas.
- Los recibos muestran la cuota pagada (X de Y) y cuántas cuotas faltan.
- Se mantiene pago por Efectivo/QR y selección de días de cobro.


## Versión 1.6
- El préstamo siempre es dinero en Bs; opcionalmente el cliente puede dejar una garantía/prenda.
- La garantía aparece en el recibo solamente cuando existe.
- Condición de garantía: al vencer el plazo hay 3 días adicionales para cancelar y retirar la prenda; después podrá ejecutarse conforme al acuerdo y la normativa aplicable.
- Frecuencia de cobro seleccionable: diaria o semanal.
- En cobro diario se eligen los días (lunes a sábado); en cobro semanal las cuotas se programan cada 7 días desde el primer cobro.
- Modalidad de monto: cuota fija en Bs o porcentaje.
- Recibos muestran frecuencia, cuota pagada, cuotas pendientes, método, saldo, garantía si corresponde y condiciones informadas.
- Aviso de atraso: más de 2 cuotas vencidas puede generar penalidad equivalente a 1 cuota adicional, salvo justificación aceptada.


## Versión 1.7
- El cobro semanal usa un plazo explícito en semanas: 1, 2, 3, etc.
- En modo porcentaje, el total se calcula una sola vez sobre el capital y se divide entre las semanas acordadas.
- Ejemplo: Bs 300 al 20% por 1 semana = Bs 360 a devolver en 1 pago semanal; por 2 semanas = 2 pagos de Bs 180.
- El primer pago semanal se propone automáticamente a 7 días de la fecha del préstamo y luego cada 7 días.
- El recibo semanal muestra plazo acordado y fecha de vencimiento.
- Se mantienen garantía/prenda, condiciones por atraso, pagos QR/efectivo y recibos compartibles.


## Versión 1.8
- Corrige la modalidad semanal: el cliente elige en cuántas semanas pagará el monto total (1, 2, 3, etc.), no cuotas semanales sucesivas.
- Ejemplo: Bs 300 al 20% y plazo de 1 semana = Bs 360 de pago total al vencimiento; si el plazo es 2 semanas, el total sigue siendo Bs 360 y vence a los 14 días.
- En modalidad semanal, el vencimiento se calcula automáticamente según las semanas acordadas.
- El recibo semanal muestra plazo acordado, monto total a devolver y fecha de vencimiento.
- El recibo en pantalla ahora se muestra en una tarjeta compacta centrada dentro de la app, con desplazamiento interno si el contenido es largo.
