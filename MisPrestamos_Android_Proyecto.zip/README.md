# TACA Money v2.0

Base: v1.9.

Novedades principales:
- Copia de seguridad en Google Drive usando el selector oficial de archivos de Android.
- Después de elegir por primera vez `TACA_Money_Respaldo.json` en Google Drive, la app puede actualizar esa misma copia con un toque.
- Restauración desde Google Drive en otro celular usando la misma cuenta de Google.
- Se conserva también la exportación/importación manual de respaldo.
- La copia incluye préstamos, clientes, pagos, recibos, finanzas, códigos y fotos de garantías almacenadas en la app.
- Cuando un préstamo con garantía queda totalmente pagado, la app pregunta si la garantía fue devuelta y si todo quedó conforme.
- El recibo final puede dejar constancia de préstamo cancelado y garantía devuelta.
- Si el préstamo ya fue pagado pero la garantía aún no se devolvió, aparece un botón para registrar la devolución posteriormente y generar su recibo.

Nota sobre Google Drive: TACA Money no guarda contraseñas ni credenciales de Google. Android/Google Drive administran la cuenta y la ubicación elegida por el usuario.
