# PrestaPro 3.22.47 — versionCode 124

Proyecto Android completo y actualizado desde la versión 3.22.46 (código 123) para instalar sin desinstalar, conservando el `applicationId` y la configuración de firma original.

**Única novedad:** calendario de cuotas/pagos semanales de solo lectura en «Ver detalles y opciones» y calendario original en el recibo real de entrega (vista previa, imagen y PDF). Reconoce las prórrogas autorizadas solo en el detalle, sin modificar fechas originales ni movimientos.

Los préstamos diarios, cotizaciones, pagos mixtos, capital, multas, cierres, licencias y respaldos no cambian.

Documentos: `CAMBIOS_3.22.47.md` y `GUIA_PRUEBAS_3.22.47.md`. Pruebas automáticas: `test_calendario_semanal.js` más las pruebas existentes.

**Pendiente:** compilación y prueba en Android físico. La firma oficial se genera en GitHub Actions con los secretos existentes. Con datos reales, confirmar un respaldo antes de actualizar.
