# PrestaPro v3.11.1 · Bloque 6

Base: v3.10.1 aprobada.

Incluye:
- Ajustes > Mi licencia.
- Código de dispositivo.
- Licencia offline firmada RSA/SHA-256.
- La APK contiene solo la clave pública; la clave privada queda fuera del repositorio.
- Valida firma, dispositivo autorizado y vencimiento.
- Muestra titular, plan, ID, emisión, vencimiento y dispositivos permitidos.
- Admite licencia permanente o temporal.
- La licencia puede estar en el respaldo, pero solo funciona en dispositivos autorizados.
- En esta primera prueba no se bloquean funciones por falta de licencia.
- No modifica préstamos, pagos, respaldos, notificaciones, reglas ni personalización.


## Corrección v3.11.1
- Reactivación de licencias válidas.
- Compatibilidad con licencias del Bloque 6 anterior.
- Pegado robusto: elimina espacios, saltos de línea y caracteres invisibles.
- El código de licencia deja de mostrarse después de activarse.
- El botón para quitar licencia solo aparece cuando existe una licencia instalada.
- Mensajes de licencia dentro de PrestaPro, sin cuadros “file://”.
