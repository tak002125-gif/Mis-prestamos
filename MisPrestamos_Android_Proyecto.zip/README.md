# PrestaPro v3.5.2

Correcciones:
- Compartir cotizaciones/recibos con logo PrestaPro incrustado.
- Recordatorios: vista previa y compartir imagen/WhatsApp.
- Mensaje visible si falla la generación del recordatorio.
- Versión visual y Android sincronizadas en 3.5.2.
- Conserva datos y package existente.
