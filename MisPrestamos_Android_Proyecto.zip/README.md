# PrestaPro v3.22.45 / code 122 — Cálculo automático del pago mixto

Base: PrestaPro 3.22.44. Al registrar o corregir un pago mixto, el importe QR o efectivo que falte se completa automáticamente; ambos campos siguen editables. Los cálculos de capital, Finanzas, Caja diaria, las licencias y los datos guardados permanecen sin cambios.

Ver `CAMBIOS_3.22.45.md` y `GUIA_PRUEBAS_3.22.45.md`.
