# PrestaPro v3.14.1

Bloque comercial Gratis / Anual / Permanente:
- PrestaPro Gratis funciona sin vencimiento con hasta 5 clientes registrados.
- Los clientes ya utilizados conservan su cupo aunque se elimine el préstamo, evitando reutilizar el límite gratuito.
- Restaurar una copia anterior o borrar los datos desde la app no reinicia los cupos gratuitos ya usados.
- Un mismo cliente puede tener nuevos préstamos sin consumir otro cupo cuando coincide por teléfono o identidad registrada.
- Cambiar un préstamo existente a una persona diferente consume un nuevo cupo; si ya se alcanzaron 5, se solicita un plan ilimitado.
- Licencias Anual o Permanente válidas mantienen clientes ilimitados.
- La antigua demostración temporal se conserva en el motor de licencias, pero ya no forma parte del flujo comercial visible normal.
- La pantalla de plan muestra el uso actual del límite Gratis y prepara la presentación de Anual/Permanente para Google Play.

Se conserva lo ya implementado en v3.13.4:
- Finanzas, caja diaria e historial.
- Cierre automático de caja configurable.
- Recordatorios, recibos, garantías, respaldos y Google Drive.
- Compatibilidad con datos y licencias ya existentes al instalar encima de una versión anterior.


PrestaPro v3.14.1
- Pantalla Plan: oculta Gratis y opciones de compra cuando existe licencia Anual/Permanente activa.
- Iconografía SVG coherente en Finanzas, Caja diaria, Ajustes y navegación inferior.
- Sin cambios en datos, préstamos, caja, licencias ni reglas comerciales.
