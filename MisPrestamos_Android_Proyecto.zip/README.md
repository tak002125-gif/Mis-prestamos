# PrestaPro by Taca v3.13.0

Bloque 7A: compatibilidad con licencias emitidas por PrestaPro Admin.

- Conserva compatibilidad con licencias anteriores y la licencia permanente del propietario.
- Añade la clave pública oficial de PrestaPro Admin.
- Las licencias siguen verificándose por firma RSA SHA-256 y código de dispositivo.
- No contiene la clave privada del generador.
