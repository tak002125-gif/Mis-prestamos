# Mis Préstamos - Android

Micro app Android local para controlar préstamos y abonos.

## Funciones
- Registrar cliente, teléfono, capital, interés y fechas.
- Calcular total a cobrar.
- Registrar abonos y saldo.
- Estados: activo, vencido y pagado.
- Historial de pagos.
- Buscar y filtrar.
- Exportar/importar respaldo JSON.
- Funciona sin internet.
- Datos guardados localmente en el dispositivo.

## Generar APK
El proyecto incluye `.github/workflows/build-apk.yml`.
Al subirlo a GitHub, la acción `Build APK` genera:
`app/build/outputs/apk/debug/app-debug.apk`

También puede abrirse directamente en Android Studio y compilarse con:
`Build > Build APK(s)`.

## Paquete
`com.remberto.misprestamos`

## Nota
Esta versión es para control personal. Para comercializarla o usarla como sistema
financiero para terceros conviene añadir autenticación, cifrado, base de datos,
copias de seguridad y revisión de requisitos legales aplicables.


## Versión 1.1
- Interfaz compacta para Xiaomi 14T Pro.
- Mejor ajuste a pantallas pequeñas.
- Modales desplazables.
- El teclado ya no debe tapar los botones.
- Escalado de texto controlado.
