# PrestaPro v3.7.1

Corrección puntual sobre v3.7.0.

Incluye:
- Nuevo botón: Restaurar diseño original de PrestaPro.
- Confirmación antes de borrar la personalización.
- Restaura nombre, WhatsApp, dirección, pie de documentos, logo y colores originales.
- No modifica préstamos, pagos, clientes, moneda, idioma ni respaldos.
