# PrestaPro v3.10.1

Corrección puntual sobre v3.10.0 aprobada.

- Al tocar la notificación normal abre Recordatorios/Préstamos pendientes.
- Al tocar la notificación de prueba también abre Recordatorios/Préstamos pendientes.
- Si existe un recordatorio pendiente, abre su vista para poder revisarlo/enviarlo.
- Si no existe uno pendiente, permanece en Préstamos y muestra el aviso correspondiente.
- No modifica préstamos, pagos, respaldos, reglas, personalización ni permisos.
