TACA Money v2.5

Nueva modalidad de cobro semanal flexible:
- **Cuotas semanales:** el total a devolver se divide entre el número de semanas. Ejemplo: Bs 1.000 al 20% por 3 semanas = Bs 1.200, dividido en 3 cuotas semanales de Bs 400.
- **Pago total al finalizar:** se conserva la modalidad anterior para poder cobrar todo al vencimiento.
- La elección también aparece en **Cotización**, recibos, vista previa, tarjeta del préstamo y comprobantes compartidos.
- Los préstamos semanales creados en versiones anteriores se conservan como pago único para no cambiar acuerdos ya registrados.
- La cotización continúa sin mostrar la ganancia al cliente.

Base visual y funcional: v2.4.

TACA Money v2.4

Rediseño de la pantalla principal para acercarla a la interfaz profesional aprobada: encabezado compacto con logo original, cuatro tarjetas financieras, buscador y filtros por modalidad, tarjetas de préstamo compactas, navegación de cuatro secciones y cotización sin mostrar la ganancia al cliente.

# TACA Money v2.3

## Corrección v2.3
- Se ocultó la ganancia estimada del recibo de cotización y de la imagen compartida.
- El cálculo interno de ganancia y el módulo Finanzas no fueron modificados.

Base estable: v2.1.

## Cambios de v2.3
- Muestra la versión de la app en la pantalla principal y en Datos y seguridad.
- Nueva función **Cotizar**: permite preparar una propuesta sin crear un préstamo ni modificar Finanzas.
- La cotización admite: Diario, Semanal (pago total en N semanas) y Con garantía.
- En cotización con garantía se puede elegir cobro diario o pago total por semanas.
- La cotización calcula monto solicitado, total a devolver, ganancia estimada, cuotas/plazo y fechas; se puede compartir como imagen.
- La condición por atraso de más de 2 cuotas se muestra solamente en préstamos/cotizaciones de cobro diario.
- En préstamos semanales ya no se solicita ni se muestra esa condición por atraso de cuotas.

## Respaldo con cuenta de Google
- Vincula una cuenta de Google mediante autorización oficial.
- Muestra el correo vinculado.
- Guarda `TACA_Money_Respaldo.json` en `appDataFolder`, el espacio privado de TACA Money en Google Drive.
- Permite crear/actualizar una copia, restaurarla en otro celular y cambiar la cuenta.
- La app no guarda la contraseña de Google.

## Garantías
- Mantiene la constancia final cuando el préstamo queda cancelado y la garantía fue devuelta.
- El recibo puede indicar `PRÉSTAMO CANCELADO · GARANTÍA DEVUELTA` y registrar fecha/hora de devolución.

## Compilación firmada en GitHub
El workflow compila `assembleRelease` y espera dos GitHub Actions Secrets:
- `TACA_KEYSTORE_BASE64`
- `TACA_KEYSTORE_PASSWORD`

La clave `.jks`, su contraseña y esos secretos nunca deben subirse como archivos del repositorio público.


## v2.3
- Rediseño profesional completo de interfaz.
- Logo original TACA conservado en cabecera y recibos.
- Navegación inferior rápida.
- Tarjetas de préstamos, finanzas, alertas, formularios y respaldo renovadas.
- Cotización para cliente sin mostrar ganancia estimada.
