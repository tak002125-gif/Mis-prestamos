# PrestaPro v3.12.0

Bloque 6 comercial.

- Licenciamiento comercial activo.
- Sin licencia válida: modo restringido, sin borrar datos.
- Se mantiene consulta de préstamos, finanzas, ajustes y creación/exportación de copias de seguridad.
- Se bloquean nuevos préstamos, cotizaciones, cobros, edición/eliminación, correcciones/anulaciones de pagos, recordatorios operativos, cierres/devoluciones de garantía, cierre de caja, restauración e importación destructiva.
- Licencias activas mantienen acceso completo.
- Licencias vencidas, inválidas o de otro dispositivo muestran el estado y mantienen los datos intactos.
- Tu licencia permanente v3.11.1 sigue siendo compatible.

versionCode: 46
versionName: 3.12.0
