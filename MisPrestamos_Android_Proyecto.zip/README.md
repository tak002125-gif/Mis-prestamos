# PrestaPro v3.8.0 · Bloque 3

Base: v3.7.1 aprobada.

Incluye:
- Ajustes > Cláusulas y reglas.
- Textos editables para atraso diario, semanal, garantía, garantía semanal, cotización y recibos.
- Activar/desactivar cada cláusula.
- Vista previa y restauración de valores originales.
- Reglas configurables: cuotas sin penalización, incumplimiento semanal con garantía, días de gracia y penalización activa/desactivada.
- Las reglas se guardan como snapshot dentro de cada préstamo nuevo para no alterar préstamos anteriores.
- Las cláusulas también se congelan al crear cada préstamo para conservar lo acordado con el cliente.
- Cotizaciones usan la configuración actual.
- No toca copias automáticas, licencias ni White Label.
