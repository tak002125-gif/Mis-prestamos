# PrestaPro 3.22.51 — versionCode 128

Proyecto Android de PrestaPro para GitHub Actions (edición comercial externa).

**Nueva mejora:** detección voluntaria de actualizaciones al abrir la app y opción de comprobación manual en **Ajustes > Buscar actualizaciones**. Cuando la página oficial publique una versión mayor, la app mostrará un aviso con «Más tarde» y «Actualizar ahora». Ver `CAMBIOS_3.22.51.md` y `GUIA_PRUEBAS_3.22.51.md`.

Se mantienen intactos los clientes, préstamos, pagos, licencias, calendarios, Finanzas, recordatorios y la mejora de búsqueda de 3.22.50. Se conserva `com.remberto.misprestamos`, alias de firma `taca_money` y almacenamiento local.

**No hay descargas ocultas ni auto-instalación:** la app solamente abre la web oficial en el navegador. Requiere internet únicamente para consultar si hay actualización.

**Despliegue por etapas:** primero compilar esta versión firmada desde GitHub; después publicar esa APK en Cloudflare junto con el archivo `version.json` del mismo código. Los usuarios de la 3.22.50 harán esta actualización manual una vez; luego recibirán avisos de versiones posteriores.

Para GitHub, subir únicamente el ZIP `MisPrestamos_Android_Proyecto.zip` con este proyecto en su raíz, reemplazando el archivo anterior del mismo nombre.
