# PrestaPro by Taca v3.13.2

Mejora de interfaz: Cláusulas y reglas por pestañas.

- Nueva organización en 4 pestañas: Reglas, Cláusulas, Textos extra y Vista previa.
- Reglas reales de cobro más compactas y explicadas.
- Cláusulas principales editables mediante tarjetas desplegables.
- Textos de cotización y recibos separados para evitar una pantalla excesivamente larga.
- Vista previa integrada con sustitución automática de variables.
- Botones inferiores de Guardar, Vista previa y Restaurar valores originales.
- Conserva las mismas reglas, cláusulas y datos existentes; el cambio es principalmente de organización y presentación.
- Mantiene compatibilidad con licencias Prueba 7 días, Anual y Permanente de PrestaPro Admin.

VersionCode: 50
VersionName: 3.13.2

- Inicio más limpio: se eliminaron los accesos duplicados inferiores “Nuevo préstamo” y “Cotizar”; se conservan arriba y abajo quedan solo “Cobrar hoy” y “Recordatorios” en dos columnas amplias.
