# PrestaPro v3.10.0 · Bloque 5 (base de notificaciones)

Base: v3.9.0 aprobada.

Incluye:
- Nueva pantalla Ajustes > Alertas y recordatorios.
- Estado real del permiso de notificaciones.
- Estado del permiso de alarmas exactas.
- Botones para revisar ambos permisos cuando sea necesario.
- Próximo aviso diario y última programación visibles.
- Prueba de alarma en aproximadamente 1 minuto para probar con la app cerrada.
- Reprogramación después de reinicio, cambio de hora/zona y actualización de APK.
- El receptor nativo recalcula vencimientos y etapas usando calendario, pagos y reglas guardadas, sin depender de haber abierto la app ese mismo día.
- Los días de gracia y reglas semanales configurables se sincronizan con Android.
- No modifica préstamos, pagos, copias de seguridad ni licencias.
