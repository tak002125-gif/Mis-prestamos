# PrestaPro 3.22.48 — versionCode 125

Proyecto Android completo a partir de PrestaPro 3.22.47 (código 124), manteniendo `applicationId`, firma de GitHub y almacenamiento local.

**Única mejora:** reorganización visual de Finanzas para distinguir capital propio, saldo pendiente, ganancia cobrada estimada, ganancia total prevista y la proyección de capital + ganancia. Las estadísticas acumuladas pasan a un bloque inferior con explicación de capital reutilizado. Las fórmulas de préstamo y los datos guardados no se modifican.

Consulta `CAMBIOS_3.22.48.md` y `GUIA_PRUEBAS_3.22.48.md`.

Pruebas JavaScript y de interfaz con datos ficticios realizadas; pendiente compilación y validación Android antes de usarlo con operaciones reales.
