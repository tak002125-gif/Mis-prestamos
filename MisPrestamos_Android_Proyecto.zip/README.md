# PrestaPro v3.6.0 · Bloque 1

Base: v3.5.2 estable.

Incluye:
- Asistente inicial solo para instalaciones nuevas.
- Idioma base: Español / English.
- País / región configurable.
- Moneda configurable: BOB, USD, MXN, PEN, ARS, CLP, COP, EUR.
- Formato monetario regional mediante Intl.NumberFormat.
- Datos básicos del negocio durante el primer inicio (opcionales).
- Nueva opción Ajustes > Idioma, país y moneda.
- Usuarios que actualizan desde versiones anteriores NO reciben el onboarding automáticamente.
- Cambiar moneda no convierte importes históricos: solo cambia su formato/identidad monetaria.
