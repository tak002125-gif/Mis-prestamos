TACA Money v3.2

Corrección de navegación: las tarjetas de resumen financiero general se muestran únicamente en la pestaña Finanzas. Préstamos y Ajustes muestran solo su contenido propio.
