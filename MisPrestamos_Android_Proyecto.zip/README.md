# Mis Préstamos - Android

Micro app Android local para controlar préstamos y abonos.

## Funciones
- Registrar cliente, teléfono, capital, interés y fechas.
- Calcular total a cobrar.
- Registrar abonos y saldo.
- Estados: activo, vencido y pagado.
- Historial de pagos.
- Buscar y filtrar.
- Exportar/importar respaldo JSON.
- Funciona sin internet.
- Datos guardados localmente en el dispositivo.

## Generar APK
El proyecto incluye `.github/workflows/build-apk.yml`.
Al subirlo a GitHub, la acción `Build APK` genera:
`app/build/outputs/apk/debug/app-debug.apk`

También puede abrirse directamente en Android Studio y compilarse con:
`Build > Build APK(s)`.

## Paquete
`com.remberto.misprestamos`

## Nota
Esta versión es para control personal. Para comercializarla o usarla como sistema
financiero para terceros conviene añadir autenticación, cifrado, base de datos,
copias de seguridad y revisión de requisitos legales aplicables.


## Versión 1.1
- Interfaz compacta para Xiaomi 14T Pro.
- Mejor ajuste a pantallas pequeñas.
- Modales desplazables.
- El teclado ya no debe tapar los botones.
- Escalado de texto controlado.


## Versión 1.2
- Respeta barra de estado y navegación en Xiaomi/HyperOS/Android 15.
- Evita que el título y + Nuevo queden debajo de la hora o batería.
- Controles un poco más compactos para mejorar visibilidad.


## Versión 1.3
- Corrige solapamiento con la barra superior de HyperOS/Xiaomi mediante margen nativo.
- Recupera tamaño normal y legible de letras y controles.
- Mantiene la interfaz adaptable sin reducir excesivamente el texto.

## Versión 1.4 - TACA Money
- Marca TACA Money y logo incorporados.
- Icono de la APK estilo moneda.
- Cobros diarios configurables por días de la semana (lunes a sábado).
- Número de cuotas/días y cuota diaria calculada automáticamente.
- Registro de pagos por Efectivo o QR.
- Pago de una o varias cuotas a la vez.
- Numeración de recibos REC-0001, REC-0002, ...
- Recibo visual con logo, monto, método, saldo y próximo cobro.
- Compartir el recibo como imagen mediante WhatsApp u otras apps.
