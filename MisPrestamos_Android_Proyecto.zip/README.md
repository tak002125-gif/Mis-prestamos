# TACA Money v1.9

Aplicación Android local/offline para control de préstamos personales.

## Novedades v1.9

- Recibo automático de **entrega del préstamo** al registrar un nuevo préstamo.
  - Nombre del cliente.
  - Código único del préstamo (`PRE-AAAA-0001`).
  - Número del recibo de entrega (`ENT-0001`).
  - Fecha y hora de entrega.
  - Monto entregado.
  - Forma de entrega: **Efectivo o QR**.
  - Modalidad, total a devolver, plazo y vencimiento.
  - Garantía/prenda cuando corresponda.
- Panel **Finanzas y ganancias** con capital prestado, total a recuperar, ganancia esperada, ganancia cobrada estimada, cobrado y saldo pendiente.
- Historial financiero de los últimos 6 meses.
- **Alertas y vencimientos** dentro de la app.
- Recordatorio diario configurable mediante notificación Android.
- Avisos de cobros de hoy, mañana, atrasados y del plazo adicional de 3 días de las garantías.
- Foto de la garantía desde cámara o galería, con descripción de su estado.
- Todos los recibos de pago muestran también el código del préstamo.
- Conserva la lógica v1.8 de cobros diarios o pago total acordado en semanas.

## Privacidad

Los datos permanecen en el dispositivo. Las fotos de garantías se guardan dentro de los datos locales de la app y se incluyen en los respaldos JSON. Conviene exportar respaldos periódicamente.

## Compilación

El proyecto se compila con Android SDK 35, Java 17 y Gradle 8.7 usando el workflow de GitHub Actions incluido en el repositorio.
