# PrestaPro 3.22.50 — versionCode 127

Proyecto Android completo para subir a GitHub en la raíz del repositorio, con **un único archivo llamado exactamente** `MisPrestamos_Android_Proyecto.zip`.

**Mejora única:** corrección del buscador «Cliente existente» en el formulario «Nuevo préstamo»: busca inmediatamente por nombre, CI/DNI o teléfono; Enter selecciona la ficha si hay una sola coincidencia y no activa la validación del formulario. Ver `CAMBIOS_3.22.50.md` y `GUIA_PRUEBAS_3.22.50.md`.

Basado en PrestaPro 3.22.49, con el mismo `applicationId`, configuración de firma y almacenamiento de préstamos, pagos, licencia y datos del negocio. No hay migraciones de datos ni cambios de negocio.

Las pruebas automatizadas se ejecutaron con datos ficticios y sin datos reales. La compilación Android firmada y la prueba final en un dispositivo deben efectuarse tras subir este ZIP a GitHub.
