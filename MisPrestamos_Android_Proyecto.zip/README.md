# PrestaPro 3.22.46 — versionCode 123

Proyecto Android completo para actualización conservando el `applicationId` y la clave de firma original.

**Novedad exclusiva para semanal:** prórroga por cuota individual con fecha y motivo, fechas de las demás cuotas intactas, protección de penalizaciones y recordatorios, registro de historial. **Los préstamos diarios no reciben prórroga.**

Conserva los cambios anteriores de 3.22.45: pagos mixtos con QR + efectivo y autocompletado editable.

Documentación: `CAMBIOS_3.22.46.md` y `GUIA_PRUEBAS_3.22.46.md`.

Procedimiento: subir este ZIP a `tak002125-gif/Mis-prestamos` para compilar mediante GitHub Actions, probar la APK primero en Samsung, respaldar el Xiaomi y confirmar todos los datos antes de instalar allí. Esta fuente aún no es una APK compilada.
