# TACA Money v2.8

Proyecto Android nativo para compilar TACA Money.

## Cambios principales de v2.8

- Corrección de avisos diarios: nuevo canal de notificación con importancia alta, sonido del sistema y vibración.
- El canal cambia de identificador para que Android/HyperOS aplique el sonido aunque el canal anterior haya quedado silencioso.
- La alarma diaria deja de usar repetición inexacta y se reprograma como aviso de una sola vez para el día siguiente, reduciendo retrasos sin requerir permisos especiales de alarma exacta.
- Al tocar la notificación, la app intenta abrir directamente la vista previa del primer recordatorio pendiente.
- Botón verde de **Enviar recordatorio** visible directamente en la tarjeta del préstamo cuando corresponde, sin tener que entrar en “Ver detalles y opciones”.
- Se mantienen los recordatorios diarios/semanales, vista previa, WhatsApp, garantías, penalidades y reglas de v2.7.

## Compilación

La configuración mantiene Android SDK 35, Java 17, Gradle 8.7 y el sistema de firma permanente mediante variables/secretos del workflow.

No incluir archivos de clave privada dentro del repositorio público.
