# PrestaPro v3.22.26 / code 103

## Idiomas — Bloque 5 seguro

- Traducción controlada de Finanzas/Caja y pantallas internas de Ajustes: negocio, alertas, seguridad, copias de seguridad y licencia.
- Estados y mensajes cortos dinámicos principales disponibles en Español, English y Português (Brasil).
- Fechas visibles ahora siguen el idioma de la aplicación sin alterar moneda ni formato numérico regional.
- No se modificaron recibos/PDF, cláusulas largas, textos legales ni mensajes largos generados para clientes.
- No se cambió la lógica de préstamos, cobros, penalizaciones, garantías, recordatorios, caja, respaldo ni licencias.

# PrestaPro v3.22.22 / code 99

## Préstamos finalizados + recordatorios reforzados
- En **Todos**, los préstamos vencidos y activos quedan primero; los **Finalizados** bajan automáticamente al final para no estorbar la cobranza diaria.
- Se agrega el filtro **Finalizados** con contador. El cliente no se archiva ni se elimina: su ficha e historial siguen disponibles para nuevos préstamos.
- Al tocar una notificación de cobro, PrestaPro abre **Préstamos** directamente en **Pendientes hoy** (o Vencidos si corresponde), en lugar de quedarse en Inicio.
- Antes de reprogramar alarmas al abrir la app, PrestaPro detecta si Android omitió un aviso programado del mismo día y lo recupera.
- Se registran las ejecuciones reales de los avisos normal y por atraso para evitar duplicados en la recuperación.
- En Android 12 o superior, si falta el permiso especial de **Alarmas y recordatorios**, PrestaPro lo solicita una vez para poder respetar la hora elegida.
- Al conceder el permiso de alarmas exactas, el receptor de recordatorios vuelve a programar automáticamente las alarmas.
- Conserva intactos préstamos existentes, clientes, pagos, penalizaciones, garantías, caja, respaldos e historial.

# PrestaPro v3.22.21 / code 98

## Navegación Android — botón Atrás en ventanas
- El botón Atrás del teléfono ahora cierra primero la ventana/modal abierta dentro de PrestaPro.
- Funciona para Nuevo préstamo, Cotizar y las demás ventanas modales de la interfaz WebView.
- Si no hay ninguna ventana abierta, Atrás conserva el comportamiento normal de Android.
- No modifica almacenamiento, clientes, préstamos, cobros, caja, idiomas ni lógica financiera.
- Conserva Bloque 1 y Bloque 2 de idiomas aprobados y la corrección de fecha/hora de Actividad reciente.

# PrestaPro v3.22.17 / code 94

## Idiomas — Bloque 2 seguro
- Traducción de textos dinámicos visibles en las tarjetas de Préstamos para Español, English y Português (Brasil).
- Incluye estados, indicador de cumplimiento, monto prestado, frecuencia, próximo pago/estado final, progreso de cuotas, botón Cobrar, recordatorios rápidos y “Ver detalles y opciones”.
- Conserva la corrección de fecha/hora de Actividad reciente de v3.22.16.
- No modifica almacenamiento, clientes, préstamos, cobros, caja, formularios, recibos/PDF, cláusulas ni lógica financiera.

# PrestaPro v3.22.16 — corrección aislada de fecha/hora en Actividad reciente

- Base: v3.22.15 / code 92, con Bloque 1 de idiomas aprobado.
- Actividad reciente ahora usa primero la fecha/hora real del desembolso (`disbursement.dateTime`) para los préstamos nuevos.
- Corrige el caso donde una fecha `YYYY-MM-DD` era interpretada como UTC y podía mostrarse como el día anterior a las 20:00 en Bolivia.
- Los eventos recientes se ordenan por marca de tiempo real, para respetar correctamente el orden entre préstamos y cobros del mismo día.
- Para préstamos antiguos sin hora de desembolso, la fecha simple se interpreta como medianoche local para evitar retroceder al día anterior.
- No modifica almacenamiento, datos existentes, lógica de préstamos, cobros, caja, recibos, garantías, recordatorios ni idiomas.
- versionCode 93 / versionName 3.22.16.

# PrestaPro v3.22.15 — Idiomas Bloque 1 seguro

- Base: v3.22.14 estable.
- Desactiva el traductor global automático del DOM para evitar cambios amplios.
- Traducción explícita ES / EN / PT-BR únicamente para navegación, Inicio, títulos y botones principales.
- No modifica almacenamiento, préstamos, cobros, caja, penalizaciones, garantías, cláusulas ni recibos.
- versionCode 92 / versionName 3.22.15.

# PrestaPro v3.22.14 — cierre de caja congelado y respaldo nativo

- Una caja cerrada queda congelada: pagos posteriores ya no modifican sus totales.
- Si entra un pago después del cierre, Finanzas lo identifica como “Movimiento posterior al cierre”.
- Esos movimientos pueden cerrarse aparte sin alterar el cierre original.
- Si Android entrega tarde el cierre automático, el corte contable conserva la hora programada.
- Se añadió un segundo disparo nativo de respaldo para el cierre automático.
- Al registrar, corregir o anular un pago se actualiza inmediatamente el resumen nativo de caja.
- Se migran de forma segura cierres anteriores que fueron reconciliados con movimientos posteriores.
- No se modificaron préstamos, recordatorios de cobro, cláusulas, idiomas ni almacenamiento de préstamos.

# PrestaPro v3.22.13 — condiciones configurables y garantía

Base: v3.22.12 estable y probada con uso real.

Cambios de esta versión:
- Interés por porcentaje inicia en 0% en nuevas cotizaciones y nuevos préstamos.
- Penalización semanal inicia en 0% / Sin penalización; 5%, 10%, 15%, 20% y personalizado siguen disponibles.
- Los préstamos existentes conservan sus porcentajes y condiciones históricas.
- En nuevas operaciones con garantía se puede acordar 0, 1, 2, 3 o una cantidad personalizada de días adicionales para regularizar después del vencimiento.
- La condición de garantía aclara vencimiento, custodia, plazo adicional acordado, procedimiento posterior y que no existe transferencia automática de propiedad.
- La nueva condición queda reflejada en cotizaciones y comprobantes de entrega.
- No se modificó el sistema de idiomas, almacenamiento, cobros, recordatorios ni cierre automático de caja.

Versión: 3.22.13 / versionCode 90.

---

# PrestaPro v3.22.7 — corrección aislada de cierre automático

Base: v3.22.3 estable recuperada.

Cambios de esta versión:
- No se modificó almacenamiento de préstamos, recuperación de datos ni sistema de idiomas.
- El cierre automático y su aviso previo siguen usando AlarmManager nativo.
- La app ahora fuerza una revisión del permiso especial de **Alarmas y recordatorios** cuando el cierre automático está activo y Android no permite alarmas exactas.
- Al conceder ese permiso, PrestaPro reprograma automáticamente el cierre y el aviso con `setExactAndAllowWhileIdle`.
- Se añadió escucha del cambio de permiso de alarmas exactas para reprogramar sin depender de reiniciar el teléfono.
- Si el permiso exacto no está concedido, se conserva una alarma compatible como respaldo, pero Android puede retrasarla.
- `last_schedule_exact` solo queda en verdadero cuando tanto el cierre como el aviso fueron registrados de forma exacta.

Versión: 3.22.7 / versionCode 84.

---

# PrestaPro v3.22.3 — rollback estable

- Base restaurada exactamente a la lógica de v3.22.3.
- versionCode elevado a 83 únicamente para permitir instalarla encima de v3.22.6 sin desinstalar ni borrar datos.
- No incorpora los cambios experimentales de v3.22.4, v3.22.5 ni v3.22.6.

# PrestaPro v3.22.3 — traducción global ES / EN / Português (Brasil)

- Cambio de idioma aplicado a toda la interfaz WebView, incluidas pantallas dinámicas, modales, formularios y estados.
- Recibos, cotizaciones y recordatorios gráficos se generan en el idioma seleccionado.
- Mensajes de recordatorio al cliente se generan en español, inglés o portugués brasileño.
- Notificaciones nativas de cobros, atrasos y cierre automático reciben el idioma seleccionado.
- Brasil usa locale `pt-BR` y moneda sugerida `BRL` (R$).
- Se mantiene intacta la corrección de cierre automático incorporada en v3.22.1.
- versionCode 79 / versionName 3.22.3.

# PrestaPro v3.22.2 — Português (Brasil), Brasil y Real brasileño

- Agrega Português (Brasil) como tercer idioma regional disponible.
- Agrega Brasil en País / región.
- Agrega BRL · Real brasileiro (R$) y formato brasileño R$ 1.250,50.
- País, moneda e idioma siguen siendo independientes; elegir Brasil sugiere BRL sin bloquear otras monedas.
- Traduce la pantalla regional, navegación principal y configuración inicial al portugués brasileño.
- Mantiene intacta la corrección v3.22.1 del cierre automático y sus alarmas.
- versionCode 78 / versionName 3.22.2.

# PrestaPro v3.22.1 — Corrección de horarios del cierre automático

- Corrige avisos de cierre que Android podía entregar tarde y junto con el cierre.
- Ignora alarmas antiguas después de cambiar/reprogramar la hora.
- El aviso muestra los minutos realmente restantes si Android lo retrasa.
- Evita el aviso previo si la caja del día ya fue cerrada manualmente.
- Al activar el cierre automático, solicita revisar el permiso de alarmas exactas cuando hace falta.
- versionCode 77 / versionName 3.22.1.

# PrestaPro v3.22.0 — Bienvenida, seguridad y exportación

- Nueva experiencia de primer inicio con dos pantallas: respaldo con cuenta de Google y seguridad con PIN/huella.
- La cuenta de Google es recomendada pero no obligatoria; si se omite, PrestaPro vuelve a recordarlo después de 7 días, no diariamente.
- Permite elegir frecuencia de respaldo: diario, semanal, mensual o manual.
- La seguridad local sigue siendo opcional y se puede configurar después desde Ajustes.
- Exportar Finanzas ya no obliga a guardar inmediatamente: al preparar Excel o CSV aparece una ventana con Abrir archivo, Compartir y Guardar en el teléfono.
- Compartir usa el menú nativo de Android para WhatsApp, correo, Drive u otras apps compatibles.
- Se mantiene intacta la lógica de préstamos, cobros, atrasos, caja, licencias y recibos.
- versionCode 76 / versionName 3.22.0.

# PrestaPro v3.21.0 — Identificación y vista previa de mensajes

- La cotización continúa siendo rápida: solo solicita el nombre del cliente.
- Al formalizar un préstamo se solicita tipo y número de documento de identidad.
- Tipos disponibles: C.I., DNI, Cédula, Pasaporte, Documento nacional / ID y Otro.
- El tipo sugerido se adapta al país configurado en PrestaPro.
- El documento queda guardado en el préstamo y aparece en el comprobante de entrega, detalle del préstamo, impresión térmica y exportación de préstamos.
- En Alertas y recordatorios se agrega “Ver mensaje al cliente” tanto para el recordatorio normal como para el recordatorio por atraso.
- La vista previa muestra el texto que recibirá el cliente sin enviar nada.
- Se mantiene intacta la lógica de las 09:00, domingo sin avisos automáticos, cierre dominical inteligente e historial de atrasos.
- versionCode 75 / versionName 3.21.0.

# PrestaPro v3.20.4 — Corrección de fechas y cumplimiento

- Historial automático por cliente: cuotas puntuales, atrasadas, vencidas, días de atraso y resumen de cumplimiento.
- Semáforo visual: verde al día, amarillo vence hoy, rojo vencido, morado incobrable, gris finalizado.
- Iconografía premium contextual en formularios y filtros, con QR, efectivo/pago, fechas, cliente, garantía, cuotas y más.
- versionCode 69 / versionName 3.20.4.

# PrestaPro v3.20.2 — Penalización semanal configurable

- Para préstamos **semanales por cuotas y sin garantía**, agrega penalización por cuota vencida.
- Opciones rápidas: 0%, 5%, 10%, 15%, 20% o porcentaje personalizado.
- La regla se acepta expresamente al crear o editar el préstamo y queda visible como cláusula en el comprobante.
- La penalización se aplica **una sola vez por cada cuota semanal vencida** sobre el saldo que quedó pendiente de esa cuota al vencimiento.
- Ejemplo: cuota de Bs 400 vencida sin pago, con 20% = Bs 80 de penalización; total de esa obligación: Bs 480.
- Si hubo un pago parcial antes o en la fecha de vencimiento, el porcentaje se calcula solo sobre el saldo pendiente de esa cuota.
- No aplica retroactivamente a préstamos semanales existentes salvo que el usuario edite el préstamo y active la regla; en ese caso rige para vencimientos futuros.
- Los préstamos semanales con garantía conservan su lógica actual de incumplimiento grave/garantía, sin mezclar esta penalización.
- La cláusula aparece también en cotizaciones, recibos, imagen/PDF e impresión térmica cuando corresponde.
- versionCode 67 / versionName 3.20.2.

# PrestaPro v3.19.1 — Incobrable / Irrecuperable

- Permite marcar un préstamo con saldo como “Incobrable” sin borrar la deuda, pagos, garantía ni historial.
- Solicita un motivo y permite añadir una nota administrativa.
- Agrega filtro visible “Incobrables” con contador.
- Un préstamo incobrable deja de aparecer en Pendientes hoy, Vencidos, recordatorios y alertas de cobranza.
- Mientras está incobrable no acumula nuevas penalidades por atraso.
- Finanzas conserva el capital y cobros históricos, pero excluye los incobrables de Total a recuperar, Saldo pendiente y Ganancia esperada.
- La tarjeta mantiene visible el saldo incobrable, fecha, motivo y garantía asociada.
- Incluye “Reactivar cobranza”; al reactivarlo no se aplican penalidades retroactivas por el período pausado.
- Todas las acciones quedan registradas en Historial de cambios.
- Mantiene intactos PIN/huella, caja automática, garantía, licencias, recibos, PDF e impresión térmica.

# PrestaPro v3.17.1 — Pendientes de hoy y vencidos

- Agrega filtros rápidos visibles en Préstamos: “Pendientes hoy” y “Vencidos”.
- Cada filtro muestra un contador actualizado automáticamente.
- “Pendientes hoy” reúne cuotas que corresponden hoy, cuotas anteriores todavía no regularizadas y penalidades pendientes a la fecha.
- “Vencidos” muestra únicamente préstamos realmente atrasados y con saldo pendiente.
- Dentro de “Pendientes hoy”, los préstamos vencidos se muestran primero para priorizar el cobro.
- El acceso “Cobrar hoy” del Inicio abre directamente la lista filtrada de pendientes del día.
- “Ver todos” en Vencimientos de hoy también abre el filtro de pendientes del día.
- Mantiene intactos seguridad PIN/biometría, caja automática, garantías, licencias, recibos, PDF e impresión térmica.

# PrestaPro v3.17.0 — Seguridad y acceso

- Agrega protección local mediante PIN de 4 a 6 dígitos.
- Al detectar que el dispositivo aún no tiene PIN de PrestaPro, muestra una recomendación de seguridad con “Configurar seguridad” o “Más tarde”; si se pospone, vuelve a recordarlo después de 7 días.
- El PIN se almacena derivado con PBKDF2 y sal; no se guarda en texto visible.
- Agrega desbloqueo opcional mediante huella/biometría registrada en Android.
- Agrega bloqueo automático configurable: inmediato, 1, 5, 15 o 30 minutos.
- Agrega botón “Bloquear ahora” para comprobar la protección sin cerrar la aplicación.
- La pantalla de bloqueo nativa oculta el contenido de PrestaPro hasta validar PIN o biometría.
- La configuración está en Ajustes > Seguridad y acceso.
- Permite cambiar el PIN o desactivar el bloqueo desde una sesión ya desbloqueada.
- No modifica préstamos, garantías, caja, licencias, recibos, PDF, impresión térmica ni respaldos.

# PrestaPro v3.16.1 — Interfaz compacta de comprobantes

- Mantiene los cuatro accesos principales en una cuadrícula compacta: Compartir imagen, Guardar PDF, Compartir PDF e Imprimir.
- PDF e impresión pasa a una tarjeta desplegable que resume el papel seleccionado sin ocupar espacio cuando está cerrada.
- Impresora térmica Bluetooth pasa a una tarjeta desplegable que resume ancho y estado/impresora seleccionada.
- La configuración térmica completa solo se muestra al expandirla: impresora emparejada, 58/80 mm, actualizar, ajustes Bluetooth e imprimir térmica.
- Ambas tarjetas se abren solo cuando el usuario necesita configurarlas, reduciendo el desplazamiento vertical.
- Se agregan iconos SVG coherentes con el resto de PrestaPro.
- No cambia la lógica de PDF, impresión normal, ESC/POS, caja, licencias ni datos del usuario.

# PrestaPro v3.16.0 — Impresión térmica Bluetooth

- Agrega impresión directa ESC/POS por Bluetooth para impresoras térmicas emparejadas.
- Permite elegir tickets de 58 mm o 80 mm.
- Lista únicamente dispositivos Bluetooth ya emparejados; no realiza escaneo de ubicación.
- Solicita el permiso Bluetooth solo al usar el módulo térmico.
- Permite abrir Ajustes Bluetooth desde PrestaPro para emparejar una impresora.
- Guarda la impresora y el ancho seleccionados para próximos tickets.
- Ticket compacto con negocio, recibo/préstamo, cliente, monto, saldo, fechas y estado.
- Intenta imprimir el logo mediante raster ESC/POS; si el modelo no lo admite, continúa con el texto.
- Mantiene intactos PDF Carta/A4/Automático e impresión normal de Android.

# PrestaPro v3.15.2

Comprobantes y PDF — ajuste final de formato:
- El generador real de recibos/cotizaciones usa ahora altura dinámica y recorte al final del contenido.
- Comprobantes compartidos como imagen más anchos y con márgenes laterales reducidos para verse mejor en teléfono/WhatsApp.
- Pie de comprobante más compacto.
- Selector de papel guardado: Carta (predeterminado), A4 o Automático.
- PDF Carta: 8,5 × 11 pulgadas. PDF A4: 210 × 297 mm.
- En Automático, Android elige el papel al imprimir; los PDF guardados/compartidos usan Carta como base.
- Guardar PDF, Compartir PDF e Imprimir respetan la selección de papel.
- Se mantiene pendiente para un bloque posterior la impresión térmica Bluetooth 58/80 mm.

# PrestaPro v3.15.1

Bloque visual de comprobantes compactos:
- Los recibos, cotizaciones y comprobantes compartidos como imagen ahora usan altura dinámica.
- Se elimina el gran espacio en blanco al final del comprobante en WhatsApp.
- Se reducen espacios verticales y se compactan bloques informativos sin perder datos importantes.
- Se mantiene la información clave: cliente, fecha, cuotas, método, monto, saldo y próximo cobro.
- Las cláusulas por atraso y garantía siguen apareciendo, pero en tarjetas más compactas.
- El diseño toma como referencia el estilo compacto de los recordatorios.

# PrestaPro v3.15.0

Bloque comercial Gratis / Anual / Permanente:
- PrestaPro Gratis funciona sin vencimiento con hasta 5 clientes registrados.
- Los clientes ya utilizados conservan su cupo aunque se elimine el préstamo, evitando reutilizar el límite gratuito.
- Restaurar una copia anterior o borrar los datos desde la app no reinicia los cupos gratuitos ya usados.
- Un mismo cliente puede tener nuevos préstamos sin consumir otro cupo cuando coincide por teléfono o identidad registrada.
- Cambiar un préstamo existente a una persona diferente consume un nuevo cupo; si ya se alcanzaron 5, se solicita un plan ilimitado.
- Licencias Anual o Permanente válidas mantienen clientes ilimitados.
- La antigua demostración temporal se conserva en el motor de licencias, pero ya no forma parte del flujo comercial visible normal.
- La pantalla de plan muestra el uso actual del límite Gratis y prepara la presentación de Anual/Permanente para Google Play.

Se conserva lo ya implementado en v3.13.4:
- Finanzas, caja diaria e historial.
- Cierre automático de caja configurable.
- Recordatorios, recibos, garantías, respaldos y Google Drive.
- Compatibilidad con datos y licencias ya existentes al instalar encima de una versión anterior.


PrestaPro v3.14.1
- Pantalla Plan: oculta Gratis y opciones de compra cuando existe licencia Anual/Permanente activa.
- Iconografía SVG coherente en Finanzas, Caja diaria, Ajustes y navegación inferior.
- Sin cambios en datos, préstamos, caja, licencias ni reglas comerciales.


PrestaPro v3.15.0 — Recibos PDF e impresión
- Mantiene el botón para compartir el recibo como imagen PNG.
- Agrega Guardar PDF usando el selector de archivos de Android, sin pedir permiso general de almacenamiento.
- Agrega Compartir PDF mediante el menú nativo de Android.
- Agrega Imprimir mediante el servicio de impresión de Android.
- Los PDF se generan en tamaño A4 y los recibos largos se dividen automáticamente en varias páginas para mantener el texto legible.
- Las opciones funcionan también al reabrir recibos anteriores, cotizaciones, entrega de préstamo y comprobantes relacionados con garantía.


## PrestaPro v3.19.1 · Punto 4 — Exportar Finanzas
- Exportación Excel (.xlsx) completa desde Finanzas > Resumen.
- Hojas: Resumen, Préstamos, Cobros, Caja e Historial mensual.
- Exportación CSV de cobros del período seleccionado.
- Usa el selector Este mes / Todo el tiempo.
- Guardado mediante selector nativo de Android, sin permisos amplios de almacenamiento.


## PrestaPro v3.19.1 · Corrección CSV
- CSV de cobros ahora usa separador por comas compatible con Excel móvil.
- Mantiene UTF-8 con BOM para acentos y caracteres especiales.
- No cambia la exportación Excel .xlsx ni los cálculos financieros.


## PrestaPro v3.20.0 — Google Play Billing
- versionCode 65.
- Google Play Billing Library 9.1.0.
- Producto de suscripción: `prestapro_anual`.
- Producto único no consumible: `prestapro_permanente`.
- Compra, restauración con la cuenta de Google Play y reconocimiento de compras.
- El plan de Google Play convive con licencias externas ya emitidas.
- En instalaciones provenientes de Google Play se oculta la activación manual externa; en APK externas se conserva.
- Los datos del negocio se restauran por Google Drive o copia local; la compra de Play solo restaura el derecho al plan.

## v3.20.0 build fix
- Corrected Google Play Billing Java package imports (`com.android.billingclient.api`).
- Version remains 3.20.0 / versionCode 65 because the prior build did not produce an APK.


## Correcciones v3.20.4
- Una cuota que vence hoy ya no aparece como atrasada durante el mismo día.
- El historial de cumplimiento usa primero la fecha local guardada del pago (`payment.date`) y solo recurre a `dateTime` como respaldo, evitando falsos atrasos por UTC.
- Las penalizaciones semanales también comparan pagos por su fecha local efectiva.
- No se modifican pagos, saldos ni datos existentes; se corrige únicamente su interpretación visual/estadística.


## v3.20.5
- Corrige Caja e Historial para usar la fecha local real del pago; un cobro de ayer no se arrastra al cierre de hoy.
- Reconcilia cierres antiguos afectados por la fecha UTC sin borrar pagos reales.
- Incluye iconografía premium visual basada en la propuesta aprobada.
- Mantiene la corrección: Vence hoy no cuenta como atraso.


## v3.20.6 · Pulido visual premium
- Inicio: acciones y resumen con iconografía premium.
- Ajustes: iconos premium completados.
- Navegación inferior: nuevo estilo visual premium y estado activo más claro.
- Finanzas: pestañas Resumen / Caja diaria / Historial rediseñadas para verse claramente interactivas.
- Conserva correcciones de historial de cumplimiento, semáforo y caja diaria de v3.20.5.


## v3.20.7 · Filtros deslizables más intuitivos
- Rediseña la fila horizontal de filtros de Préstamos para que se perciba claramente como contenido deslizable.
- Agrega degradados laterales, flechas contextuales izquierda/derecha y pista “Desliza para ver más filtros”.
- Añade una microanimación inicial de descubrimiento la primera vez.
- Mantiene visibles y priorizados Todos, Pendientes hoy, Vencidos, Incobrables, Diario, Semanal y Garantía.
- Mejora el acabado visual de los chips y sus estados activos sin cambiar la lógica de filtrado.
- Conserva todas las correcciones funcionales de v3.20.6.
- versionCode 72 / versionName 3.20.7.

## v3.20.8 · Calendario operativo y domingo inteligente
- En préstamos diarios, los recordatorios por atraso se generan únicamente en el siguiente día real de cobranza.
- Domingo queda fuera de los recordatorios automáticos: una cuota vencida el sábado permanece pendiente, pero el primer aviso pasa al lunes si aún no fue pagada.
- Si el cliente paga extraordinariamente el domingo, el pago se registra en su fecha real y el lunes ya no se genera recordatorio por esa cuota.
- Los recordatorios por atraso muestran la fecha real de la cuota vencida con “Vencida desde”, en lugar de confundirla con la fecha de generación del aviso.
- El número de cuota mostrado en un recordatorio atrasado corresponde a la cuota más antigua pendiente.
- El cierre automático de caja funciona normal de lunes a sábado. El domingo solo genera cierre y notificaciones si hubo pagos/movimientos reales; con caja en cero no crea cierre vacío ni avisa.
- Mantiene intacta la lógica de historial de cumplimiento, penalidades por días de cobro, pagos extraordinarios y caja diaria.
- versionCode 73 / versionName 3.20.8.

## v3.20.9 · Recordatorio matutino por atraso
- Agrega un aviso automático independiente para cuotas vencidas, activado por defecto a las 09:00 y configurable desde Alertas y recordatorios.
- El recordatorio normal del día conserva su propio horario; el aviso por atraso funciona por separado.
- Aplica a préstamos diarios y semanales.
- En cobro diario respeta los días reales de cobranza; domingo no genera aviso y un atraso del sábado se revisa el lunes.
- Si el cliente paga antes de la hora del aviso, deja de corresponder el recordatorio por atraso.
- La imagen de atraso incorpora un símbolo visual de advertencia, “Primer atraso” / “Segundo atraso”, fecha real de vencimiento y saldo total pendiente.
- La notificación matutina abre directamente los recordatorios pendientes para revisar y compartir.
- versionCode 74 / versionName 3.20.9.


## v3.22.8 · Comprobación visible de alarmas exactas
- Basada en la v3.22.7 / v3.22.3 estable.
- Añade en Finanzas → Caja un bloque visible **Alarmas exactas** con estado Permitidas / No permitidas.
- Añade botón **Comprobar alarmas**. Si Android no concede el permiso, abre la configuración oficial de Alarmas y recordatorios.
- Muestra el próximo aviso y el próximo cierre programados.
- Al regresar de la configuración de Android, la app reprograma el cierre y actualiza el estado automáticamente.
- No se modifica la carga, guardado ni estructura de préstamos/datos.


## v3.22.19 / code 96
- Idiomas Bloque 3: traducción segura del contenido desplegable de fichas de préstamos en Español, English y Português (Brasil).
- Conserva corrección de Actividad reciente y navegación Atrás compatible con Android moderno y antiguo.


## v3.22.20 / code 97
- Penalización configurable para préstamo semanal de 1 semana, pago único y sin garantía.
- Valor inicial 0%; opciones 5%, 10%, 15%, 20% o personalizada.
- Al vencer sin pago, la penalización se aplica una sola vez sobre el saldo pendiente.
- Cotización, recibo de entrega, vista previa, detalle del préstamo y cálculo real usan la misma regla.
- No cambia la lógica de préstamos con garantía ni la regla de incumplimiento grave con garantía.


## v3.22.21 / code 98
- Nuevo flujo de cliente dentro de “Nuevo préstamo”: Cliente existente / Nuevo cliente.
- Búsqueda de clientes por nombre o CI/DNI y reutilización de la misma ficha para nuevos préstamos.
- Los clientes antiguos sin documento se conservan y pueden completar CI/DNI una sola vez al reutilizarlos.
- El registro interno de clientes ahora conserva tipo y número de documento y los recupera desde préstamos anteriores cuando existen.
- Protección contra duplicados por CI/DNI: si el documento ya existe, PrestaPro dirige al cliente existente.
- Los préstamos anteriores permanecen cerrados e independientes; un nuevo préstamo crea una nueva operación vinculada al mismo cliente.
- Sin cambios en cálculos financieros, cobros, penalizaciones, garantías, caja, respaldos ni licencias.


## v3.22.23 / code 100
- Idiomas Bloque 4: traducción segura de Nuevo préstamo y Cotizar en Español, English y Português (Brasil).
- Traduce campos, opciones, botones, buscador de cliente existente, estados de ficha, mensajes de validación y vistas previas de cálculo/cotización.
- Los valores internos de formularios no cambian; solo se traduce la presentación visible.
- Mantiene fuera de este bloque los textos legales largos, recibos/PDF y recordatorios completos para tratarlos en bloques separados.
- Conserva sin cambios los cálculos, clientes reales, penalizaciones, garantías, caja, respaldo, licencias y alarmas de la v3.22.22.


## v3.22.25 / code 102 — Bloque 6 de idiomas
- Recibos en pantalla: etiquetas, estados y valores estructurales ES/EN/PT-BR.
- Imagen del recibo / PDF / impresión: misma localización segura sin traducir nombres ni datos escritos por el usuario.
- Configuración de papel e impresora térmica traducida.
- Las cláusulas largas de penalización/garantía quedan reservadas para el Bloque 7.
- Sin cambios en cálculos, cobros, préstamos, caja, alarmas, licencias o respaldos.


## v3.22.26 / code 103 — Bloque 7 de idiomas

- Traducción segura de cláusulas y textos legales estándar a Español, English y Português (Brasil).
- Cláusulas estándar históricas se traducen solo al mostrarse/generarse; no se reescriben préstamos ni snapshots guardados.
- Cláusulas personalizadas por el usuario se conservan exactamente como fueron escritas.
- Penalización semanal/pago único y condiciones de garantía traducidas sin cambiar porcentajes, reglas ni cálculos.
- Cotizaciones, recibos, PDF, imagen e impresión muestran las cláusulas estándar en el idioma activo.
- Pantalla Ajustes > Cláusulas y reglas traducida.
- Los textos legales del canvas usan las reglas guardadas del préstamo/cotización en vez de valores fijos.
- Sin cambios en Java/Android, alarmas, caja, licencias, respaldo ni persistencia de préstamos.
