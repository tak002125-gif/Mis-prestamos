# PrestaPro v3.13.3

Mejora visual del encabezado de Inicio.

## Cambios
- Mantiene la marca **PrestaPro · by Taca** en el lado izquierdo.
- El espacio derecho del encabezado ahora muestra la identidad de **Mi negocio**.
- Si el usuario configuró nombre y logo, se muestran automáticamente en Inicio.
- Si todavía no configuró un negocio, se muestra **Mi negocio** con un icono comercial genérico.
- Estado dinámico de licencia: activa, prueba activa, vencida o sin licencia.
- Fecha actual según la configuración regional.
- Cantidad de cobros pendientes del día.
- Al tocar el bloque del negocio se abre directamente **Mi negocio** para editarlo.
- Conserva los botones **Nuevo préstamo** y **Cotizar**.
- Mantiene las mejoras de v3.13.2: Cláusulas y reglas por pestañas e Inicio sin botones duplicados.
