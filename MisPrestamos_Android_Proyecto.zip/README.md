# PrestaPro v3.19.1 — Incobrable / Irrecuperable

- Permite marcar un préstamo con saldo como “Incobrable” sin borrar la deuda, pagos, garantía ni historial.
- Solicita un motivo y permite añadir una nota administrativa.
- Agrega filtro visible “Incobrables” con contador.
- Un préstamo incobrable deja de aparecer en Pendientes hoy, Vencidos, recordatorios y alertas de cobranza.
- Mientras está incobrable no acumula nuevas penalidades por atraso.
- Finanzas conserva el capital y cobros históricos, pero excluye los incobrables de Total a recuperar, Saldo pendiente y Ganancia esperada.
- La tarjeta mantiene visible el saldo incobrable, fecha, motivo y garantía asociada.
- Incluye “Reactivar cobranza”; al reactivarlo no se aplican penalidades retroactivas por el período pausado.
- Todas las acciones quedan registradas en Historial de cambios.
- Mantiene intactos PIN/huella, caja automática, garantía, licencias, recibos, PDF e impresión térmica.

# PrestaPro v3.17.1 — Pendientes de hoy y vencidos

- Agrega filtros rápidos visibles en Préstamos: “Pendientes hoy” y “Vencidos”.
- Cada filtro muestra un contador actualizado automáticamente.
- “Pendientes hoy” reúne cuotas que corresponden hoy, cuotas anteriores todavía no regularizadas y penalidades pendientes a la fecha.
- “Vencidos” muestra únicamente préstamos realmente atrasados y con saldo pendiente.
- Dentro de “Pendientes hoy”, los préstamos vencidos se muestran primero para priorizar el cobro.
- El acceso “Cobrar hoy” del Inicio abre directamente la lista filtrada de pendientes del día.
- “Ver todos” en Vencimientos de hoy también abre el filtro de pendientes del día.
- Mantiene intactos seguridad PIN/biometría, caja automática, garantías, licencias, recibos, PDF e impresión térmica.

# PrestaPro v3.17.0 — Seguridad y acceso

- Agrega protección local mediante PIN de 4 a 6 dígitos.
- Al detectar que el dispositivo aún no tiene PIN de PrestaPro, muestra una recomendación de seguridad con “Configurar seguridad” o “Más tarde”; si se pospone, vuelve a recordarlo después de 7 días.
- El PIN se almacena derivado con PBKDF2 y sal; no se guarda en texto visible.
- Agrega desbloqueo opcional mediante huella/biometría registrada en Android.
- Agrega bloqueo automático configurable: inmediato, 1, 5, 15 o 30 minutos.
- Agrega botón “Bloquear ahora” para comprobar la protección sin cerrar la aplicación.
- La pantalla de bloqueo nativa oculta el contenido de PrestaPro hasta validar PIN o biometría.
- La configuración está en Ajustes > Seguridad y acceso.
- Permite cambiar el PIN o desactivar el bloqueo desde una sesión ya desbloqueada.
- No modifica préstamos, garantías, caja, licencias, recibos, PDF, impresión térmica ni respaldos.

# PrestaPro v3.16.1 — Interfaz compacta de comprobantes

- Mantiene los cuatro accesos principales en una cuadrícula compacta: Compartir imagen, Guardar PDF, Compartir PDF e Imprimir.
- PDF e impresión pasa a una tarjeta desplegable que resume el papel seleccionado sin ocupar espacio cuando está cerrada.
- Impresora térmica Bluetooth pasa a una tarjeta desplegable que resume ancho y estado/impresora seleccionada.
- La configuración térmica completa solo se muestra al expandirla: impresora emparejada, 58/80 mm, actualizar, ajustes Bluetooth e imprimir térmica.
- Ambas tarjetas se abren solo cuando el usuario necesita configurarlas, reduciendo el desplazamiento vertical.
- Se agregan iconos SVG coherentes con el resto de PrestaPro.
- No cambia la lógica de PDF, impresión normal, ESC/POS, caja, licencias ni datos del usuario.

# PrestaPro v3.16.0 — Impresión térmica Bluetooth

- Agrega impresión directa ESC/POS por Bluetooth para impresoras térmicas emparejadas.
- Permite elegir tickets de 58 mm o 80 mm.
- Lista únicamente dispositivos Bluetooth ya emparejados; no realiza escaneo de ubicación.
- Solicita el permiso Bluetooth solo al usar el módulo térmico.
- Permite abrir Ajustes Bluetooth desde PrestaPro para emparejar una impresora.
- Guarda la impresora y el ancho seleccionados para próximos tickets.
- Ticket compacto con negocio, recibo/préstamo, cliente, monto, saldo, fechas y estado.
- Intenta imprimir el logo mediante raster ESC/POS; si el modelo no lo admite, continúa con el texto.
- Mantiene intactos PDF Carta/A4/Automático e impresión normal de Android.

# PrestaPro v3.15.2

Comprobantes y PDF — ajuste final de formato:
- El generador real de recibos/cotizaciones usa ahora altura dinámica y recorte al final del contenido.
- Comprobantes compartidos como imagen más anchos y con márgenes laterales reducidos para verse mejor en teléfono/WhatsApp.
- Pie de comprobante más compacto.
- Selector de papel guardado: Carta (predeterminado), A4 o Automático.
- PDF Carta: 8,5 × 11 pulgadas. PDF A4: 210 × 297 mm.
- En Automático, Android elige el papel al imprimir; los PDF guardados/compartidos usan Carta como base.
- Guardar PDF, Compartir PDF e Imprimir respetan la selección de papel.
- Se mantiene pendiente para un bloque posterior la impresión térmica Bluetooth 58/80 mm.

# PrestaPro v3.15.1

Bloque visual de comprobantes compactos:
- Los recibos, cotizaciones y comprobantes compartidos como imagen ahora usan altura dinámica.
- Se elimina el gran espacio en blanco al final del comprobante en WhatsApp.
- Se reducen espacios verticales y se compactan bloques informativos sin perder datos importantes.
- Se mantiene la información clave: cliente, fecha, cuotas, método, monto, saldo y próximo cobro.
- Las cláusulas por atraso y garantía siguen apareciendo, pero en tarjetas más compactas.
- El diseño toma como referencia el estilo compacto de los recordatorios.

# PrestaPro v3.15.0

Bloque comercial Gratis / Anual / Permanente:
- PrestaPro Gratis funciona sin vencimiento con hasta 5 clientes registrados.
- Los clientes ya utilizados conservan su cupo aunque se elimine el préstamo, evitando reutilizar el límite gratuito.
- Restaurar una copia anterior o borrar los datos desde la app no reinicia los cupos gratuitos ya usados.
- Un mismo cliente puede tener nuevos préstamos sin consumir otro cupo cuando coincide por teléfono o identidad registrada.
- Cambiar un préstamo existente a una persona diferente consume un nuevo cupo; si ya se alcanzaron 5, se solicita un plan ilimitado.
- Licencias Anual o Permanente válidas mantienen clientes ilimitados.
- La antigua demostración temporal se conserva en el motor de licencias, pero ya no forma parte del flujo comercial visible normal.
- La pantalla de plan muestra el uso actual del límite Gratis y prepara la presentación de Anual/Permanente para Google Play.

Se conserva lo ya implementado en v3.13.4:
- Finanzas, caja diaria e historial.
- Cierre automático de caja configurable.
- Recordatorios, recibos, garantías, respaldos y Google Drive.
- Compatibilidad con datos y licencias ya existentes al instalar encima de una versión anterior.


PrestaPro v3.14.1
- Pantalla Plan: oculta Gratis y opciones de compra cuando existe licencia Anual/Permanente activa.
- Iconografía SVG coherente en Finanzas, Caja diaria, Ajustes y navegación inferior.
- Sin cambios en datos, préstamos, caja, licencias ni reglas comerciales.


PrestaPro v3.15.0 — Recibos PDF e impresión
- Mantiene el botón para compartir el recibo como imagen PNG.
- Agrega Guardar PDF usando el selector de archivos de Android, sin pedir permiso general de almacenamiento.
- Agrega Compartir PDF mediante el menú nativo de Android.
- Agrega Imprimir mediante el servicio de impresión de Android.
- Los PDF se generan en tamaño A4 y los recibos largos se dividen automáticamente en varias páginas para mantener el texto legible.
- Las opciones funcionan también al reabrir recibos anteriores, cotizaciones, entrega de préstamo y comprobantes relacionados con garantía.


## PrestaPro v3.19.1 · Punto 4 — Exportar Finanzas
- Exportación Excel (.xlsx) completa desde Finanzas > Resumen.
- Hojas: Resumen, Préstamos, Cobros, Caja e Historial mensual.
- Exportación CSV de cobros del período seleccionado.
- Usa el selector Este mes / Todo el tiempo.
- Guardado mediante selector nativo de Android, sin permisos amplios de almacenamiento.


## PrestaPro v3.19.1 · Corrección CSV
- CSV de cobros ahora usa separador por comas compatible con Excel móvil.
- Mantiene UTF-8 con BOM para acentos y caracteres especiales.
- No cambia la exportación Excel .xlsx ni los cálculos financieros.
