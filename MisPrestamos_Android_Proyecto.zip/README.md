# TACA Money v2.7

Proyecto Android nativo para compilar TACA Money.

## Cambios principales de v2.7

- Recordatorios visuales también para cobros semanales, con vista previa antes de compartir.
- El recordatorio muestra el número de cuota (Cuota X de N).
- Aviso diario configurable (por defecto 13:00 en instalaciones nuevas). La app avisa; no envía mensajes automáticamente.
- Historial de recordatorios enviado por WhatsApp/compartido.
- Penalidad acumulativa se mantiene exclusivamente para cobros diarios: desde el tercer atraso, una cuota adicional por cada día de cobro programado sin regularizar.
- Garantías: descripción, estado, fotografía, valor de referencia y declaración de propiedad/autorización.
- Registro de fecha/hora de aceptación de condiciones de garantía.
- Cobro diario con garantía: opción manual de cierre mediante garantía cuando la condición de atraso ya está activa. Al cerrar, se detienen nuevos cobros y penalidades en la app y se genera recibo de cierre.
- Cobro semanal por cuotas con garantía: con 2 cuotas semanales consecutivas incumplidas se marca incumplimiento grave, se suspenden nuevos recordatorios y la garantía queda sujeta al procedimiento de ejecución, previa confirmación manual.
- La cotización con garantía muestra y exige aceptación de estas condiciones antes de generar el comprobante.
- La app nunca transfiere automáticamente la propiedad de una prenda; cualquier ejecución debe ajustarse al acuerdo y a la normativa aplicable.
- Compatibilidad con préstamos y respaldos de versiones anteriores.

## Compilación

La configuración del proyecto mantiene Android SDK 35, Java 17, Gradle 8.7 y el sistema de firma permanente configurado mediante variables/secretos del workflow.

No incluir archivos de clave privada dentro del repositorio público.
