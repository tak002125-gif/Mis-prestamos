const assert=require('assert'),fs=require('fs'),vm=require('vm');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const gradle=fs.readFileSync('app/build.gradle','utf8');
assert(gradle.includes('versionCode 133')&&gradle.includes('versionName "3.22.56"'));
const names=['ruleDailyClausesEnabled','ruleDailyPenaltyEnabled','ruleWeeklyClausesEnabled','ruleWeeklyPenaltyEnabled'];
for(const name of names){
  assert(html.includes('id="'+name+'" value="yes"'),`Sí para ${name}`);
  assert(html.includes('id="'+name+'No" value="no"'),`No para ${name}`);
  assert(html.includes('name="'+name+'"'),`Grupo nativo de ${name}`);
  assert(!html.includes('<select id="'+name+'"'),`No debe quedar selector recortado para ${name}`);
  assert(html.includes('aria-labelledby="'+name+'Label"'),`Grupo accesible ${name}`);
}
for(const key of ['clause-choice-group','clause-choice-option','min-height:48px','grid-template-columns:1fr;gap:12px'])assert(html.includes(key));
for(const id of ['ruleDailyGrace','ruleWeeklyDefaultPenalty','ruleCollateralGrace'])assert(html.includes('id="'+id+'"'));
const start=html.indexOf('  function setRuleChoice(');
const end=html.indexOf('  function refreshClausesForm()',start);
assert(start>0&&end>start);
const items=Object.fromEntries(names.map(name=>[name,[{value:'yes',checked:false},{value:'no',checked:false}]]));
const document={querySelectorAll(q){const m=q.match(/input\[name="([^"]+)"\]/);return m?items[m[1]]:[];},querySelector(q){const m=q.match(/input\[name="([^"]+)"\]:checked/);return m?items[m[1]].find(x=>x.checked)||null:null;}};
const ctx={document};vm.createContext(ctx);vm.runInContext(html.slice(start,end),ctx);
for(const name of names){
  ctx.setRuleChoice(name,true);assert.equal(ctx.readRuleChoice(name),true);assert.deepStrictEqual(items[name].map(x=>x.checked),[true,false]);
  ctx.setRuleChoice(name,false);assert.equal(ctx.readRuleChoice(name),false);assert.deepStrictEqual(items[name].map(x=>x.checked),[false,true]);
}
assert(html.includes("dailyPenaltyEnabled:readRuleChoice('ruleDailyPenaltyEnabled')"));
assert(html.includes("weeklyPenaltyEnabled:readRuleChoice('ruleWeeklyPenaltyEnabled')"));
assert(html.includes('setRuleChoice(\'ruleDailyClausesEnabled\',r.dailyClausesEnabled)'));
assert(html.includes('setRuleChoice(\'ruleWeeklyClausesEnabled\',r.weeklyClausesEnabled)'));
assert(html.includes("'Sí':'Yes','No':'No'"));
assert(html.includes("'Sí':'Sim','No':'Não'"));
console.log('PASS 3.22.56: Sí/No visibles y accesibles, guardado/lectura compatible, otros campos y traducciones intactos');
