# PrestaPro 3.22.62 — 27/11/2026

ES: Recordatorios semanales con cuota original, abonos recibidos y saldo pendiente real. Diferencia cuotas vencidas de las que vencen hoy, muestra prórrogas autorizadas y penalización pendiente por separado. Mensaje e imagen de WhatsApp con los mismos importes. Sin cambios en reglas de cobro, recibos, préstamos diarios ni Finanzas.

EN: Weekly reminders show original installment, payments received and remaining installment balance. Separates overdue and due-today installments, displays authorized extensions and outstanding late fees separately. Matching reminder image and WhatsApp caption. Existing collection rules, receipts, daily loans and Finance remain unchanged.

PT-BR: Lembretes semanais com parcela original, abonos recebidos e saldo pendente real. Separa parcelas vencidas das que vencem hoje e mostra prorrogações autorizadas e multas pendentes separadamente. Imagem e mensagem do WhatsApp com os mesmos valores. Regras de cobrança, recibos, empréstimos diários e Finanças preservados.
