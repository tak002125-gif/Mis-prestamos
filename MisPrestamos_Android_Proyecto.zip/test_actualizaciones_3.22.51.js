const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const gradle=fs.readFileSync('app/build.gradle','utf8');
const native=fs.readFileSync('app/src/main/java/com/remberto/misprestamos/PrestaProUpdateChecker.java','utf8');
const activity=fs.readFileSync('app/src/main/java/com/remberto/misprestamos/MainActivity.java','utf8');
assert(gradle.includes('versionCode 128')&&gradle.includes('versionName "3.22.51"'));
assert(gradle.includes('applicationId "com.remberto.misprestamos"')&&gradle.includes('keyAlias "taca_money"'));
assert(native.includes('remoteCode > installedCode')&&native.includes('"https".equalsIgnoreCase(url.getScheme())'));
assert(native.includes('"/PrestaPro.apk".equals(url.getPath())'));
assert(native.includes('OFFICIAL_HOST.equalsIgnoreCase(url.getHost())'));
assert(native.includes('setInstanceFollowRedirects(false)'));
assert(native.includes('setConnectTimeout(6500)')&&native.includes('MAX_MANIFEST_BYTES'));
assert(native.includes('installedFromPlay')===false); // consulta desde MainActivity
assert(activity.includes('void checkForAppUpdates()')&&activity.includes('void openAppUpdateDownload(String url)'));
assert(activity.includes('updateChecker.check(false)')&&activity.includes('updateChecker.setPageReady()'));
assert(html.includes('id="settingsUpdateCheckBtn"')&&html.includes('id="appUpdateModal"'));
const start=html.indexOf('  const appUpdateModal=$(\'#appUpdateModal\');');
const end=html.indexOf('  function refreshAppVersion(){',start);
assert(start>=0&&end>start);
const source=html.slice(start,end);
const els=new Map();
const get=(key)=>{
 if(!els.has(key)) els.set(key, {
  style:{display:'none'},classList:{open:false,contains(t){return this.open;},add(t){this.open=true;},remove(t){this.open=false;}},
  textContent:'',value:'', children:[],childElementCount:0,
  replaceChildren(){this.children=[];this.childElementCount=0;},
  appendChild(n){this.children.push(n);this.childElementCount++;},
  listeners:{},addEventListener(evt,fn){this.listeners[evt]=fn;}
 });
 return els.get(key)
};
const modal=get('#appUpdateModal');
const local=new Map();let nativeChecks=0,openedUrl='';let modalCount=0;
const ctx={
 $:get,meta:{language:'es'},localStorage:{getItem(k){return local.get(k)||null;},setItem(k,v){local.set(k,v)}},
 document:{createElement:tag=>({tag,textContent:''}),querySelectorAll:()=>modalCount?[{}]:[]},
 window:{AndroidApp:{checkForAppUpdates(){nativeChecks++;},openAppUpdateDownload(url){openedUrl=url;}}},
 openModal:m=>m.classList.add('open'),closeModal:m=>m.classList.remove('open'),
 setTimeout:(fn)=>fn(),
};
vm.createContext(ctx);vm.runInContext(source,ctx);
assert.equal(get('#settingsUpdateTitle').textContent,'');
const release={status:'available',manual:false,versionCode:129,versionName:'3.22.52',downloadUrl:'https://prestapro.tacaapps.app/PrestaPro.apk?v=3.22.52',releaseNotes:['Mejora A','Mejora B']};
ctx.window.receivePrestaProUpdateStatus(release);
assert.equal(modal.classList.open,true,'Notificación automática de nueva versión');
assert.equal(get('#appUpdateNotes').childElementCount,2);
assert.equal(get('#settingsUpdateBadge').style.display,'inline-block');
get('#appUpdateLater').listeners.click();
assert.equal(modal.classList.open,false);
assert.equal(local.get('prestapro_update_dismissed_v1'),'129');
ctx.window.receivePrestaProUpdateStatus(release);
assert.equal(modal.classList.open,false,'No repite modal de versión descartada');
get('#settingsUpdateCheckBtn').listeners.click();
assert.equal(nativeChecks,1,'Comprobación manual');
assert.equal(modal.classList.open,true);
ctx.window.receivePrestaProUpdateStatus({...release,manual:true});
assert.equal(modal.classList.open,true,'La comprobación manual muestra versión descartada');
get('#appUpdateDownload').listeners.click();
assert.equal(openedUrl,release.downloadUrl,'Descarga oficial');
assert.equal(modal.classList.open,false);
ctx.window.receivePrestaProUpdateStatus({status:'current',manual:true,versionCode:128});
assert.equal(get('#appUpdateActions').style.display,'none');
assert.equal(get('#settingsUpdateBadge').style.display,'none');
assert.equal(modal.classList.open,true);
get('#closeAppUpdate').listeners.click();
assert.equal(modal.classList.open,false);
ctx.window.receivePrestaProUpdateStatus({status:'error',manual:true,message:'Sin conexión'});
assert.equal(get('#appUpdateTitle').textContent,'No se pudo comprobar');
assert.equal(get('#appUpdateActions').style.display,'none');
get('#closeAppUpdate').listeners.click();
ctx.meta.language='pt-BR';ctx.window.receivePrestaProUpdateStatus({status:'checking',manual:true});
assert.equal(get('#appUpdateTitle').textContent,'Verificando atualizações…');
ctx.meta.language='en';ctx.window.receivePrestaProUpdateStatus({status:'current',manual:true});
assert.equal(get('#appUpdateTitle').textContent,'You are up to date!');
console.log('PASS: comprobación nativa/HTTPS/firmado, estado disponible, posponer, versión actual, errores, actualización manual, traducciones y enlaces');
