const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const html=fs.readFileSync(path.join(__dirname,'app/src/main/assets/index.html'),'utf8');
const gradle=fs.readFileSync(path.join(__dirname,'app/build.gradle'),'utf8');
assert(/versionCode\s+(13[1-9]|1[4-9][0-9])/.test(gradle)&&/versionName "3\.22\.(5[4-9]|[6-9][0-9])"/.test(gradle));
function fn(name){const start=html.indexOf(`  function ${name}(`);assert(start>=0,`Falta ${name}`);const next=html.indexOf('\n  function ',start+5);return html.slice(start,next<0?undefined:next);}
function createLoan(overrides={}){
 return {id:'Y',client:'Yessica ferreira menacho',loanCode:'PRE-2026-0010',collectionFrequency:'daily',amount:1000,total:1200,paid:1200,penaltyCountAccrued:1,penaltyAmountAccrued:50,penaltyPaid:0,penaltyWaivedAmount:0,penaltyWaiverEvents:[],installments:24,installmentAmount:50,uncollectible:false,closedWithCollateral:false,auditTrail:[],payments:Array.from({length:17},(_,i)=>({paymentId:'test'+i,amount:i===16?50:0,voided:false})),...overrides};
}
let loan=createLoan(),saved=0,rendered=0,alerts=0,toasts=[],modalOpen=0,confirmationCount=0;
const els={'#penaltyWaiverSummary':{innerHTML:''},'#penaltyWaiverReason':{value:''}};
const ctx={loans:[loan],currentPenaltyWaiverLoanId:'',penaltyWaiverModal:{},$:id=>els[id],
 requireCommercialLicense:()=>true,money:n=>'Bs '+Number(n).toFixed(2),esc:x=>String(x).replace(/&/g,'&amp;'),
 todayISO:()=> '2026-11-20',overdueBeforeToday:()=> 5,loanRules:()=>({dailyPenaltyEnabled:true,dailyGraceMisses:2}),
 openModal:()=>modalOpen++,closeModal:()=>modalOpen--,save:()=>saved++,render:()=>rendered++,syncNativeAlerts:()=>alerts++,toast:m=>toasts.push(m),
 confirm:msg=>{confirmationCount++;assert(msg.includes('No se registrará ningún cobro'));return true;},
 weeklyGuaranteeDefault:()=>false,weeklyPenaltyEligibleFor:()=>true};
vm.createContext(ctx);
vm.runInContext(['paidInstallments','penaltyAccrued','penaltyWaived','penaltyBalance','baseBalanceRaw','baseBalance','totalDebt','debtBalance','refreshPenalty','waiveWeeklyPenalty','addAudit','statusOf','openPenaltyWaiverModal','confirmPenaltyWaiver'].map(fn).join('\n'),ctx);

Object.assign(loan,{collectionFrequency:'weekly',weeklyPenaltyEvents:[{dueDate:'2026-11-01',amount:120,waivedAmount:0}],penaltyAmountAccrued:120,penaltyPaid:20,paid:450,weeklyPenaltyPercent:0});
vm.runInContext("openPenaltyWaiverModal('Y')",ctx);els['#penaltyWaiverReason'].value='Excepción autorizada';vm.runInContext('confirmPenaltyWaiver()',ctx);
assert.equal(loan.paid,450);assert.equal(loan.penaltyPaid,20);assert.equal(loan.weeklyPenaltyEvents[0].waivedAmount,100);assert.equal(vm.runInContext('penaltyBalance(loans[0])',ctx),0);assert.equal(loan.penaltyWaiverEvents.length,1);vm.runInContext('refreshPenalty(loans[0])',ctx);assert.equal(vm.runInContext('penaltyBalance(loans[0])',ctx),0);console.log('PASS weekly waiver');
