const fs=require('fs'),assert=require('assert'),vm=require('vm');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const gradle=fs.readFileSync('app/build.gradle','utf8');
assert(gradle.includes('versionCode 132')&&gradle.includes('versionName "3.22.55"'));
for(const id of ['ruleDailyClausesEnabled','ruleDailyPenaltyEnabled','ruleDailyGrace','ruleWeeklyClausesEnabled','ruleWeeklyPenaltyEnabled','ruleWeeklyDefaultPenalty','clauseDailyText','clauseWeeklyText']) assert(html.includes('id="'+id+'"'),`Falta ${id}`);
assert(html.includes('clauseSnapshot:configuredClausesForFrequency(freq)'), 'La cotización debe congelar cláusulas de su modalidad');
assert(html.includes('clauseSnapshot:configuredClausesForFrequency(collectionFrequency)'), 'El préstamo debe congelar sus cláusulas');
assert(html.includes('weeklyPenaltyAllowedForForm()&&weeklyPenaltyEligibleFor(collectionFrequency'), 'Nueva operación semanal debe respetar interruptor');
assert(html.includes('activeRules().weeklyPenaltyEnabled&&weeklyPenaltyEligibleFor(freq'), 'Cotización semanal debe respetar interruptor');
assert(html.includes('dailyTermsNeeded()&&!lateTermsAccepted'), 'Aceptación diaria condicional');
const slice1=html.slice(html.indexOf('  function defaultRules(){'),html.indexOf('  function formatLicenseDate('));
assert(slice1.startsWith('  function defaultRules()'));
const meta={rules:{},clauses:{
 daily:{enabled:true,text:'Texto diario'},weekly:{enabled:true,text:'Texto semanal'},
 weeklyCollateral:{enabled:true,text:'Garantía semanal'},collateral:{enabled:true,text:'Garantía normal'},
 receipt:{enabled:true,text:'Recibo'},quote:{enabled:true,text:'Cotización'}
}};
const el={};const get=s=>el[s]||(el[s]={value:'',style:{},checked:false,dataset:{}});
const ctx={meta,$:get,quoteFrequency:()=> 'daily',normalizedLanguage:(lang)=>['es','en','pt-BR'].includes(lang)?lang:'es',B7_DEFAULT_CLAUSES:{es:{daily:'Texto diario'},en:{daily:'Daily text'},'pt-BR':{daily:'Texto diario'}},Number,JSON,Math,String};
vm.createContext(ctx);vm.runInContext(slice1,ctx);
assert.equal(ctx.activeRules().dailyPenaltyEnabled,true);
assert.equal(ctx.activeRules().weeklyPenaltyEnabled,true);
assert.equal(ctx.activeRules().weeklyPenaltyDefaultPercent,0);
const original=ctx.configuredClausesForFrequency('daily');assert.equal(original.daily.enabled,true);assert.equal(original.weekly.enabled,false);
meta.rules.dailyClausesEnabled=false;meta.rules.dailyPenaltyEnabled=false;
const noDaily=ctx.configuredClausesForFrequency('daily');assert.equal(noDaily.daily.enabled,false);assert.equal(ctx.dailyTermsNeeded(),false);
assert.equal(meta.clauses.daily.enabled,true,'Apagar global no debe borrar texto o interruptor individual');
meta.rules.weeklyClausesEnabled=false;meta.rules.weeklyPenaltyEnabled=false;
const noWeekly=ctx.configuredClausesForFrequency('weekly');assert.equal(noWeekly.weekly.enabled,false);assert.equal(noWeekly.weeklyCollateral.enabled,false);
assert.equal(noWeekly.collateral.enabled,true,'Reglas de garantías independientes intactas');
assert.equal(meta.clauses.weekly.enabled,true,'Apagar global no debe borrar texto editable');
const pastLoan={ruleSnapshot:{dailyPenaltyEnabled:true,dailyGraceMisses:2},clauseSnapshot:{daily:{enabled:true,text:'Contrato original'}}};
assert.equal(ctx.loanRules(pastLoan).dailyPenaltyEnabled,true,'No alterar regla de préstamo viejo');
assert.equal(pastLoan.clauseSnapshot.daily.enabled,true,'No alterar cláusulas históricas');
meta.rules.dailyClausesEnabled=true;meta.rules.dailyPenaltyEnabled=false;
assert.equal(ctx.configuredClausesForFrequency('daily').daily.text,ctx.dailyWithoutPenaltyText(),'Texto predeterminado no debe prometer multa desactivada');
// Semanales: desactivar multa debe ocultarla en un préstamo nuevo, sin modificar ediciones históricas.
const slice2=html.slice(html.indexOf('  function readWeeklyPenaltyPercent('),html.indexOf('  function toggleCollateralFields('));
assert(slice2.startsWith('  function readWeeklyPenaltyPercent('));
Object.assign(ctx,{block4Text:(k)=>k,weeklyPenaltyClauseTextLocalized:()=>'Cláusula de prueba',weeklyPenaltySummaryLocalized:()=>'Resumen de prueba',Number,Math});
vm.runInContext(slice2,ctx);
get('#collectionFrequency').value='weekly';get('#weeklyPaymentMode').value='installments';get('#installments').value='4';get('#hasCollateral').value='no';get('#weeklyPenaltyRate').value='10';get('#weeklyPenaltyCustom').value='';get('#weeklyPenaltyTermsAccepted').checked=true;
ctx.updateWeeklyPenaltyFields();assert.equal(get('#weeklyPenaltyRateWrap').style.display,'none','Multa semanal desactivada no debe aparecer');assert.equal(get('#weeklyPenaltyTermsWrap').style.display,'none');
get('#loanForm').dataset.edit='historico';ctx.updateWeeklyPenaltyFields();assert.equal(get('#weeklyPenaltyRateWrap').style.display,'block','Editar un préstamo viejo no debe borrar la regla anterior');delete get('#loanForm').dataset.edit;
meta.rules.weeklyPenaltyEnabled=true;meta.rules.weeklyPenaltyDefaultPercent=12.5;
assert.equal(ctx.activeRules().weeklyPenaltyDefaultPercent,12.5);
ctx.useWeeklyPenaltyPreset('#weeklyPenaltyRate','#weeklyPenaltyCustom');assert.equal(get('#weeklyPenaltyRate').value,'custom');assert.equal(get('#weeklyPenaltyCustom').value,'12.5');
ctx.updateWeeklyPenaltyFields();assert.equal(get('#weeklyPenaltyRateWrap').style.display,'block');assert.equal(get('#weeklyPenaltyTermsWrap').style.display,'flex');
meta.rules.weeklyPenaltyEnabled=false;
get('#quoteType').value='daily';get('#quoteCollateralFrequency').value='weekly';get('#quoteWeeklyPaymentMode').value='installments';get('#quoteCount').value='4';get('#quoteWeeklyPenaltyRate').value='10';
ctx.updateQuoteWeeklyPenaltyFields=ctx.updateQuoteWeeklyPenaltyFields || (()=>{throw new Error('No existe función semanal de cotización')});
// Esta función usa quoteFrequency() y queda oculta al estar desactivada la multa semanal.
ctx.updateQuoteWeeklyPenaltyFields(); // quoteFrequency emulado: diario, no elegible
assert.equal(get('#quoteWeeklyPenaltyRateWrap').style.display,'none');
console.log('PASS 3.22.55: selectores independientes, cláusulas editables, penalizaciones semanales configurables, snapshots históricas, sin falsas multas');
