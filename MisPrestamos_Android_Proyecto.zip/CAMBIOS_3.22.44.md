# PrestaPro 3.22.44 (versionCode 121) — Pago mixto

## Propósito

Registrar **un único cobro** recibido mediante **QR + efectivo** y conservar el desglose real de ambos importes, sin duplicar capital, saldos, cuotas ni ganancias.

## Cambios realizados

1. **Cobrar cuota → Método de pago:** se mantienen «Efectivo» y «QR» y se agrega «Mixto (QR + Efectivo)».
2. **Desglose obligatorio cuando se elige Mixto:** campos «Recibido por QR» y «Recibido en efectivo». Se verifica en **centavos enteros** que ambos montos sean positivos y sumen exactamente el importe del cobro. Si no coinciden, no se registra el pago.
3. **Almacenamiento:** cada pago nuevo registra los campos `cashAmount` y `qrAmount`, además del total `amount` y método `method`. Los pagos antiguos **no se reescriben ni migran**: `QR` sigue siendo 100% QR y `Efectivo` sigue siendo 100% efectivo.
4. **Caja diaria y cierre:** los importes se reparten entre las columnas Efectivo y QR. Un pago mixto cuenta como **un solo cobro**, un solo cliente y un único recibo. Se actualiza también el cálculo del cierre automático/manual y de los movimientos posteriores al cierre, sin modificar el aviso programado de 15 minutos.
5. **Historial y corrección:** se muestra el desglose del pago mixto. Es posible corregir un pago previo a «Mixto», con motivo obligatorio, conservando la auditoría original. Si el cobro pertenece a una caja cerrada, se advierte que ese cierre deberá revisarse y realizarse de nuevo, conforme al comportamiento de correcciones vigente.
6. **Recibos:** un recibo mixto incluye «Método: Mixto», «Recibido por QR», «Recibido en efectivo» y el total. Se aplica a la vista previa, a imagen, PDF y recibo térmico.
7. **Finanzas y exportación:** las filas de Cobros exportadas a Excel/CSV incluyen, al final, las nuevas columnas «Efectivo recibido» y «QR recibido»; se conservan las columnas anteriores y sus posiciones.
8. **Compatibilidad:** se mantiene el mismo `applicationId`, firma configurada en GitHub, claves de datos, licencias, respaldo Drive y versión de formato de respaldo. No se modifican importes históricos ni saldos existentes.

## Ejemplo ficticio

- Pago total: **Bs 3.600,00**.
- QR: **Bs 2.000,00**.
- Efectivo: **Bs 1.600,00**.
- Capital/ganancias/cuota: se aplica **Bs 3.600,00 una sola vez** mediante los cálculos existentes.
- Caja diaria: QR **Bs 2.000,00**, Efectivo **Bs 1.600,00**; Total **Bs 3.600,00**; Cobros **1**.

## Límites de alcance

- **No se agrega «Depositar efectivo al banco»** en esta versión; eso sería un movimiento entre cuentas, no un cobro adicional.
- Los cobros ya registrados como QR o efectivo **permanecen tal como están**, salvo corrección manual explícita.
- Esta versión todavía requiere compilación Android en GitHub y pruebas reales antes de instalarla en un dispositivo con datos de clientes.
