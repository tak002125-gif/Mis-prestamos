# PrestaPro 3.22.49 (versionCode 126)

## Mejora única: ordenar clientes en «Finanzas > Desglose de ganancias»

El listado de clientes ahora se ordena por el **estado actual de todos sus préstamos**:

1. **Clientes con préstamos activos** (incluidos atrasados), primero. Dentro de este grupo aparece antes quien tiene la próxima cuota con vencimiento más cercano, considerando prórrogas individuales aplicables.
2. **Clientes sin préstamos activos**, después. Entre estos, aparecen primero los que finalizaron más recientemente; si hay incobrables o cierres, permanecen sin préstamos activos, pero sus préstamos individuales NO se marcan como pagados.

Los grupos aparecen con una cabecera clara y mantienen el detalle de cada préstamo y de cada cobro.

### Caso de cliente que vuelve a pedir otro préstamo

- Si un cliente termina todas sus cuotas, baja al grupo sin préstamos activos.
- Si más adelante se le presta de nuevo, **regresa al grupo activo incluso antes de recibir el primer abono**.
- Si termina de pagar todos sus préstamos, vuelve abajo.
- Nunca se borran ni se reescriben préstamos anteriores, recibos o movimientos.

### Alcance del cambio

- La agrupación identifica clientes igual que antes (`clientKey`, documento o nombre normalizado) y consulta los préstamos completos para saber su estado actual.
- El desglose sigue mostrando solo los movimientos que cumplen la búsqueda y filtros seleccionados. Cuando se muestra un préstamo anterior pero el cliente tiene otro préstamo activo sin movimientos en ese filtro, se explica dentro del desglose.
- La selección de «Activos»/«Finalizados» sigue filtrando **préstamos** según su estado, mientras que el orden de los **clientes** depende de todos sus préstamos. Esto evita que un préstamo anterior pagado esconda una deuda vigente del mismo cliente.
- Los importes, la lógica de préstamos, contabilidad, capital, penalizaciones, comprobantes, pagos mixtos, cierres, prórrogas, respaldos y licencias permanecen intactos.
- Los rótulos añadidos están traducidos a español, inglés y portugués.

## Seguridad técnica

- `applicationId`: `com.remberto.misprestamos` (sin cambios).
- Misma configuración de firma permanente en GitHub (`taca_money`; no se incluye llave privada).
- Solo se modifica la presentación y el orden en `app/src/main/assets/index.html`, más el incremento de versión en `app/build.gradle`.
- No existe migración de datos ni modificaciones del almacenamiento.

## Pruebas

- `node test_orden_clientes_3.22.49.js` — casos de représtamo, estados, orden, filtros, importes y renderizado con clientes ficticios.
- `node test_resumen_finanzas_3.22.48.js` — regresión de Finanzas.
- `node test_prorroga_semanal.js`
- `node test_calendario_semanal.js`
- `node test_payments_mixtos.js`
- `node test_autorelleno_mixto.js`
- Sintaxis de JavaScript validada con Node 22.

**Pendiente:** compilación y verificación de la APK firmada en GitHub Actions; prueba final en dispositivo Android después de realizar respaldo.
