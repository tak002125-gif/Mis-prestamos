const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const start=html.indexOf('  function matchingExistingClients(query=\'\'){');
const end=html.indexOf('  function setClientMode(mode,clearFields=true){',start);
assert(start>0&&end>start,'Bloque de búsqueda no encontrado');
const searchSource=html.slice(start,end);
const normalizers=html.slice(html.indexOf('  function normalizeClientName(value){'),html.indexOf('  function loadFreeClientLedger(){'));
const people=[
 {id:'a',name:'Edison Ativiana',phone:'70010001',documentNumber:'1212121',updatedAt:20},
 {id:'b',name:'Édgar Peralta',phone:'77771111',documentNumber:'8787878',updatedAt:22},
 {id:'c',name:'María Pérez',phone:'76543210',documentNumber:'5555555',updatedAt:30},
 {id:'d',name:'Juan Edison López',phone:'78945612',documentNumber:'3444455',updatedAt:10},
 {id:'e',name:'Carlos Díaz',phone:'',documentNumber:'1234567',updatedAt:5}
];
const resultBox={innerHTML:'',querySelectorAll(){return[];},querySelector(){return null;}};
let selectedId=null,preventCount=0,stopCount=0,blurCount=0;
const input={value:'',blur:()=>{blurCount++},listeners:{},addEventListener(type,fn){this.listeners[type]=fn;}};
const ctx={
 freeClientLedger:people.map(x=>({...x,nameKey:x.name.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim(),documentKey:x.documentNumber})),
 $:sel=>sel==='#existingClientResults'?resultBox:sel==='#existingClientSearch'?input:null,
 block4Text:s=>s,
 clientDocumentText:p=>p.documentNumber,
 clientLedgerSummary:()=>({active:1,finished:0}),clientInitials:n=>n.slice(0,2).toUpperCase(),
 esc:v=>String(v),selectExistingClient:e=>{selectedId=e?.id},findClientLedgerById:id=>people.find(x=>x.id===id),
};
vm.createContext(ctx);vm.runInContext(normalizers+searchSource,ctx);
function ids(q){return Array.from(vm.runInContext(`matchingExistingClients(${JSON.stringify(q)})`,ctx),x=>x.id)}
assert.deepStrictEqual(ids('Edison').sort(),['a','d']);
assert.deepStrictEqual(ids('édison').sort(),['a','d']);
assert.deepStrictEqual(ids('ativiana'),['a']);
assert.deepStrictEqual(ids('EDGAR'),['b']);
assert.deepStrictEqual(ids('76543210'),['c']);
assert.deepStrictEqual(ids('1234567'),['e']);
assert.deepStrictEqual(ids('7001'),['a']);
assert.deepStrictEqual(ids('sin coincidencias'),[]);
assert.deepStrictEqual(ids('').length,5);
// 30 resultados como máximo en interfaz; búsqueda completa sin recortar antes de Enter.
vm.runInContext(`renderExistingClientResults('Edison')`,ctx);
assert(resultBox.innerHTML.includes('Edison Ativiana')&&resultBox.innerHTML.includes('Juan Edison López'));
assert(!resultBox.innerHTML.includes('María Pérez'));
vm.runInContext(`renderExistingClientResults('sin coincidencias')`,ctx);
assert(resultBox.innerHTML.includes('noMatches'));
// Registrar exactamente el controlador de Enter agregado a la app.
const listenerStart=html.indexOf("  $('#existingClientSearch').addEventListener('keydown',e=>{");
const listenerEnd=html.indexOf("  $('#btnNew').addEventListener",listenerStart);
assert(listenerStart>0&&listenerEnd>listenerStart);
vm.runInContext(html.slice(listenerStart,listenerEnd),ctx);
const press=(query)=>{input.value=query;selectedId=null;input.listeners.keydown({key:'Enter',currentTarget:input,preventDefault(){preventCount++},stopPropagation(){stopCount++}});return selectedId;};
assert.equal(press('ativiana'),'a','Enter debe seleccionar cliente único');
assert.equal(press('Edison'),null,'Enter no debe seleccionar si hay dos coincidencias');
assert.equal(press('nombre inexistente'),null,'Enter no debe seleccionar cuando no existe');
assert.equal(press(''),null,'Enter vacío no selecciona');
assert.equal(preventCount,4,'Enter no debe enviar el formulario');
assert.equal(stopCount,4);
assert.equal(input.getAttribute,undefined);
console.log('PASS búsqueda clientes v3.22.50: texto/acentos, CI/DNI, teléfono, vacío, sin coincidencias, Enter y selección única');
