# Pruebas de PrestaPro 3.22.47 en teléfono Android

1. Antes de actualizar el Xiaomi, confirmar que la copia de seguridad es reciente y verificar clientes, saldos y licencia.
2. Instalar como **actualización**, nunca desinstalando la app con datos existentes.
3. En un préstamo semanal de 3 cuotas, abrir **Ver detalles y opciones**: comprobar primera, segunda y tercera cuota, sus importes y fechas originales.
4. En un préstamo semanal con prórroga, comprobar que la cuota afectada muestra **fecha original y prórroga**, y que las otras fechas no cambiaron.
5. Abrir **Recibo entrega**: comprobar que la vista previa incluye el calendario original. Luego verificar imagen y PDF compartidos (las tres fechas y sus montos).
6. Comprobar préstamos semanales de 1, 2 y 4 cuotas si existen; para pago único semanal debe figurar solo la fecha de su único pago.
7. Abrir un préstamo diario y comprobar que no aparece el nuevo calendario y que su cobro funciona igual.
8. Verificar que la cotización, el pago mixto, el capital, la caja, la licencia y el respaldo siguen como estaban.
9. Si alguna fecha no coincide, no editar datos ni realizar un pago ficticio en el Xiaomi; informar el problema antes de publicar.
