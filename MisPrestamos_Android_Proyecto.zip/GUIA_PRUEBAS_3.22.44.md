# Protocolo de prueba — PrestaPro 3.22.44

## Reglas de seguridad para el Xiaomi de trabajo

1. Probar primero en Samsung y Tecno con datos ficticios. **No** publicar la actualización web hasta confirmar su comportamiento.
2. Antes de actualizar el Xiaomi: comprobar que abre normalmente, verificar todos los datos reales y **crear y comprobar un respaldo reciente de Google Drive**.
3. Instalar siempre sobre la versión anterior. **No desinstalar** ni borrar almacenamiento ni restaurar datos para probar la mejora.
4. Conservar la APK de la versión 3.22.43 y la copia de seguridad para una posible recuperación supervisada. No bajar de versión sin evaluar compatibilidad de datos.
5. No crear cobros reales de prueba ni emitir recibos a clientes por ensayos. Las pruebas ficticias son en Samsung/Tecno.

## Casos de prueba obligatorios (datos ficticios)

- [ ] Pago 100% QR: total, recibo y Caja en QR, efectivo cero.
- [ ] Pago 100% efectivo: total, recibo y Caja en efectivo, QR cero.
- [ ] Pago mixto por Bs 3.600: QR Bs 2.000 y efectivo Bs 1.600; un solo recibo y un solo pago.
- [ ] Pago mixto con sumas incorrectas, campos vacíos, valores negativos, cero o más de dos decimales: **no debe guardarse**.
- [ ] Cambiar cantidad de cuotas y verificar que el total actualizado se exige también en el desglose.
- [ ] Verificar multas/penalizaciones y gracia en pagos; no duplicar nada.
- [ ] Corregir pago antiguo QR a Mixto con motivo obligatorio; verificar importes, historial y recibo regenerado.
- [ ] Anular un pago mixto: el total no debe contar en Caja.
- [ ] Caja diaria: efectivo + QR = total; un pago mixto cuenta como uno.
- [ ] Cierre de caja manual y automático, incluyendo el aviso previo de 15 minutos.
- [ ] Compartir imagen y PDF del recibo mixto en Samsung Android 9 y Tecno.
- [ ] Exportar Finanzas Excel y CSV y revisar columnas añadidas al final.
- [ ] Reiniciar la app y verificar que el desglose y el historial se conservan.
- [ ] Verificar que los clientes y préstamos anteriores, licencia y respaldos continúen intactos.

**Estado del paquete:** fuentes modificadas y pruebas de lógica/sintaxis superadas; **APK todavía no compilada ni firmada** en este paquete. La versión para uso real solo se considera aprobada después de las pruebas en dispositivos.
