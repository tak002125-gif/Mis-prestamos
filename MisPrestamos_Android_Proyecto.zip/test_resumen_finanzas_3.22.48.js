'use strict';
const assert=require('assert');
const fs=require('fs');
const path=require('path');
const vm=require('vm');
const html=fs.readFileSync(path.join(__dirname,'app/src/main/assets/index.html'),'utf8');
const gradle=fs.readFileSync(path.join(__dirname,'app/build.gradle'),'utf8');
let checks=0;
function ok(v,msg){assert.ok(v,msg);checks++;}
function eq(a,b,msg){assert.strictEqual(a,b,msg);checks++;}
const pure=html.match(/  function projectedBusinessTotal\(capital,expectedProfit,alreadyTransferred\)\{[\s\S]*?\n  \}/);
ok(pure,'Debe existir la fórmula de proyección sin doble conteo');
const projected=vm.runInNewContext('('+pure[0].trim()+')');
[
 [9700,2500,0,12200],
 [10100,2500,400,12200],
 [9700,0,0,9700],
 [10000,1000,1000,10000],
 [10000,1000,2000,10000],
 [5000,120.55,20.12,5100.43],
 [9700,2500,-99,12200],
].forEach(([capital,expected,transferred,result],i)=>eq(projected(capital,expected,transferred),result,'Proyección caso '+i));
[
 'finBusinessCapital','finBalanceDue','finExpected','finProfitPaid','finProjected',
 'financeHistoricalPanel','finLent','finRecover','finCollected','finPending','finHistoryNote',
 'financePeriod','finProjectedDoubleCount'
].forEach(id=>ok(html.includes('id="'+id+'"'),'Falta el campo de resumen '+id));
const business=html.indexOf('id="financeBusinessOverview"');
const manage=html.indexOf('id="capitalManagerCard"');
const historical=html.indexOf('id="financeHistoricalPanel"');
ok(business>=0 && business<manage && manage<historical,'Resumen primero e histórico después de capital');
ok(html.includes('Cuotas aún pendientes'),'Tarjetas principales deben distinguir deuda de actividad');
ok(html.includes('Ganancia total prevista'),'Ganancia futura se etiqueta como proyección');
ok(html.includes('No es dinero disponible hoy'),'No presentar la proyección como saldo en cuenta');
ok(html.includes('Un mismo capital puede prestarse, recuperarse y volver a prestarse'),'Explicar el movimiento histórico');
ok(html.includes('ya agregadas al capital para no contarlas dos veces'),'Explicar el tratamiento de ganancias reinvertidas');
ok(html.includes("$('#stRecover').textContent=money(pending)"),'Estadísticas superiores deben mostrar saldo pendiente');
ok(html.includes("$('#finBalanceDue').textContent=money(allPending)"),'Resumen principal debe usar saldo pendiente global');
ok(html.includes("$('#finExpected').textContent=money(allExpected)"),'Resumen principal debe usar ganancia prevista global');
ok(html.includes("const period=$('#financePeriod')?.value||'all'"),'Histórico separado con selección todo el tiempo');
ok(html.includes("$('#finHistoryNote').textContent=financeOverviewText(period==='all'?'noteAll':'noteMonth')"),'Nota histórica contextual');
ok(html.includes('const allActive=loans.filter(l=>!l.uncollectible);'),'No sumar incobrables a deuda o ganancia proyectada');
ok(/versionCode (125|126|127)/.test(gradle)&&/versionName "3\.22\.(48|49|50)"/.test(gradle),'Versión compatible con 3.22.48, 3.22.49 o 3.22.50');
ok(gradle.includes('applicationId "com.remberto.misprestamos"'),'Mismo paquete Android');
ok(gradle.includes('keyAlias "taca_money"'),'Misma configuración de firma');
for (const lang of ['es:{capital:', 'en:{capital:', "'pt-BR':{capital:"])ok(html.includes(lang),'Idiomas originales conservados');
console.log('OK: '+checks+' verificaciones de presentación de Finanzas y proyección, sin datos reales.');
