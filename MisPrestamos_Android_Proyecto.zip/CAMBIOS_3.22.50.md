# PrestaPro 3.22.50 (versionCode 127)

## Corrección puntual: buscar cliente existente al crear un nuevo préstamo

Problema observado: al escribir «Edison» en **Nuevo préstamo → Cliente existente**, la lista mostraba también clientes sin ese nombre. Al pulsar Enter, el navegador intentaba enviar el formulario y mostraba la validación de campos obligatorios.

### Corrección

- La búsqueda ahora filtra los clientes existentes por **nombre, documento (CI/DNI) o teléfono**, conforme al texto introducido. Se ignora la diferencia entre mayúsculas y minúsculas y entre letras con y sin tilde.
- Se corrige la condición de teléfono: no se compara la cadena vacía cuando el texto no contiene números; esa condición hacía coincidir a todos los clientes.
- El teclado muestra la acción **Buscar** cuando es compatible. Pulsar **Enter** no envía el formulario de préstamo.
- Si el texto introduce una coincidencia única, Enter selecciona esa ficha. Si hay varias, muestra las coincidencias para que el usuario elija una. Si no hay coincidencias, se muestra el aviso existente.
- Ningún cliente se selecciona automáticamente cuando la búsqueda está vacía.

### Alcance y seguridad

Modificación limitada a la interfaz web del buscador de clientes en `app/src/main/assets/index.html` y al incremento de la versión de Android en `app/build.gradle`. Sin cambios de almacenamiento, capital, cálculos, préstamos, cuotas, licencias, respaldos, pagos mixtos, prórrogas ni recordatorios.

- `applicationId`: `com.remberto.misprestamos` (sin cambios)
- `versionCode`: 127, `versionName`: 3.22.50
- Clave/alias de firma de GitHub sin cambios.

### Verificación

- Pruebas automatizadas del buscador con nombres ficticios, mayúsculas, tildes, documentos, teléfonos, ninguna coincidencia y teclado Enter.
- Pruebas de regresión existentes: pagos mixtos, prórrogas, calendario semanal, estadísticas financieras y orden de clientes.
- Pendiente: compilación firmada en GitHub Actions y prueba final en un teléfono Android, previa copia de seguridad.
