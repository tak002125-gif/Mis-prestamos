# Guía de prueba — PrestaPro 3.22.49

1. **Antes de instalar**: efectuar respaldo completo desde PrestaPro a Google Drive. No desinstalar ni borrar datos. Si Android exige desinstalación para actualizar, detenerse y revisar firma/código.
2. Abrir **Finanzas > Resumen > Desglose de ganancias**, con período **Todo el tiempo** y estado **Todos los estados**.
3. Confirmar que arriba aparecen los clientes que todavía tienen un préstamo activo, ordenados por fecha de próxima cuota (primero próximos o vencidos). Los clientes que terminaron todos sus préstamos deben aparecer abajo.
4. Abrir un cliente que pagó un préstamo antiguo pero tiene otro vigente: debe estar arriba, sin perder ninguno de los pagos históricos. Si el nuevo préstamo aún no tiene abonos, el detalle puede explicar que existe un préstamo activo sin cobros en el filtro actual.
5. Si un cliente recibe un préstamo nuevo después de haber terminado otros, debe pasar arriba; cuando pague todas sus deudas, abajo. **No crear préstamos ficticios en el dispositivo con datos reales**: comprobar usando la actividad normal.
6. Verificar que **ganancia cobrada estimada, total cobrado y penalizaciones** coinciden con la versión anterior para el mismo período, y que siguen funcionando la búsqueda, filtros, expandir clientes, exportación CSV y el detalle individual.
7. Comprobar rápidamente que el capital propio, capital disponible, ganancias, caja diaria, recordatorios, pago mixto, prórrogas semanales, licencias y respaldos no muestran cambios inesperados.
8. **Si algún dato cambia o la licencia no se conserva, no introducir nuevos movimientos ni reemplazar respaldos antes de revisar.**
