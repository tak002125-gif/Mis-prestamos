# Pruebas de PrestaPro 3.22.56

1. Instalar encima de 3.22.55 después de respaldar: deben conservarse clientes, préstamos, licencias y cobros.
2. Ajustes → Cláusulas y reglas → Reglas: verificar que los cuatro controles de **Sí/No** se ven completos, incluso en pantallas estrechas. Comprobar la navegación entre las cuatro pestañas.
3. Confirmar que los controles traen las preferencias guardadas. Probar un cambio en una modalidad, guardar y reabrir; comprobar persistencia. Reponer las preferencias originales después de la prueba.
4. No modificar préstamos ni registrar cobros reales para probar la interfaz.
5. Revisar que el texto editable de Cláusulas y la Vista previa se siguen mostrando.
6. Confirmar versión 3.22.56 en Acerca de PrestaPro.
