# PrestaPro 3.22.48 — Código 125

## Única mejora: claridad del resumen financiero

**Base:** 3.22.47 (código 124), validada por el usuario en su Xiaomi con clientes reales.

### Presentación nueva en Finanzas

- Las tarjetas superiores muestran **capital registrado**, **pendiente de cobrar**, **ganancia cobrada estimada** y **ganancia total prevista**. Estos importes son globales, para que un filtro mensual no se mezcle con el capital propio.
- Una tarjeta aparte muestra **Capital + ganancia total proyectada**: se calcula sobre el capital registrado y la ganancia prevista. Si se ha registrado formalmente una incorporación de ganancias al capital, esta parte se descuenta para **evitar contarlas dos veces**.
- Este total es una **proyección** si se cobra lo previsto, no efectivo disponible ni dinero en la cuenta bancaria. La ganancia esperada incluye la ya cobrada: **no hay que sumarla dos veces**.
- La fila de tarjetas superiores de Finanzas usa **Pendiente de cobrar** donde antes decía **Total a recuperar**.
- Más abajo, una sección separada muestra el **movimiento histórico**: capital entregado en préstamos, total de cuotas pactadas, cobros registrados y saldo pendiente. Incluye una explicación de la reutilización del mismo capital.
- El selector **Todo el tiempo / Este mes** afecta las estadísticas históricas, **no** el capital ni la proyección. En «Este mes» se aclara que préstamos originados y cobros recibidos pueden referirse a operaciones diferentes, por lo que no siempre suman.
- Se preservan las funciones de gestión de capital y su historial, la caja diaria, el historial mensual, los reportes y los archivos exportados.

### Ejemplo ilustrativo (no se incorporan datos del cliente al proyecto)

- Capital registrado: Bs 9.700
- Pendiente de cobrar: Bs 4.910
- Ganancia cobrada estimada: Bs 1.681,67
- Ganancia total prevista: Bs 2.500
- Capital + ganancia prevista: **Bs 12.200**
- Total histórico de cuotas: Bs 15.000 (no es una ganancia)

### Seguridad

- No cambia la base de datos, las estructuras de respaldo, el cálculo de cuotas o intereses, la asignación de pagos, penalizaciones, licencias ni alarmas.
- `applicationId` y configuración de firma de producción sin cambios; incremento de `versionCode` a 125.
- La APK de producción debe compilarse y firmarse en GitHub Actions con los secretos previamente configurados. **No instalar primero sobre el Xiaomi sin un respaldo válido y comprobar la nueva pantalla.**

### Verificación

- Sintaxis JavaScript.
- Pruebas Node existentes de pagos mixtos, prórrogas y calendario semanal.
- Nuevas pruebas de fórmula y presentación en `test_resumen_finanzas_3.22.48.js`.
- Prueba de navegador con datos ficticios: cifras, cambio de período y reinversión de ganancias.
- Aún falta comprobar APK firmada y funcionamiento en teléfono físico.
