'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/app/src/main/assets/index.html','utf8');
const java=fs.readFileSync(__dirname+'/app/src/main/java/com/remberto/misprestamos/MainActivity.java','utf8');
const start=html.indexOf('  async function shareReminder(preferWhatsApp)');
const end=html.indexOf('\n',start); const src=html.slice(start,end);
assert(start>=0&&end>start);
const png='data:image/png;base64,AAAA';
async function test(weekly,mode){
 const calls=[], logs=[]; const app={shareToWhatsApp:(...a)=>calls.push(['wa',...a]),shareReceipt:(...a)=>calls.push(['generic',...a]),shareWeeklyReminderToWhatsApp:()=>{throw Error('caption route must not be called')}};
 const c={currentReminder:{loanCode:'P1',dataUrl:png,message:'must not be shared',weeklyDetails:weekly?{}:null},requireCommercialLicense:()=>true,block8Text:x=>x,block6Text:x=>x,todayISO:()=> '2026-11-27',logReminderShare:x=>logs.push(x),toast:()=>{},alert:x=>{throw Error(x)},translateAppText:x=>x,window:{AndroidApp:mode==='web'?null:app},navigator:{share:async a=>calls.push(['web',a])},fetch:async()=>({blob:async()=>({})}),File:class {constructor(parts,name,opts){this.name=name;this.type=opts.type;}}};
 vm.createContext(c);vm.runInContext(src,c);await c.shareReminder(mode==='wa'||mode==='web');
 assert.equal(calls.length,1);assert.equal(logs.length,1);
 if(mode==='web'){assert.equal(calls[0][0],'web');assert(!('text' in calls[0][1]));assert.equal(calls[0][1].files.length,1);}
 else {assert.equal(calls[0][0],mode);assert.equal(calls[0].length,3);assert.equal(calls[0][1],png);}
}
(async()=>{for(const weekly of [true,false])for(const mode of ['wa','generic','web'])await test(weekly,mode);const a=java.indexOf('private void shareTemporaryPng('),b=java.indexOf('public void shareReceipt(',a);assert(a>=0&&b>a);const native=java.slice(a,b);assert(native.includes('Intent.EXTRA_STREAM'));assert(!native.includes('Intent.EXTRA_TEXT'));assert(java.includes('public void shareWeeklyReminderToWhatsApp(String dataUrl, String fileName, String message) {\n            shareTemporaryPng(dataUrl, fileName, "Compartir recordatorio", true);'));console.log('PASS: recordatorios diarios/semanales, WhatsApp/compartir/web, imagen sin texto y puente Android sin caption');})().catch(e=>{console.error(e);process.exit(1)});
