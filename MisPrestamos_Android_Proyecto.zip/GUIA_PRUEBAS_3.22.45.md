# Guía de pruebas — PrestaPro 3.22.45

1. **Samsung de pruebas:** actualizar sin desinstalar; verificar clientes y préstamos existentes.
2. En un cobro mixto ficticio de Bs 3.600, ingresar QR Bs 1.950: efectivo debe completarse con Bs 1.650.
3. Modificar efectivo a Bs 2.000: QR debe actualizarse a Bs 1.600.
4. Borrar y volver a introducir un campo; debe permitir edición sin trabas.
5. Intentar Bs 3.601 en QR, importes con más de dos decimales o uno de los campos en cero: el pago no debe guardarse.
6. Registrar un pago mixto ficticio y verificar un único cobro, saldo correcto, recibo, Finanzas y cierre de caja.
7. En «Corregir pago», probar cálculo automático al modificar QR, efectivo y total, con motivo de corrección.
8. Comprobar compartir recibo como imagen y PDF, aviso de caja de 15 minutos y respaldo con datos ficticios.
9. **Xiaomi con datos reales:** solo después de aprobar Samsung, verificar copia de seguridad reciente, comparar saldos/capital/licencia antes y después, sin crear cobros ficticios. No borrar datos ni desinstalar.

No modificar el préstamo real de Sergio Novoa durante esta prueba.
