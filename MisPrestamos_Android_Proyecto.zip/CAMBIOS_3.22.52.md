# PrestaPro 3.22.52 (versionCode 129)

## Nueva función: recordatorio manual de pago pendiente

- En **Préstamos**, cuando un préstamo activo mantiene cuotas vencidas o una penalidad pendiente después de los dos avisos formales, aparece el botón **Recordar pago pendiente**.
- Al tocarlo se crea una vista previa de imagen para compartir manualmente por WhatsApp u otro medio. El mensaje muestra el saldo pendiente de cuotas, penalidad pendiente cuando corresponda y total. No añade multas ni modifica saldos.
- Se puede usar de nuevo mientras exista la deuda en cobranza activa; cada acción de compartir de seguimiento manual se añade al historial de recordatorios.
- Sigue sin aparecer en préstamos pagados, marcados incobrables o cerrados con garantía.
- **No agrega notificaciones automáticas ni altera los primeros dos avisos formales**: `reminderStageForNotification()` continúa usando exclusivamente `reminderStage()`.
- Soporta préstamos diarios y semanales y tres idiomas (español, inglés, portugués).
- Se conserva íntegro el detector de actualizaciones 3.22.51, buscador 3.22.50, pagos, préstamos, finanzas, licencias y respaldos.

## Instalación

Subir a GitHub reemplazando **solo** `MisPrestamos_Android_Proyecto.zip`. Compilar el APK release firmado e **instalar encima de la 3.22.51** tras realizar respaldo en Google Drive. No desinstalar.

La app anterior 3.22.51 continúa estable hasta comprobar la nueva APK en el dispositivo.
