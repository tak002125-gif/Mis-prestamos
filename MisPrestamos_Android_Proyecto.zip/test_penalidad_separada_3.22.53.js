const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const html=fs.readFileSync(path.join(__dirname,'app/src/main/assets/index.html'),'utf8');
const gradle=fs.readFileSync(path.join(__dirname,'app/build.gradle'),'utf8');
assert(/versionCode\s+(13[1-9]|1[4-9][0-9])/.test(gradle)&&/versionName "3\.22\.(5[4-9]|[6-9][0-9])"/.test(gradle));
function fn(n){const a=html.indexOf(`  function ${n}(`);assert(a>=0,`Falta ${n}`);const next=html.indexOf('\n  function ',a+5);return html.slice(a,next<0?undefined:next);}
const el={
  '#payQty':{value:'8'},'#payAmount':{value:'0'},'#payPenaltyAmount':{value:'0.00',max:'0.00',disabled:false},'#payPenaltyWrap':{style:{}},'#payAllocationPreview':{textContent:''},'#payGraceWaiver':{checked:false},
  '#editPaymentMethod':{value:'QR'},'#editPaymentAmount':{value:'400.00'},'#editPaymentPenaltyAmount':{value:'0.00'},'#editPaymentReason':{value:'Se pagaron 8 cuotas por 400 Bs; la penalización quedó pendiente'},'#editPenaltyWaiver':{checked:false},'#editPaymentAllocationPreview':{textContent:'',style:{}}
};
const registered={id:'Y',amount:1000,total:1200,paid:1050,penaltyPaid:100,penaltyAmountAccrued:100,penaltyCountAccrued:2,installmentAmount:50,installments:24,collectionFrequency:'daily',payments:[
  ...Array.from({length:15},(_,i)=>({paymentId:`p${i}`,receiptNo:`REC-${i}`,amount:50,baseAmount:50,penaltyAmount:0,dateTime:`2026-11-${String(i+1).padStart(2,'0')}T12:00:00Z`,method:'QR'})),
  {paymentId:'p57',receiptNo:'REC-0057',amount:400,baseAmount:300,penaltyAmount:100,method:'QR',dateTime:'2026-11-19T22:01:00Z'},
  {paymentId:'p59',receiptNo:'REC-0059',amount:100,baseAmount:100,penaltyAmount:0,voided:true,method:'QR',dateTime:'2026-11-20T17:23:00Z'}
]};
let saved=0, messages=[],audits=[];
const context={
  loans:[registered],currentPayLoanId:'Y', currentEditPaymentLoanId:'Y', currentEditPaymentId:'p57',meta:{dailyClosings:{}},
  $:(k)=>{assert(el[k],`missing input ${k}`);return el[k]},todayISO:()=> '2026-11-20',
  overdueBeforeToday:()=>5,loanRules:()=>({dailyPenaltyEnabled:true,dailyGraceMisses:2}),
  weeklyPenaltyEligibleFor:()=>false,supportsManualPenaltyGrace:()=>false,
  readPaymentSplitFromForm:()=>({ok:true,qrAmount:400,cashAmount:0}),paymentCents:v=>Math.round(v*100),
  paymentDate:p=>(p.dateTime||'').slice(0,10),
  requireCommercialLicense:()=>true, toast:(s)=>messages.push(s),
  addAudit:(l,type,desc,reason,p)=>audits.push({type,reason}),
  invalidateCashClosingForPayment:()=>{},save:()=>saved++,syncNativeCashAuto:()=>{},closeModal:()=>{},render:()=>{},
  paymentEditModal:{},showReceipt:()=>{},makePaymentReceiptFromPayment:()=>({}),
  nextCollection:()=> '2026-11-21',
  money:n=>'Bs '+n.toFixed(2),paymentMethodDetail:()=> 'QR',
};
const names=['paidInstallments','penaltyAccrued','penaltyWaived','penaltyBalance','baseBalanceRaw','baseBalance','totalDebt','debtBalance','refreshPenalty','activePayments','recomputeLoanPaid','paymentBaseForSelectedQty','updatePayAmount','savePaymentCorrection'];
vm.createContext(context);vm.runInContext(names.map(fn).join('\n'),context);
vm.runInContext('refreshPenalty(loans[0])',context);
assert.equal(registered.penaltyCountAccrued,1,'una sola penalidad');
assert.equal(registered.penaltyAmountAccrued,50,'una sola cuota adicional = 50');
assert.equal(registered.payments.find(p=>p.paymentId==='p57').penaltyAmount,100,'no reescribe recibos automáticamente');
vm.runInContext('updatePayAmount()',context);
assert.equal(el['#payAmount'].value,'150.00','al seleccionar todas las cuotas restantes no se agrega ninguna penalización automática');
vm.runInContext('savePaymentCorrection()',context);
const rec=registered.payments.find(p=>p.paymentId==='p57');
assert.equal(rec.amount,400);assert.equal(rec.baseAmount,400);assert.equal(rec.penaltyAmount,0);
assert.equal(registered.paid,1150);assert.equal(registered.penaltyPaid,0);
assert.equal(registered.penaltyAmountAccrued,50);
assert.equal(registered.total+registered.penaltyAmountAccrued,1250);
assert.equal(registered.total-registered.paid+registered.penaltyAmountAccrued-registered.penaltyPaid,100);
assert.equal(Math.floor(registered.paid/50),23);
assert.equal(registered.payments.find(p=>p.paymentId==='p59').voided,true);
assert.equal(registered.payments.filter(p=>!p.voided).reduce((a,p)=>a+p.amount,0),1150);
assert.equal(saved,1);assert(audits.some(a=>a.type==='payment_corrected'));
// Simulación de pago nuevo: 8 cuotas de Bs 50 no absorben Bs 50 de penalización.
registered.paid=750;registered.penaltyPaid=0;el['#payQty'].value='8';el['#payPenaltyAmount'].value='0.00';
vm.runInContext('updatePayAmount()',context);
assert.equal(el['#payAmount'].value,'400.00','ocho cuotas exactas, sin penalidad automática');
el['#payPenaltyAmount'].value='50.00';vm.runInContext('updatePayAmount()',context);
assert.equal(el['#payAmount'].value,'450.00','el usuario agrega penalización explícita y separada');
assert.equal(registered.penaltyAmountAccrued,50,'no surge una segunda penalización por más días de atraso');

assert(html.includes('id="payPenaltyAmount"'));
assert(html.includes('id="editPaymentPenaltyAmount"'));
assert(!html.includes('const penaltyPayment=Math.min(penaltyDue,amount)'));
console.log('PASS v3.22.53: penalización única, cobro separado, corrección auditada REC-0057 de Bs 400, 23/24 cuotas, saldo 100, anulación intacta');
