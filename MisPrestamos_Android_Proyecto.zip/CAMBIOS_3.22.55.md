# PrestaPro 3.22.55 (versionCode 132) — Configuración independiente de cláusulas y penalizaciones

## Cambios
- Ajustes > Cláusulas y reglas > Reglas: nueva organización en préstamos **diarios**, **semanales** y **garantías**.
- Independientes para préstamos nuevos: activar/desactivar las **cláusulas diarias**, la **penalización diaria**, las **cláusulas semanales** y la **penalización semanal**.
- Conserva el límite de cuotas vencidas antes de la penalización diaria única; al desactivarla, no se generan multas diarias en nuevos préstamos.
- Porcentaje semanal inicial editable entre **0 y 100 %** (por defecto 0 %). El prestamista lo puede modificar al crear cada préstamo semanal, siempre que su política semanal permita multas. Si las multas semanales están desactivadas, el formulario nuevo no ofrece ni aplica ese cobro.
- Las cláusulas específicas siguen siendo editables por texto, y pueden habilitarse individualmente en la pestaña **Cláusulas**. El interruptor general de modalidad no borra textos ni ajustes individuales.
- Cuando el prestamista desactiva todas las condiciones diarias, el formulario no requiere aceptar una cláusula inactiva. Cuando la penalización está activa pero la cláusula está desactivada, el cliente sigue viendo la información necesaria sobre la penalización.
- Las nuevas cotizaciones y los nuevos préstamos guardan una **instantánea de las condiciones elegidas**; los préstamos anteriores conservan sus reglas e historial sin recalcular cuotas, multas, recibos, caja, licencias ni Finanzas.
- Formulario de edición de préstamos previos: conserva el porcentaje semanal ya acordado aunque el ajuste general se haya desactivado para nuevas operaciones.
- VersionCode incrementado de 131 a 132, versionName de 3.22.54 a 3.22.55. Misma aplicación Android `com.remberto.misprestamos` y misma configuración de firma.

## Publicación
Este ZIP es **proyecto fuente** para reemplazar `MisPrestamos_Android_Proyecto.zip` en GitHub. No es la APK. Compilar con el workflow firmado actual. La página Cloudflare sigue pendiente hasta validar esta versión en el Xiaomi.
