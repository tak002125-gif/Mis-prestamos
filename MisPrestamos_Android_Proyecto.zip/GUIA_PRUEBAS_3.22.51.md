# Prueba rápida de PrestaPro 3.22.51

1. Realizar copia en Google Drive de los datos reales y guardar respaldo de seguridad antes de instalar.
2. Instalar APK firmada 3.22.51 encima de 3.22.50 (sin desinstalar). Confirmar conservación de préstamos, cobranzas y licencia.
3. Abrir **Ajustes > Buscar actualizaciones** estando en línea; con `version.json` 3.22.51/código 128 debe mostrar «Ya estás actualizado». Con `version.json` 3.22.50/código 127 no debe pedir actualizar.
4. Con internet desconectado, volver a consultar manualmente; debe mostrar aviso de conexión, sin impedir préstamos ni cobros.
5. Test de aviso real con versión *superior* cuando se publique la siguiente APK: al abrir la app aparece «¡Nueva actualización disponible!»; «Más tarde» la pospone; «Actualizar ahora» abre la descarga HTTPS desde nuestra web.
6. Verificar que la opción de Google Drive, PIN, licencia permanente/anual, buscador y Finanzas sigan funcionando.

Aviso importante: no se puede comprobar la alerta real de versión superior hasta que Cloudflare anuncie una APK firmada de código mayor que 128.
