# PrestaPro 3.22.63 — 27/11/2026

ES: Los recordatorios de pago se comparten solo como imagen, sin repetir su contenido en un texto adjunto de WhatsApp. Se conserva el diseño, los abonos, saldos, prórrogas, penalizaciones, recibos y Finanzas.

EN: Payment reminders are shared as images only, without repeating their content in a WhatsApp caption. Reminder design, partial payments, balances, extensions, late fees, receipts and Finance remain unchanged.

PT-BR: Os lembretes de pagamento são compartilhados apenas como imagem, sem repetir seu conteúdo em uma legenda no WhatsApp. Layout, abonos, saldos, prorrogações, multas, recibos e Finanças permanecem inalterados.
