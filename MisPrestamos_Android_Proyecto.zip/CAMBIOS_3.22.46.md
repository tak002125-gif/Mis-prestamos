# PrestaPro 3.22.46 — Prórroga individual, SOLO semanal

**versionCode:** 123. **Base:** 3.22.45 código 122. **applicationId y firma:** sin cambios.

## Alcance aprobado

- Se agrega «Dar prórroga a una cuota» únicamente a préstamos de **cobro semanal por cuotas**.
- Es posible elegir una cuota pendiente, indicar una nueva fecha y un motivo obligatorio.
- Se conserva `scheduleDates` con todos los vencimientos originales. La autorización se guarda por índice de cuota y fecha original en `weeklyGraceDates`, y se registra en `auditTrail` con fecha y motivo.
- **Solo la cuota elegida** usa la nueva fecha para determinar vencimiento, atraso, penalización, recordatorio, aviso nativo y calificación de cumplimiento.
- Las cuotas siguientes mantienen sus fechas. Para evitar superposiciones, no se permite extender una cuota hasta la fecha de la siguiente o después.
- No aumenta el capital, intereses, cuota, saldo ni número de cuotas por la simple concesión.
- Si la cuota ya tiene penalización activa generada, la prórroga no la borra retroactivamente: se informa al usuario que debe revisar la corrección/condonación correspondiente.
- Si un préstamo con prórrogas registradas se edita, se impide cambiar su calendario para preservar la identidad de las fechas.
- Los datos de préstamos anteriores no se migran ni se reescriben; el nuevo campo está vacío por defecto y es compatible con respaldos JSON.

## Fuera de alcance: importante

- **NO se implementan prórrogas en préstamos diarios.** Sus reglas de atrasos, penalizaciones y cobranza permanecen iguales.
- La opción de pago semanal único conserva su comportamiento anterior; esta mejora está pensada para cuotas semanales separadas.
- No se cambia el sistema de pagos QR/efectivo/mixto, Caja diaria, cierre automático, notificación de cierre de 15 minutos, licencias, Google Drive ni la firma.
- Ningún préstamo real, incluidos préstamos existentes, recibe una prórroga automática. La autorización es manual y explícita.

## Validación

- Sintaxis de JS comprobada.
- Pruebas de lógica sin datos personales: prórroga primera cuota de 04/11/2026 a 06/11/2026; segundo y tercer vencimientos inalterados; sin penalizar ni recordar el 05/11; vencimiento el 06/11; penalización semanal únicamente después; segunda cuota independiente; bloqueo de prórrogas que invaden la siguiente cuota; rechazo de condonación retroactiva.
- Pruebas anteriores de pagos mixtos y autocompletado conservadas y ejecutadas.
- **No se ha instalado ni probado en Android físico todavía.** Compilar en GitHub Actions con la firma original. Probar primero en Samsung con préstamo ficticio; respaldar Xiaomi antes de cualquier instalación.
