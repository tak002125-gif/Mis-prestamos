# PrestaPro 3.22.51 (versionCode 128)

## Nueva función: detección de actualizaciones

- El aplicativo externo consulta `https://prestapro.tacaapps.app/version.json` cuando se abre o vuelve a primer plano (máximo una comprobación exitosa automática cada dos horas).
- Solo informa sobre una versión disponible si el `versionCode` remoto es **mayor** que el de la APK instalada. Si la web está en 3.22.50 (código 127) y la app en 3.22.51 (código 128), **no** se muestra un aviso falso.
- Al detectar una versión posterior, muestra un cuadro con versión, notas de actualización y botones **Más tarde / Actualizar ahora**. Si el usuario lo pospone, no lo repite automáticamente para el mismo código; sí avisa al publicarse una versión aún más nueva.
- Se añade **Ajustes > Buscar actualizaciones**, con estado manual en línea y un indicador discreto mientras haya una versión pendiente.
- **Actualizar ahora** abre la URL de APK en el navegador, sin descarga o instalación silenciosa. Solo admite HTTPS en `prestapro.tacaapps.app` y ruta `/PrestaPro.apk`.
- Sin internet la aplicación sigue operando normalmente. La comprobación no solicita permisos especiales ni cuentas de Google; no toca préstamos, cobranzas, copias de seguridad ni licencias.
- Las instalaciones desde Google Play se mantienen separadas: no se sugieren APK externas desde esta vía.
- Interfaz para los avisos disponible en español, inglés y portugués.

## Compatibilidad

- Mismo `applicationId`: `com.remberto.misprestamos`.
- Se mantiene la configuración de firma `taca_money` y todas las clases de datos y funcionalidad de la 3.22.50.
- Únicos cambios funcionales: clase nueva `PrestaProUpdateChecker.java`, dos métodos seguros del puente Android y un modal/pestaña de comprobación en `assets/index.html`.
- La actualización debe instalarse **encima** de la anterior, sin desinstalar; se recomienda un respaldo primero.

## Publicación necesaria

1. Subir el ZIP de fuente `MisPrestamos_Android_Proyecto.zip` a GitHub y obtener su **APK de release firmada**.
2. Publicar en Cloudflare **esa misma APK firmada** como `PrestaPro.apk`.
3. Al mismo tiempo, publicar `version.json` con `app: PrestaPro`, `versionName: 3.22.51`, `versionCode: 128`, `downloadUrl: https://prestapro.tacaapps.app/PrestaPro.apk?v=3.22.51`, `releaseNotes`, y `mandatory: false`.
4. En el futuro, cada nueva APK debe publicarse junto a su `version.json` actualizado. Nunca anunciar una versión si la APK real descargable es anterior.
5. Los usuarios que actualmente tienen 3.22.50 deberán actualizar **una vez manualmente** a 3.22.51. La 3.22.50 no contiene este detector y por tanto no mostrará el aviso por sí sola.

## Pruebas

`node test_actualizaciones_3.22.51.js` valida aviso nuevo, versiones iguales, posponer, consulta manual, URL segura, mensajes sin conexión y traducciones. También ejecutar todos los tests históricos.

**Pendiente de comprobación real:** compilación firmada de GitHub e instalación en Xiaomi; esta entrega contiene fuentes, no la APK firmada final.
