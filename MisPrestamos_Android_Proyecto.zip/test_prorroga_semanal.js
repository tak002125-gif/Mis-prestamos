// PrestaPro 3.22.46 — pruebas sin clientes ni datos reales
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/app/src/main/assets/index.html','utf8');
const between=(start,end)=>{const i=html.indexOf(start),j=html.indexOf(end,i+start.length);assert(i>=0&&j>i,start);return html.slice(i,j)};
const code=[
  between('  function supportsManualPenaltyGrace(l){','  function grantManualGrace(l,until,reason='),
  between('  function dueInstallments(l){','  function collateralGraceDays(l){'),
  between('  function refreshPenalty(l){','  function refreshAllPenalties(){'),
  between('  function hasTodayInstallmentDue(l){','  function hasPendingPreviousAndToday(l){'),
  between('  function statusOf(l){','  function isOverdueLoan(l){'),
  between('  function nextCollection(l){','  function isDueTodayLoan(l){'),
  between('  function loanInstallmentCompliance(l){','  function clientCompliance(l){'),
  between('  function weeklyGraceOptions(l){','  function openUncollectibleModal(loanId){')
].join('\n');
const fields={};for(const id of ['weeklyGraceInstallment','weeklyGraceUntil','weeklyGraceReason','weeklyGraceDatePreview','weeklyGraceSummary'])fields['#'+id]={value:'',min:'',max:'',textContent:'',innerHTML:'',removeAttribute(k){delete this[k];}};
const $=selector=>{if(!fields[selector])throw Error('missing field '+selector);return fields[selector]};
const l={id:'test',client:'Cliente ficticio',loanCode:'TEST-1',collectionFrequency:'weekly',weeklyPaymentMode:'installments',termWeeks:3,installments:3,startDate:'2026-10-28',scheduleDates:['2026-11-04','2026-11-11','2026-11-18'],dueDate:'2026-11-18',total:1200,installmentAmount:400,weeklyPenaltyPercent:10,weeklyPenaltyTermsAccepted:true,weeklyPenaltyEffectiveFrom:'2026-10-28',weeklyPenaltyEvents:[],paid:0,payments:[],penaltyCountAccrued:0,penaltyAmountAccrued:0,penaltyPaid:0,weeklyGraceDates:[],auditTrail:[],uncollectible:false,closedWithCollateral:false};
let saved=0,rendered=0,notified=0;
const env={
  now:'2026-11-04',loans:[l],console,$,currentWeeklyGraceLoanId:'test',
  todayISO(){return this.now},
  effectiveScheduleDates:x=>x.scheduleDates,
  nextCollectionBusinessDate:(x,s)=>s,
  isoAddDays:(iso,days)=>{const d=new Date(iso+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+days);return d.toISOString().slice(0,10)},
  paidInstallments:x=>Math.floor((x.paid+0.005)/x.installmentAmount),
  loanRules:()=>({dailyPenaltyEnabled:true,dailyGraceMisses:2}),
  weeklyPenaltyEligibleFor:(freq,mode,weeks,hasCol)=>freq==='weekly'&&mode==='installments'&&!hasCol,
  weeklyScheduledAmount:()=>400,
  paymentBaseThroughDate:(x,day)=>x.payments.filter(p=>p.date<=day&&!p.voided).reduce((a,p)=>a+(p.baseAmount||p.amount),0),
  baseBalance:x=>Math.max(0,x.total-x.paid),baseBalanceRaw:x=>Math.max(0,x.total-x.paid),
  penaltyBalance:x=>Math.max(0,x.penaltyAmountAccrued-x.penaltyPaid),
  debtBalance:x=>Math.max(0,x.total-x.paid+x.penaltyAmountAccrued-x.penaltyPaid),
  weeklyGuaranteeDefault:()=>false,
  isGlobalNonWorkingDate:()=>false,isDailyCollectionDay:()=>true,
  activePayments:x=>x.payments.filter(p=>!p.voided),paymentDate:p=>p.date,
  daysBetweenISO:(a,b)=>Math.round((new Date(b+'T12:00:00Z')-new Date(a+'T12:00:00Z'))/86400000),
  money:n=>'Bs '+Number(n).toFixed(2),dateLabel:x=>x,esc:x=>String(x),
  requireCommercialLicense:()=>true,confirm:()=>true,alert:x=>{env.lastAlert=x},
  addAudit:(x,type,detail,reason)=>x.auditTrail.push({type,detail,reason}),
  save:()=>saved++,syncNativeAlerts:()=>notified++,render:()=>rendered++,closeModal:()=>{},weeklyGraceModal:{},toast:()=>{}
};
// Don't use `this` in date callback because VM calls standalone identifiers.
env.todayISO=()=>env.now;
vm.createContext(env);vm.runInContext(code,env,{filename:'grace-functions'});
let count=0;const eq=(a,b,label)=>{assert.strictEqual(a,b,label);count++};
eq(env.effectiveDueDate(l,l.scheduleDates[0]),'2026-11-04','before');
eq(env.dueInstallments(l),1,'due before');
eq(env.overdueBeforeToday(l),0,'not late on due');
// A verified grant only updates installment 1. All originals remain untouched.
fields['#weeklyGraceInstallment'].value='0';fields['#weeklyGraceUntil'].value='2026-11-06';fields['#weeklyGraceReason'].value='Acuerdo del prestamista';
env.saveWeeklyGrace({preventDefault(){}});
eq(l.scheduleDates.join(','),'2026-11-04,2026-11-11,2026-11-18','original dates');
eq(l.weeklyGraceDates.length,1,'one extension');
eq(l.weeklyGraceDates[0].installmentIndex,0,'specific installment');
eq(env.effectiveDueDate(l,l.scheduleDates[0]),'2026-11-06','extended due');
eq(env.effectiveDueDate(l,l.scheduleDates[1]),'2026-11-11','second intact');
eq(env.effectiveDueDate(l,l.scheduleDates[2]),'2026-11-18','third intact');
eq(env.effectiveInstallmentDates(l).join(','),'2026-11-06,2026-11-11,2026-11-18','effective dates');
eq(saved,1,'save after grant');eq(notified,1,'notify after grant');eq(rendered,1,'render after grant');
eq(l.auditTrail[0].type,'weekly_installment_grace','audit');
// Nov 5: no late, no penalty and no reminder expected for first installment.
env.now='2026-11-05';eq(env.dueInstallments(l),0,'not yet due');eq(env.overdueBeforeToday(l),0,'not overdue');eq(env.statusOf(l),'active','status clean');eq(env.refreshPenalty(l),false,'no penalty');eq(l.weeklyPenaltyEvents.length,0,'no penalty event');eq(env.hasTodayInstallmentDue(l),false,'no reminder today');
// Friday is due date; Saturday is overdue and penalty can then apply (according to weekly rules).
env.now='2026-11-06';eq(env.hasTodayInstallmentDue(l),true,'friday due');eq(env.overdueBeforeToday(l),0,'no late friday');
env.now='2026-11-07';eq(env.overdueBeforeToday(l),1,'late saturday');eq(env.refreshPenalty(l),true,'weekly penalty after grace');eq(l.weeklyPenaltyEvents.length,1,'one penalty');eq(l.weeklyPenaltyEvents[0].dueDate,'2026-11-04','event keyed to original');eq(l.weeklyPenaltyEvents[0].amount,40,'penalty amount');
// Second installment can have independent grace, third stays fixed.
const l2={...l,id:'test2',scheduleDates:[...l.scheduleDates],weeklyGraceDates:[...l.weeklyGraceDates],weeklyPenaltyEvents:[],paid:400,payments:[{date:'2026-11-06',amount:400}],auditTrail:[]};env.loans.push(l2);env.currentWeeklyGraceLoanId='test2';env.now='2026-11-11';
fields['#weeklyGraceInstallment'].value='1';fields['#weeklyGraceUntil'].value='2026-11-13';fields['#weeklyGraceReason'].value='Prórroga por dos días';env.saveWeeklyGrace({preventDefault(){}});
eq(l2.weeklyGraceDates.length,2,'two independent grants');eq(env.effectiveDueDate(l2,l2.scheduleDates[1]),'2026-11-13','second moved');eq(env.effectiveDueDate(l2,l2.scheduleDates[2]),'2026-11-18','third unmoved');
// Daily loan does not inherit weekly overrides and its due logic remains unchanged.
const daily={...l2,collectionFrequency:'daily',weeklyPaymentMode:'',scheduleDates:['2026-11-04','2026-11-05','2026-11-06'],installments:3,paid:0,penaltyCountAccrued:0,penaltyAmountAccrued:0,penaltyPaid:0};
env.now='2026-11-05';eq(env.supportsWeeklyInstallmentGrace(daily),false,'daily unsupported');eq(env.effectiveDueDate(daily,'2026-11-04'),'2026-11-04','daily date unmodified');eq(env.effectiveInstallmentDates(daily).join(','),'2026-11-04,2026-11-05,2026-11-06','daily schedule');
// Refuse a grace request which reaches the next original installment.
env.currentWeeklyGraceLoanId='test2';fields['#weeklyGraceInstallment'].value='1';fields['#weeklyGraceUntil'].value='2026-11-18';fields['#weeklyGraceReason'].value='Invalid extension';let before=l2.auditTrail.length;env.saveWeeklyGrace({preventDefault(){}});eq(l2.auditTrail.length,before,'cannot shift next installment');
// Refuse retroactive replacement of an accrued penalty.
const l3={...l,id:'test3',weeklyGraceDates:[],weeklyPenaltyEvents:[{dueDate:'2026-11-04',amount:40,waivedAmount:0}],paid:0,payments:[]};env.loans.push(l3);env.currentWeeklyGraceLoanId='test3';env.now='2026-11-06';fields['#weeklyGraceInstallment'].value='0';fields['#weeklyGraceUntil'].value='2026-11-08';fields['#weeklyGraceReason'].value='Retroactivo';env.lastAlert='';env.saveWeeklyGrace({preventDefault(){}});eq(l3.weeklyGraceDates.length,0,'no retroactive change');assert(env.lastAlert.includes('penalización'));count++;
console.log(`OK: ${count} verificaciones sin datos reales: cuotas individuales, días, penalidad, recordatorios, historial, cobro diario, seguridad.`);
