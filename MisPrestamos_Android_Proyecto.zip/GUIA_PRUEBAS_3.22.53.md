# Pruebas recomendadas — PrestaPro 3.22.53

**Antes de usar con datos reales:** crear respaldo verificado en Google Drive y, si es posible, respaldo manual adicional. No desinstalar PrestaPro.

1. Confirmar «Acerca de PrestaPro» = v3.22.53. Confirmar todos los préstamos y pagos previos.
2. En un préstamo de prueba diario con cuota Bs 50, tras más de dos cuotas vencidas confirmar penalización **única Bs 50**, sin aumentar a Bs 100 por continuar atrasado.
3. Entrar en **Cobrar**: seleccionar 8 cuotas → Total Bs 400 y penalización a cobrar Bs 0 por defecto. Si se escribe 50 en penalización, debe mostrar cuota Bs 400 + multa Bs 50 = total Bs 450.
4. En un cobro real que fue previamente mal distribuido, entrar al recibo ORIGINAL → Corregir, mantener su monto y método reales, cambiar solo la penalización cobrada y escribir el motivo. La distribución no se corrige automáticamente por instalar la APK.
5. Verificar que el recibo y Finanzas muestran importe total recibido sin duplicaciones, cuotas y penalización separadas; que la caja/cierre del día se recalculan si el sistema avisa.
6. Comprobar que un recibo anulado permanece **ANULADO**, y que el historial sigue completo.
7. Verificar que Mi licencia, respaldos, recordatorios manuales, calendarios, buscador y detección de actualizaciones siguen funcionando.

## Corrección ilustrativa del recibo REC-0057

- Antes de hacer cambios, verificar en tu respaldo/capturas que el cobro original de Bs 400 corresponde realmente a ocho cuotas, y que la multa Bs 50 no fue cobrada.
- En **REC-0057 → Corregir** conservar **QR** y **Monto correcto Bs 400**, fijar **De ese monto, penalización realmente pagada = Bs 0**, indicar «Los Bs 400 correspondieron a 8 cuotas; multa de Bs 50 pendiente» y guardar.
- Esperado: **23/24 cuotas**, Bs 1.150 cobrados en total, Bs 50 de cuota pendientes, Bs 50 de penalización pendientes, **saldo Bs 100**. El **REC-0059** ya anulado debe seguir anulado.
- Nunca registrar Bs 100 adicionales si no se recibió ese dinero.

Los datos ficticios del test automatizado no modifican el teléfono. La corrección de los registros reales debe confirmarla el usuario desde la propia aplicación.
