// Pruebas sin datos privados para PrestaPro 3.22.44. Requiere Node.js.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/app/src/main/assets/index.html','utf8');
function between(start,end){const i=html.indexOf(start),j=html.indexOf(end,i+start.length);assert(i>=0&&j>i,start);return html.slice(i,j)}
const testsCode=between('  // v3.22.44: centavos enteros','  function computeCashDay(date){')+
  between('  function computeCashDay(date){','  function cashPaymentTime(p){')+
  between('  function cashPaymentTime(p){','  function computeCashDayUntil(date,untilInclusive){');
const sandbox={console,loans:[],money:n=>'Bs '+Number(n).toFixed(2),
 paymentDate:p=>p.date, effectiveScheduleDates:()=>[],effectiveInstallmentDates:()=>[],statusOf:()=>'',activePayments:l=>l.payments.filter(p=>!p.voided&&!p.cashExcluded)};
vm.createContext(sandbox);vm.runInContext(testsCode,sandbox);
const valid=sandbox.validatePaymentSplit('Mixto',3600,'2000.00','1600.00');
assert.strictEqual(valid.ok,true);
assert.strictEqual(valid.qrAmount,2000);
assert.strictEqual(valid.cashAmount,1600);
assert.strictEqual(sandbox.validatePaymentSplit('Mixto',3600,'2000','1599.99').ok,false);
assert.strictEqual(sandbox.validatePaymentSplit('Mixto',3600,'2000','1600.001').ok,false);
assert.strictEqual(sandbox.validatePaymentSplit('Mixto',3600,'2000','').ok,false);
assert.strictEqual(sandbox.validatePaymentSplit('Mixto',3600,'3600','0').ok,false);
assert.strictEqual(sandbox.validatePaymentSplit('QR',3600,'','').qrAmount,3600);
assert.strictEqual(sandbox.validatePaymentSplit('Efectivo',3600,'','').cashAmount,3600);
assert.strictEqual(sandbox.paymentCents('0.019'),null);
assert.strictEqual(sandbox.paymentCents('300.25'),30025);
const date='2026-11-04';
const payments=[
 {paymentId:'legacyCash',date,dateTime:'2026-11-04T12:00:00Z',method:'Efectivo',amount:200,voided:false},
 {paymentId:'legacyQR',date,dateTime:'2026-11-04T12:05:00Z',method:'QR',amount:500,voided:false},
 {paymentId:'mixed',date,dateTime:'2026-11-04T12:10:00Z',method:'Mixto',amount:3600,qrAmount:2000,cashAmount:1600,voided:false},
 {paymentId:'void',date,dateTime:'2026-11-04T12:15:00Z',method:'QR',amount:1000,voided:true},
 {paymentId:'excluded',date,dateTime:'2026-11-04T12:18:00Z',method:'Efectivo',amount:100,cashExcluded:true}
];
sandbox.loans=[{id:1,payments,uncollectible:false,closedWithCollateral:false}];
const today=sandbox.computeCashDay(date);assert.strictEqual(today.cash,1800);assert.strictEqual(today.qr,2500);
assert.strictEqual(today.total,4300);assert.strictEqual(today.cash+today.qr,today.total);assert.strictEqual(today.payments,3);
const window=sandbox.computeCashDayWindow(date,'2026-11-04T12:05:00Z','2026-11-04T12:10:00Z');
assert.strictEqual(window.cash,1600);assert.strictEqual(window.qr,2000);assert.strictEqual(window.total,3600);
assert.strictEqual(sandbox.paymentMethodDetail(payments[2]).includes('QR Bs 2000.00'),true);
assert(sandbox.paymentMethodReceiptRows(payments[2]).includes('Recibido por QR'));
const corrected={...payments[1],method:'Mixto',amount:500,cashAmount:150,qrAmount:350};
assert.strictEqual(sandbox.paymentSplit(corrected).cash,150);
assert.strictEqual(sandbox.paymentSplit(corrected).qr,350);
// Los pagos históricos de QR o efectivo continúan funcionando sin campos de desglose.
assert.strictEqual(sandbox.paymentSplit(payments[0]).cash,200);
assert.strictEqual(sandbox.paymentSplit(payments[1]).qr,500);
console.log('OK: 18 verificaciones sobre split, validación, historial y caja diaria.');
