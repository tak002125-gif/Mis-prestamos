# Guía de pruebas — PrestaPro 3.22.46

**Primero Samsung S9 Plus**, con clientes ficticios. Nunca crear movimientos de prueba en el Xiaomi que guarda clientes reales.

1. Actualiza la versión 3.22.45 a 3.22.46 usando la misma firma. No desinstales.
2. Confirma que clientes, préstamos, pagos y licencias se conservaron.
3. En un préstamo semanal por cuotas ficticio (3 cuotas, Bs 400, vencen los miércoles), abre «Ver detalles y opciones» > «Dar prórroga a una cuota».
4. Elige cuota 1, vencimiento original miércoles 04/11/2026; registra viernes 06/11/2026 y motivo obligatorio.
5. Comprueba que el vencimiento de cuota 1 sea el viernes 06/11, pero los vencimientos de cuota 2 y cuota 3 sigan miércoles 11 y miércoles 18.
6. Durante el plazo autorizado, comprueba que no se muestre atraso prematuro ni se genere penalización o recordatorio de vencido para esa cuota.
7. Prueba prorrogar de manera independiente la cuota 2. La fecha de cuota 3 no debe cambiar.
8. Confirma que el historial muestre cuándo y por qué se autorizó la prórroga.
9. Prueba intentar elegir una fecha que alcance a la cuota siguiente; la app debe impedirlo.
10. Comprueba que diario **no** muestra la opción y conserva sus reglas originales (primeros atrasos y penalización desde el momento acordado).
11. Revisa recibos, pago mixto, Finanzas, Caja diaria, cierre automático, aviso 15 min y respaldo.
12. Tras las pruebas en Samsung y respaldo reciente y verificable de Google Drive, considerar actualización de Xiaomi. No restaurar ni borrar datos durante la prueba.

**Caso importante:** Si ya se generó una penalización semanal de la cuota seleccionada, no se elimina automáticamente. Primero revisar el historial y las correcciones pertinentes.
