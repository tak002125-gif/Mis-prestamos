# PrestaPro 3.22.54 — versionCode 131

## Nueva función: condonar penalización pendiente (préstamos diarios)

- Dentro de **Préstamos → Ver detalles y opciones** aparece **«Condonar penalización»** únicamente cuando un préstamo diario conserva una multa pendiente de cobro. No aparece en un préstamo incobrable ni cerrado mediante garantía.
- La ventana muestra el cliente, el préstamo, las cuotas pagadas, el monto exacto a perdonar y el saldo antes/después. Exige motivo por escrito y una confirmación final.
- La condonación se guarda como **decisión administrativa**, separada del dinero recibido: crea un registro de auditoría con fecha, monto y motivo, pero no crea un pago ni un recibo falso y no altera caja, capital ni el total de cuotas efectivamente pagadas.
- La multa se conserva como **penalización originalmente aplicada**, con el importe **condonado** separado. El saldo pendiente resta la parte perdonada y el detalle del préstamo muestra la constancia.
- Cuando todas las cuotas normales están pagadas, condonar la última multa deja saldo Bs 0 y permite marcar el préstamo como **finalizado** por su cálculo habitual. No elimina el historial de atrasos.
- La condonación persiste en los datos y respaldos porque está almacenada junto al préstamo.
- **Ámbito deliberado:** esta nueva función cubre penalizaciones de préstamos diarios. Las reglas semanales y su gracia manual existente permanecen intactas.

## Regresión con datos ficticios equivalentes

- Total pactado Bs 1.200, 24 cuotas de Bs 50, dinero recibido Bs 1.200, multa única pendiente Bs 50.
- Antes: 24/24 cuotas, saldo Bs 50, etiqueta «Con retraso».
- Después de condonar Bs 50 con motivo «Excepción por robo del celular»: 24/24 cuotas, dinero recibido Bs 1.200, multa condonada Bs 50, multa pendiente Bs 0, saldo Bs 0, préstamo finalizado.
- No se crea cobro en caja, no aumenta ganancias cobradas, no se reescriben recibos y no permite condonar dos veces la misma multa.
- Si quedan cuotas por pagar, la condonación perdona solo la multa y no cierra anticipadamente el préstamo.

## Instalación

Subir el ZIP con el **nombre exacto** `MisPrestamos_Android_Proyecto.zip` sustituyendo el archivo anterior en GitHub. Compilar release firmada. Crear respaldo de Google Drive antes de instalar encima de 3.22.53 y **no desinstalar** la aplicación con datos reales.
