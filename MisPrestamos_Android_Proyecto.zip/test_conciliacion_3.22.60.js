  function reconcileAmounts(available,profit,penalties,bank,cash){
    const cents=n=>Math.round(n*100),total=cents(available)+cents(profit)+cents(penalties);
    const valid=n=>n!==null&&Number.isFinite(n)&&n>=0;
    const b=valid(bank)?cents(bank):null,c=valid(cash)?cents(cash):null;
    return {total:total/100,expected:b===null?null:(total-b)/100,actual:b===null||c===null?null:(b+c)/100,diff:b===null||c===null?null:(b+c-total)/100};
  }

const assert=require('assert');assert.deepStrictEqual(reconcileAmounts(1579.17,2855.83,0,4285,150),{total:4435,expected:150,actual:4435,diff:0});assert.equal(reconcileAmounts(2079.17,2355.83,0,4285,150).total,4435);assert.equal(reconcileAmounts(1579.17,2855.83,20,4285,170).diff,0);assert.equal(reconcileAmounts(1579.17,2855.83,0,4285,null).diff,null);assert.equal(reconcileAmounts(1579.17,2855.83,0,4500,0).expected,-65);console.log('OK conciliación');