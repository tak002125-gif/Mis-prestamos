# Pruebas PrestaPro 3.22.52

1. Respaldar Google Drive; actualizar encima de 3.22.51 con la misma firma y comprobar préstamos/clientes/licencias intactos.
2. En un préstamo de PRUEBA diario con 3 o más cuotas vencidas, verificar el botón **Recordar pago pendiente** incluso si hay penalidad activa.
3. Abrir vista previa y comprobar cliente, saldo de cuotas, penalidad pendiente cuando exista y total; compartir por WhatsApp manualmente. Comprobar registro en historial.
4. Repetir el envío manual (deben constar dos acciones, no sobrescribirse) y comprobar que no cambia el saldo ni aumenta la penalidad por compartir.
5. Probar préstamo semanal vencido y penalidad cuando corresponda.
6. Comprobar que siguen los avisos formales primero/segundo y aviso normal y que NO se programa una notificación automática de seguimiento.
7. Comprobar que el botón no aparece en préstamo pagado, incobrable ni cerrado con garantía, y desaparece al saldar la deuda.
8. Comprobar Finanzas, cobranzas, recordatorios, búsqueda de clientes, licencias y Ajustes > Buscar actualizaciones.

Para no poner en riesgo los préstamos reales, realizar las pruebas con clientes ficticios en un teléfono secundario o sobre copia de seguridad.
