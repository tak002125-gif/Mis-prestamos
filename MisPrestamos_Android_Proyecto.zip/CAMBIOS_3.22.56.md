# PrestaPro 3.22.56 (versionCode 133) — Mejoras visuales en Cláusulas y reglas

- Los 4 interruptores de cláusulas y penalizaciones diarias/semanales se muestran ahora como botones de selección nativos **Sí / No**, amplios, accesibles y visibles sin recortes.
- Etiqueta y explicación permanecen encima del control. Los campos numéricos usan todo el ancho disponible.
- Las pestañas tienen mayor separación y permiten ajustar el texto sin superposiciones; en pantallas muy estrechas se organizan en dos filas.
- Los valores que se guardan en `meta.rules` no cambian: las preferencias existentes se recuperan, se muestran, se pueden modificar y se guardan igual que antes.
- No se modificaron el cálculo de intereses, cuotas, penalizaciones, condonaciones, cobros, históricos, licencias ni el mecanismo de actualizaciones.
- Versión 3.22.56, código 133, aplicación `com.remberto.misprestamos`.
