# Pruebas de aceptación — PrestaPro 3.22.55

1. Antes de actualizar PrestaPro en un teléfono con datos reales, crear respaldo en Google Drive. Instalar encima sin desinstalar.
2. Ajustes > Cláusulas y reglas > Reglas: verificar 4 opciones independientes (cláusulas diarias, multa diaria, cláusulas semanales, multa semanal), además de días de tolerancia, porcentaje semanal inicial y garantías.
3. Configuración de usuario sin cláusulas ni multas: poner las cuatro en **No**, guardar, crear préstamo diario y semanal ficticios: no debe requerir aceptar una cláusula diaria desactivada, ni generar penalidad diaria ni mostrar multa semanal. Revisar sus documentos y cronogramas.
4. Configuración diaria propia: activar cláusulas diarias, desactivar multa diaria, editar texto de la cláusula y guardar. Nuevo préstamo diario: texto apropiado y 0 multas aunque se atrase. Si el texto predeterminado mencionaba multas, debe mostrarse la variante sin multa.
5. Configuración semanal propia: activar multas semanales y porcentaje inicial 12,5 %; al crear préstamo semanal sin garantía se preselecciona el porcentaje y se solicita aceptación de multa. Se puede cambiar ese porcentaje en el préstamo. Desactivar de nuevo y repetir: no debe aplicar penalidad.
6. Comprobar que textos individuales guardados siguen existiendo tras apagar y volver a encender la modalidad.
7. Verificar la persistencia de todas las opciones tras cerrar y abrir la aplicación.
8. Verificar que préstamos anteriores mantienen cuotas, recibos, porcentaje de penalización y cláusulas que tenían cuando se crearon. Revisar particularmente Yessica PRE-2026-0010: finalizado, Bs 1.200 realmente cobrados, Bs 50 condonados y saldo 0, sin nuevo ingreso ficticio.
9. Revisar Finanzas, cobros por QR/efectivo, búsquedas, recordatorios, licencia y Ajustes > Buscar actualizaciones.
10. Probar las opciones en español; si hay usuarios en inglés o portugués, verificar también sus textos y términos.

Solo entregar al público después de la compilación firmada de GitHub y prueba funcional en teléfono.
