# 3.22.59 — 26/11/2026
ES: Permite condonar penalizaciones pendientes de préstamos semanales sin alterar cuotas, abonos ni caja. Registra motivo e historial.
EN: Waive outstanding weekly loan penalties without changing installments, partial payments or cash records. Records reason and history.
PT-BR: Perdoe multas pendentes de empréstimos semanais sem alterar parcelas, pagamentos parciais ou caixa. Registra motivo e histórico.
