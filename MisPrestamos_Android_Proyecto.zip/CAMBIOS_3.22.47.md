# PrestaPro 3.22.47 — Calendario visible de pagos semanales

**versionCode:** 124. **Base:** 3.22.46 código 123. **applicationId, firma y permisos:** sin cambios.

## Únicas mejoras de esta versión

1. Dentro de **Préstamos → Ver detalles y opciones**, los préstamos de **frecuencia semanal** muestran una tarjeta de solo lectura con cada cuota/pago programado, la fecha original, el importe y su estado. Si se concedió prórroga semanal, aparece además la nueva fecha autorizada y se mantiene visible la original.
2. El **recibo de entrega del préstamo semanal** muestra el calendario ORIGINAL de fechas e importes para que el cliente conozca cuándo debe pagar. Se aplica tanto a la vista previa como a las imágenes compartidas, archivos PDF y su impresión normal, ya que utilizan el generador del mismo comprobante.
3. Funciona con **1, 2, 3, 4 o más cuotas semanales existentes**, y reconoce la modalidad semanal de pago único cuando corresponde, sin inventar cuotas.

## Seguridad y compatibilidad

- Los préstamos **diarios** quedan intactos: no se muestra calendario semanal y no se modifica su cobro, atrasos ni penalización.
- Las **cotizaciones** quedan intactas; el calendario nuevo se añade únicamente al recibo de entrega de un préstamo real.
- El calendario del recibo se basa en `scheduleDates` del préstamo y **no incorpora cambios posteriores por prórroga**. El detalle sí muestra la prórroga al lado de su vencimiento original.
- No se cambia el valor de `scheduleDates`, la cantidad de cuotas, fechas, pago, balance, capital, interés, multa, prórroga, licencia ni respaldos.
- Solo se modifican la interfaz en `app/src/main/assets/index.html` y `versionCode`/`versionName` en `app/build.gradle`; los demás archivos fuente Android quedan idénticos.
- No se han tocado las reglas de cierre de caja, sus notificaciones, pagos QR/efectivo/mixto, ni Google Drive.

## Pruebas

- Sintaxis JavaScript comprobada con Node.js.
- 40 comprobaciones nuevas de detalle, recibo, fechas, prórroga, cuota única, cotización, diario y redondeo; sin usar datos personales.
- 24 comprobaciones anteriores de autocompletado mixto, 18 de pagos/finanzas y 36 de prórrogas semanales superadas.
- ZIP validado y comparación de fuentes Android con la base original.
- **Todavía no se ha compilado ni instalado esta versión en Android real.** Compilar con la firma original de GitHub y probar antes de publicar.
