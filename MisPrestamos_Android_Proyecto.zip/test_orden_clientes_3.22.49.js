'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'app/src/main/assets/index.html'),'utf8');
const gradle=fs.readFileSync(path.join(__dirname,'app/build.gradle'),'utf8');
let tests=0;
function eq(actual,expected,label){assert.deepEqual(actual,expected,label);tests++;}
function ok(expr,label){assert.ok(expr,label);tests++;}
function fn(start,end){const i=html.indexOf(`  function ${start}(`);const j=html.indexOf(`  function ${end}(`,i);ok(i>=0&&j>i,`Se encontró ${start}`);return html.slice(i,j);}
// Evaluar las funciones REALES extraídas de la aplicación, sin datos ni dispositivo.
const src=[fn('allocateProfitCents','profitClientGroupKey'),fn('profitClientGroupKey','profitClientOrderStates'),fn('profitClientOrderStates','compareProfitClientGroups'),fn('compareProfitClientGroups','buildProfitBreakdownData'),fn('buildProfitBreakdownData','profitBreakdownExportRows')].join('\n');
const env={
  loans:[],profitBreakdownPeriod:'all',profitBreakdownStatus:'all',profitBreakdownSearch:'',
  normalizeClientName(x){return String(x||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' ');},
  statusOf(l){return l.fakeStatus;},nextCollection(l){return l.fakeNext||'';},
  estimatedProfitCents(principal,total,payments){const ps=(payments||[]).filter(p=>!p.voided&&!p.cashExcluded);const base=ps.reduce((n,p)=>n+Number(p.baseAmount??p.amount??0),0);return Math.round(Math.min(Number(total),base)*Math.max(0,Number(total)-Number(principal))/Number(total)*100)||0;},
  paymentDate(p){return String(p.dateTime||p.date||'').slice(0,10);},
  profitPeriodMatches(d,period){return period==='all'||(period==='month'&&d.startsWith('2026-11'))||(period==='today'&&d==='2026-11-12');},
  profitPeriodLabel(period){return period;},profitDetailText(k){return k;}
};vm.createContext(env);vm.runInContext(src,env,{filename:'funciones_reales_3.22.49.js'});
const add=(id,name,st,next,paidDate,options={})=>({id,client:name,clientKey:options.key||name,amount:100,total:120,startDate:options.start||'2026-11-01',dueDate:options.due||'2026-11-20',loanCode:id,fakeStatus:st,fakeNext:next||'',payments:paidDate?[{amount:120,baseAmount:120,dateTime:`${paidDate}T10:30:00`}]:[],...options});
function run(ls,period='all',status='all',query=''){
  env.loans=ls;return env.buildProfitBreakdownData(period,status,query);
}
function names(d){return Array.from(d.groups,g=>g.name);}
const activeEarly=add('AE','Ana activa','active','2026-11-13','2026-11-10');
const activeLate=add('AL','Luis activo','late','2026-11-08','2026-11-10');
const closedRecent=add('CR','Marta terminada','paid','','2026-11-11');
const closedOld=add('CO','Sergio terminado','paid','','2026-11-02');
const original=[closedOld,activeEarly,closedRecent,activeLate];
const snapshot=JSON.stringify(original);
let data=run(original);
eq(names(data),['Luis activo','Ana activa','Marta terminada','Sergio terminado'],'Activos primero, vencimiento más próximo; finalizados últimos, más reciente primero');
eq(data.clientCount,4,'Cuatro clientes sin pérdidas');
eq(data.totalCollected,480,'Cobros conservados');
eq(data.totalProfit,80,'Ganancias conservadas');
eq(data.movementCount,4,'Movimientos conservados');
eq(JSON.stringify(original),snapshot,'No mutar préstamos ni pagos originales');
// Cliente pagado retorna al grupo activo aun SIN registrar el primer pago del nuevo préstamo.
const returning=add('R2','Sergio terminado','active','2026-11-12',null,{key:'Sergio terminado'});
data=run([...original,returning]);
eq(names(data),['Luis activo','Sergio terminado','Ana activa','Marta terminada'],'Représtamo sin cobros: cliente finalizado vuelve arriba');
eq(data.totalCollected,480,'No inventar cobros de préstamo nuevo');
eq(data.totalProfit,80,'No inventar ganancias de préstamo nuevo');
eq(data.movementCount,4,'Un préstamo nuevo sin pagos no altera el número de movimientos');
eq(data.groups.find(g=>g.name==='Sergio terminado').hasActive,true,'Nuevo préstamo conserva estado de cliente activo');
eq(data.groups.find(g=>g.name==='Sergio terminado').loans.length,1,'Solo mostrar préstamos con movimientos para el filtro');
// Paga su préstamo nuevo: pasa automáticamente abajo.
returning.fakeStatus='paid';returning.fakeNext='';returning.payments=[{amount:120,baseAmount:120,dateTime:'2026-11-12T18:00:00'}];
data=run([...original,returning]);
eq(names(data),['Luis activo','Ana activa','Sergio terminado','Marta terminada'],'Al terminar todo vuelve abajo con fecha de finalización reciente');
eq(data.totalProfit,100,'Se actualiza resultado cuando se registra pago');
// Dos préstamos: terminado + vigente; siguiente cuota más próxima de cualquier préstamo activo.
const multi1=add('M1','Cliente mixto','paid','','2026-10-20',{key:'same-key'});
const multi2=add('M2','Cliente mixto','active','2026-11-14','2026-11-11',{key:'same-key'});
const multi3=add('M3','Cliente mixto','active','2026-11-09',null,{key:'same-key'});
data=run([...original,multi1,multi2,multi3]);
eq(data.groups.find(g=>g.name==='Cliente mixto').nextDue,'2026-11-09','Usa el vencimiento más próximo entre préstamos activos');
eq(data.groups.find(g=>g.name==='Cliente mixto').hasActive,true,'Terminado anterior no desplaza al cliente al final');
// Clasificación por todos los préstamos incluso si los cobros filtrados son de un préstamo ya pagado.
data=run([...original,returning,...[multi1,multi2,multi3]],'all','finished');
eq(data.groups.find(g=>g.name==='Cliente mixto')?.hasActive,true,'Filtro Finalizados no confunde el estado actual del cliente');
// Estado incobrable sin deuda activa: no se presenta como activo ni como pagado.
const uncollectible=add('I1','Incobrable','uncollectible','',null,{uncollectibleAt:'2026-11-12T17:00:00',payments:[{amount:20,baseAmount:20,dateTime:'2026-11-07T09:00:00'}]});
data=run([uncollectible]);
eq(data.groups[0].hasActive,false,'Incobrable queda como sin préstamos activos');
// Un cliente con pagos filtrados del mes anterior y nuevo préstamo sin cobros sigue activo.
const oldPayment=add('OLD','Cliente que regresa','paid','','2026-11-10',{key:'cliente-retorno'});
const newUnpaid=add('NEW','Cliente que regresa','active','2026-11-15',null,{key:'cliente-retorno'});
data=run([oldPayment,newUnpaid],'month');
eq(data.groups[0].hasActive,true,'Filtro mensual no pierde estado de nuevo préstamo sin pagos');
// Opciones de búsqueda y filtros existentes siguen disponibles.
eq(names(run(original,'all','all','Marta')),['Marta terminada'],'Buscar cliente sigue funcionando');
eq(run(original,'today').clientCount,0,'Filtro Hoy sigue respetando fecha de movimientos');
// Renderizar el HTML real de los clientes (sin navegador ni datos reales).
const uiSrc=fn('updateProfitBreakdownResults','exportProfitBreakdownCsv');
const elements=Object.fromEntries(['profitBreakdownList','profitBreakdownPeriodLabel','profitBreakdownTotalProfit','profitBreakdownTotalCollected','profitBreakdownTotalPenalty','profitBreakdownMeta'].map(id=>['#'+id,{innerHTML:'',textContent:''}]));
Object.assign(env,{
  $(selector){return elements[selector]||null;},
  normalizedLanguage(){return 'es';},regional(){return {language:'es'};},
  PROFIT_DETAIL_TEXT:{es:{...Object.fromEntries(['clients','movements','loans','loan','activeClients','finishedClients','activeOrderHint','finishedOrderHint','activeElsewhere','activeStatus','paidStatus','lateStatus','closedStatus','uncollectibleStatus','profit','collected','penaltyIncluded','estimated','method','weekly','daily','capital','totalToRepay','loanCollected','penaltyTotal','applied','received','noReceipt'].map(x=>[x,x]))}},
  esc(s){return String(s);},money(n){return Number(n).toFixed(2);},dateLabel(s){return String(s);},translateAppText(s){return String(s);}
});
vm.runInContext(uiSrc,env,{filename:'pantalla_desglose_3249.js'});
run(original);env.updateProfitBreakdownResults();
const rendered=elements['#profitBreakdownList'].innerHTML;
ok(rendered.includes('profit-client-section'),'Cabeceras visibles en desglose');
ok(rendered.indexOf('Luis activo')<rendered.indexOf('Ana activa')&&rendered.indexOf('Ana activa')<rendered.indexOf('Marta terminada'),'Orden renderizado coincide con orden calculado');
ok(rendered.indexOf('activeClients')<rendered.indexOf('finishedClients'),'Encabezado activos arriba de finalizados');
eq(elements['#profitBreakdownTotalCollected'].textContent,'480.00','El total cobrado en pantalla sigue igual');
eq(elements['#profitBreakdownTotalProfit'].textContent,'80.00','El total de ganancia estimada en pantalla sigue igual');
run([...original,add('R3','Sergio terminado','active','2026-11-12',null,{key:'Sergio terminado'})]);
env.updateProfitBreakdownResults();
ok(elements['#profitBreakdownList'].innerHTML.includes('profit-client-scope-note'),'Un nuevo préstamo activo sin pagos explica por qué sube el cliente');
for(const label of ['activeClients','finishedClients','activeOrderHint','finishedOrderHint','activeElsewhere']){
  ok(html.includes(`${label}:`),`Existe traducción de ${label}`);
}
for(const label of ['profit-client-section','profit-client-scope-note'])ok(html.includes(label),`Existe estructura visual ${label}`);
ok(/versionCode (126|127|128)/.test(gradle)&&/versionName "3\.22\.(49|50|51)"/.test(gradle),'Versión compatible con 3.22.49 o 3.22.50');
ok(gradle.includes('applicationId "com.remberto.misprestamos"'),'ApplicationId conservado');
ok(gradle.includes('keyAlias "taca_money"'),'Alias de firma conservado');
console.log('OK: '+tests+' pruebas de clasificación, représtamo, filtros, cobros y firma con datos ficticios.');
