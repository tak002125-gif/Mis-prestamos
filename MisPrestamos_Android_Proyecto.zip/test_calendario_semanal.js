'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/app/src/main/assets/index.html','utf8');
const a=html.indexOf('  /* v3.22.47 · solo presentación:');
const b=html.indexOf('\n  function refreshPenalty(l)',a);
assert(a>0&&b>a,'helpers semanales presentes');
const code=html.slice(a,b);
let today='2026-11-04';
const sandbox={
  normalizedLanguage:v=>v,
  regional:()=>({language:'es'}),
  dateLabel:s=>String(s||'').replace(/^(\d{4})-(\d{2})-(\d{2})$/,'$3/$2/$1'),
  esc:s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;'),
  money:v=>'BOB '+Number(v||0).toFixed(2),
  paidInstallments:l=>Number(l.paid||0)>=l.total-.005?l.installments:Math.min(l.installments,Math.floor((Number(l.paid||0)+.005)/Math.max(.01,l.installmentAmount))),
  supportsWeeklyInstallmentGrace:l=>Boolean(l&&l.collectionFrequency==='weekly'&&l.weeklyPaymentMode==='installments'&&Array.isArray(l.scheduleDates)),
  weeklyGraceEntry:(l,i)=>(l.weeklyGraceDates||[]).find(e=>e.installmentIndex===i&&e.originalDate===l.scheduleDates[i])||null,
  effectiveDueDate:(l,date)=>{const i=l.scheduleDates.indexOf(date);return (l.weeklyGraceDates||[]).find(e=>e.installmentIndex===i)?.until||date},
  todayISO:()=>today,
};
vm.createContext(sandbox);
vm.runInContext(code+'\n globalThis.testApi={originalWeeklyInstallments,weeklyDetailCalendarHtml,disbursementWeeklyCalendarHtml};',sandbox);
const api=sandbox.testApi;
let count=0;function check(ok,msg){assert.ok(ok,msg);count++}
function loan(weeks){let d=['2026-11-04','2026-11-11','2026-11-18','2026-11-25'];return {collectionFrequency:'weekly',weeklyPaymentMode:'installments',total:1200,installments:weeks,installmentAmount:Number((1200/weeks).toFixed(2)),scheduleDates:d.slice(0,weeks),paid:0,weeklyGraceDates:[]};}
for(let n=1;n<=4;n++){
  const l=loan(n),rows=api.originalWeeklyInstallments(l),detail=api.weeklyDetailCalendarHtml(l);
  check(rows.length===n,`${n} semanas: ${n} filas`);
  check(Math.abs(rows.reduce((t,x)=>t+x.amount,0)-1200)<.005,`${n} semanas: no altera suma`);
  for(let i=0;i<n;i++)check(detail.includes(sandbox.dateLabel(l.scheduleDates[i])),`fecha de cuota ${i+1}`);
  check(detail.includes('Calendario de cuotas semanales'),`${n} semanas: titulo`);
}
const l3=loan(3);l3.weeklyGraceDates=[{installmentIndex:0,originalDate:'2026-11-04',until:'2026-11-06'}];
const before=JSON.stringify(l3),out=api.weeklyDetailCalendarHtml(l3);
check(out.includes('04/11/2026')&&out.includes('06/11/2026'),'muestra vencimiento original y prorroga');
check(out.includes('11/11/2026')&&out.includes('18/11/2026'),'otras fechas intactas');
check(out.includes('En prórroga'),'identifica estado de prorroga');
check(before===JSON.stringify(l3),'no escribe campos en el prestamo');
const r={type:'disbursement',collectionFrequency:'weekly',weeklyPaymentMode:'installments',originalWeeklySchedule:api.originalWeeklyInstallments(l3)};
const rec=api.disbursementWeeklyCalendarHtml(r);
check(rec.includes('04/11/2026')&&!rec.includes('06/11/2026'),'recibo conserva calendario original');
check((rec.match(/receipt-weekly-calendar-row/g)||[]).length===3,'recibo 3 cuotas');
check(rec.includes('BOB 400.00'),'importe cuota correcto');
check(api.disbursementWeeklyCalendarHtml({...r,type:'quote'})==='','cotizacion no incorpora calendario');
check(api.disbursementWeeklyCalendarHtml({...r,collectionFrequency:'daily'})==='','recibo diario no incorpora calendario');
check(api.weeklyDetailCalendarHtml({...l3,collectionFrequency:'daily'})==='','detalle diario no incorpora calendario');
const single={...loan(1),weeklyPaymentMode:'single',termWeeks:3,installments:1,installmentAmount:1200,scheduleDates:['2026-11-18']};
check(api.weeklyDetailCalendarHtml(single).includes('Pago único'),'modalidad semanal pago unico respetada');
check(api.originalWeeklyInstallments(single).length===1,'no inventa cuotas para pago unico');
check(api.weeklyDetailCalendarHtml({...single,scheduleDates:[]})==='','sin calendario no inventa fechas');
const rounding={...loan(3),total:1000,installmentAmount:333.33};
check(api.originalWeeklyInstallments(rounding).map(x=>x.amount.toFixed(2)).join(',')==='333.33,333.33,333.34','ultima cuota respeta redondeo');
check(html.includes('${weeklyDetailCalendarHtml(l)}'),'ubicacion en detalles');
check(html.includes('${disbursementWeeklyCalendarHtml(r)}'),'ubicacion en recibo entrega HTML');
check(html.includes("rows.push([weeklyCalendarWord('title'),''])"),'ubicacion en canvas PDF imagen');
check(html.includes('originalWeeklySchedule:originalWeeklyInstallments(l)'),'recibo utiliza calendario del prestamo');
console.log(`OK: ${count} verificaciones calendario semanal, detalle, prorroga, recibo, cotizacion y diario.`);
