# PrestaPro 3.22.45 (versionCode 122)

## Mejora
- Pago mixto QR + Efectivo: al escribir cualquiera de los dos importes, se completa el restante automáticamente.
- El usuario puede editar cualquiera de ambos campos y el otro se recalcula.
- La misma ayuda se aplica a la corrección de un pago mixto.
- Cuando cambia el monto total (número de cuotas o corrección), se ajusta el otro componente usando el campo modificado por última vez.
- Se sigue validando antes de guardar que ambos importes sean positivos, precisos en centavos y sumen exactamente el cobro total.
- No se altera ningún pago existente ni los cálculos de capital, intereses, licencias, Caja, recibos o respaldos.

## Motivo del incremento de versión
La versión 3.22.44 código 121 ya fue instalada en Samsung y podría estar instalada en Xiaomi. Para actualizar sin desinstalar se incrementa a 3.22.45 código 122.

## Verificación
`node test_payments_mixtos.js` y `node test_autorelleno_mixto.js` deben pasar. Faltan compilación firmada, instalación y prueba en Samsung antes de instalar en Xiaomi con datos reales.
