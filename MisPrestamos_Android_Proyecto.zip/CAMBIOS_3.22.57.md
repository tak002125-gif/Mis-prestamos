# 3.22.57 (134) — candidato de prueba
- Abonos parciales en cuotas semanales, fecha real, prórroga opcional, comprobante e historial. Se reutiliza el registro de pagos y caja.
- Recordatorios vencidos: cuotas vencidas pendientes, penalización y total a regularizar. No se modifica el recordatorio normal.
- La versión anterior establece penalización sobre saldo pendiente. Para aplicar sobre cuota original se requiere marcar aceptación expresa del cliente al registrar el abono; no se reescriben eventos previos.
- Pendiente: compilación Android, pruebas de interfaz, traducción completa de nuevos controles y validación de correcciones/anulaciones y cierres históricos antes de producción.
