# Guía de pruebas — PrestaPro 3.22.48

1. **Antes de instalar:** confirmar respaldo de Google Drive íntegro y reciente. Instalar sobre la versión anterior sin desinstalar ni borrar datos. Si Android pide desinstalar, detenerse.
2. Abrir Finanzas → Resumen. Comprobar que el capital registrado, las cuotas pendientes y las ganancias coincidan con los importes de la versión anterior. La tarjeta superior **Pendiente de cobrar** ya no debe mostrar el total histórico de cuotas.
3. Verificar la tarjeta **Capital + ganancia total proyectada**. No debe tratarse como dinero disponible hoy. Si se registraron ganancias como capital, el importe ya transferido no debe sumarse dos veces.
4. Desplazarse hasta **Movimiento histórico de préstamos**. Comprobar que el total histórico esté ahí, separado del resumen real, junto con la explicación de reutilización del capital.
5. Cambiar el filtro histórico entre «Todo el tiempo» y «Este mes». Capital, deuda global, ganancia global y proyección deben permanecer iguales; solo deben cambiar las estadísticas históricas.
6. Comprobar **Gestionar capital**, Caja diaria, cierres, pago mixto, recordatorios, prórrogas semanales, recibos, PDF y copia de seguridad. No registrar cobros ficticios en equipos con datos reales.
7. Si se observa cualquier diferencia inesperada en clientes, capital, pagos, ganancias o licencia, **no registrar movimientos ni reemplazar respaldos** hasta revisar el caso.
